import { systemServices } from '../data/mockData';

export default function SystemHealth() {
  return (
    <div className="flex-1 overflow-y-auto p-4 lg:p-6 space-y-6" >
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-2 border-b" style={{ borderColor: '#e2e8f0' }}>
        <div>
          <div className="text-xs font-mono tracking-widest text-[#0284c7] uppercase">INFRASTRUCTURE TELEMETRY</div>
          <h1 className="text-2xl lg:text-3xl font-black text-slate-900 mt-1">System Health & Microservice Radar</h1>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {systemServices.map(srv => (
          <div key={srv.name} className="liquid-glass p-4 rounded-xl border space-y-3" style={{ borderColor: '#e2e8f0' }}>
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-900 truncate">{srv.name}</span>
              <span className="text-[10px] font-mono px-1.5 py-0.2 rounded font-bold uppercase text-[#059669] bg-emerald-500/20">
                {srv.status}
              </span>
            </div>
            <div className="grid grid-cols-2 gap-2 text-xs font-mono">
              <div className="p-2 rounded bg-white/80 border border-slate-200">
                <div className="text-slate-500 text-[10px]">LATENCY:</div>
                <div className="text-[#0284c7] font-bold">{srv.latency} ms</div>
              </div>
              <div className="p-2 rounded bg-white/80 border border-slate-200">
                <div className="text-slate-500 text-[10px]">UPTIME:</div>
                <div className="text-[#059669] font-bold">{srv.uptime}%</div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}