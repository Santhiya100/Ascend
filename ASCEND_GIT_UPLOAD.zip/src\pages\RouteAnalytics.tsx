import { useState } from 'react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { routes, routeDelayData } from '../data/mockData';

export default function RouteAnalytics() {
  const [selectedRouteId, setSelectedRouteId] = useState('R-01');
  const selectedRoute = routes.find(r => r.id === selectedRouteId) || routes[0];

  return (
    <div className="flex-1 overflow-y-auto p-4 lg:p-6 space-y-6" >
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-2 border-b" style={{ borderColor: '#e2e8f0' }}>
        <div>
          <div className="text-xs font-mono tracking-widest text-[#0284c7] uppercase">TRANSIT PERFORMANCE OPTIMIZATION</div>
          <h1 className="text-2xl lg:text-3xl font-black text-slate-900 mt-1">Route Analytics & Punctuality</h1>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {routes.map(r => (
          <div key={r.id} onClick={() => setSelectedRouteId(r.id)}
            className={'liquid-glass p-4 rounded-xl border cursor-pointer hover:scale-[1.02] transition-all ' + (selectedRouteId === r.id ? 'liquid-glass-glow border-cyan-400' : '')}
            style={{ borderColor: selectedRouteId === r.id ? '#06b6d4' : '#e2e8f0' }}>
            <div className="flex justify-between items-center mb-1">
              <span className="font-bold text-slate-900">{r.name}</span>
              <span className="text-[10px] font-mono text-[#059669]">{r.status}</span>
            </div>
            <div className="text-xs text-slate-500 mb-2">{r.from} ➔ {r.to}</div>
            <div className="text-xs font-mono text-[#0284c7]">Speed: {r.avgSpeed}k · Delay: {r.avgDelay}m</div>
          </div>
        ))}
      </div>

      <div className="liquid-glass p-5 rounded-2xl border" style={{ borderColor: '#e2e8f0' }}>
        <h3 className="text-sm font-bold text-slate-900 mb-4">Corridor Delay Comparison</h3>
        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={routeDelayData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" opacity={0.5} />
              <XAxis dataKey="route" stroke="#64748b" fontSize={11} fontFamily="JetBrains Mono" />
              <YAxis stroke="#64748b" fontSize={11} fontFamily="JetBrains Mono" />
              <Tooltip contentStyle={{ background: '#ffffff', border: '1px solid #0284c7', borderRadius: '16px', color: '#0f172a', fontFamily: 'JetBrains Mono', fontSize: '11px', boxShadow: '0 10px 30px rgba(0,0,0,0.1)' }} />
              <Bar dataKey="delay" fill="#f59e0b" name="Avg Delay (Mins)" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}