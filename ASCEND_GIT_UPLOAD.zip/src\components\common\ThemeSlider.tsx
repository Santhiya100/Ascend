import { useApp } from '../../context/AppContext';

export default function ThemeSlider() {
  const { state, dispatch } = useApp();
  const isDark = state.theme === 'dark';

  return (
    <div
      onClick={() => dispatch({ type: 'TOGGLE_THEME' })}
      className="relative flex items-center p-1 rounded-2xl cursor-pointer transition-all duration-300 border shadow-sm select-none font-mono text-xs"
      style={{
        background: isDark ? 'rgba(15, 23, 42, 0.9)' : 'rgba(255, 255, 255, 0.9)',
        borderColor: isDark ? 'rgba(56, 189, 248, 0.4)' : 'rgba(226, 232, 240, 0.9)',
        width: '140px',
        height: '36px',
      }}
      title={isDark ? 'Switch to Light Theme' : 'Switch to Dark Theme'}
    >
      <div
        className="absolute top-1 bottom-1 w-[66px] rounded-xl shadow-md flex items-center justify-center text-[11px] font-bold transition-all duration-300 ease-out pointer-events-none"
        style={{
          transform: isDark ? 'translateX(66px)' : 'translateX(0px)',
          background: isDark
            ? 'linear-gradient(135deg, #0284c7, #2563eb)'
            : 'linear-gradient(135deg, #f8fafc, #ffffff)',
          color: isDark ? '#ffffff' : '#0284c7',
          border: isDark ? '1px solid rgba(0, 229, 255, 0.4)' : '1px solid rgba(226, 232, 240, 1)',
          boxShadow: isDark ? '0 0 12px rgba(2, 132, 199, 0.5)' : '0 2px 8px rgba(0, 0, 0, 0.08)',
        }}
      >
        <span className="flex items-center gap-1">
          <span>{isDark ? '🌙' : '☀️'}</span>
          <span>{isDark ? 'DARK' : 'LIGHT'}</span>
        </span>
      </div>

      <div className="w-full flex justify-between items-center px-2 text-[10px] font-bold pointer-events-none">
        <span
          className="flex items-center gap-1 transition-opacity duration-200"
          style={{
            opacity: isDark ? 0.5 : 0,
            color: isDark ? '#94a3b8' : '#0284c7',
          }}
        >
          <span>☀️</span>
          <span>LIGHT</span>
        </span>
        <span
          className="flex items-center gap-1 transition-opacity duration-200"
          style={{
            opacity: isDark ? 0 : 0.5,
            color: isDark ? '#00e5ff' : '#64748b',
          }}
        >
          <span>🌙</span>
          <span>DARK</span>
        </span>
      </div>
    </div>
  );
}