import { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import { useApp } from '../../context/AppContext';

const tileProviders = {
  voyager: {
    name: 'Carto Light (Voyager)',
    url: 'https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png',
    attribution: '&copy; CARTO &copy; OpenStreetMap',
  },
  osm: {
    name: 'OpenStreetMap Standard',
    url: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
    attribution: '&copy; OpenStreetMap contributors',
  },
  satellite: {
    name: 'Satellite Hybrid (ESRI)',
    url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
    attribution: 'Tiles &copy; Esri',
  },
  dark: {
    name: 'Dark Tactical (Carto)',
    url: 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png',
    attribution: '&copy; CARTO &copy; OpenStreetMap',
  },
};

const routeCoordinates: Record<string, [number, number][]> = {
  'Route 1': [
    [12.9767, 77.5713],
    [12.9750, 77.5850],
    [12.9716, 77.5946],
    [12.9700, 77.6100],
    [12.9600, 77.6400],
    [12.9550, 77.6900],
  ],
  'Route 7': [
    [13.0280, 77.5400],
    [13.0000, 77.5700],
    [12.9767, 77.5713],
    [12.9500, 77.5700],
    [12.9300, 77.5800],
    [12.9100, 77.5850],
  ],
  'Route 12': [
    [12.9850, 77.6050],
    [12.9716, 77.5946],
    [12.9550, 77.6100],
    [12.9350, 77.6200],
    [12.9180, 77.6230],
    [12.8500, 77.6600],
  ],
  'Route 15': [
    [13.0350, 77.5970],
    [13.0000, 77.5900],
    [12.9850, 77.6050],
    [12.9600, 77.5900],
    [12.9300, 77.5900],
  ],
  'Route 21': [
    [12.9350, 77.6200],
    [12.9300, 77.6900],
    [12.9250, 77.6800],
    [12.9000, 77.6500],
    [12.9180, 77.6230],
  ],
  'Route 34': [
    [12.9900, 77.6300],
    [12.9700, 77.6400],
    [12.9500, 77.6900],
    [12.9700, 77.7200],
    [12.9700, 77.7500],
  ],
};

interface InteractiveLeafletMapProps {
  height?: string;
  showLayersControl?: boolean;
  onSelectEntity?: (entity: any) => void;
  activeLayers?: {
    buses?: boolean;
    defects?: boolean;
    traffic?: boolean;
    incidents?: boolean;
    routes?: boolean;
  };
}

export default function InteractiveLeafletMap({
  height = '100%',
  showLayersControl = true,
  onSelectEntity,
  activeLayers = { buses: true, defects: true, traffic: true, incidents: true, routes: true },
}: InteractiveLeafletMapProps) {
  const { state, dispatch } = useApp();
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const layerGroupsRef = useRef<{
    buses: L.LayerGroup;
    defects: L.LayerGroup;
    incidents: L.LayerGroup;
    routes: L.LayerGroup;
    tileLayer?: L.TileLayer;
  }>({
    buses: L.layerGroup(),
    defects: L.layerGroup(),
    incidents: L.layerGroup(),
    routes: L.layerGroup(),
  });

  const [currentTile, setCurrentTile] = useState<keyof typeof tileProviders>('voyager');

  useEffect(() => {
    if (!mapContainerRef.current || mapInstanceRef.current) return;

    const map = L.map(mapContainerRef.current, {
      center: [12.9716, 77.5946],
      zoom: 12,
      zoomControl: false,
      attributionControl: false,
    });

    L.control.zoom({ position: 'bottomright' }).addTo(map);

    const tile = L.tileLayer(tileProviders[currentTile].url, {
      maxZoom: 19,
      subdomains: 'abcd',
    }).addTo(map);

    layerGroupsRef.current.tileLayer = tile;
    layerGroupsRef.current.routes.addTo(map);
    layerGroupsRef.current.defects.addTo(map);
    layerGroupsRef.current.incidents.addTo(map);
    layerGroupsRef.current.buses.addTo(map);

    mapInstanceRef.current = map;

    return () => {
      map.remove();
      mapInstanceRef.current = null;
    };
  }, []);

  useEffect(() => {
    if (!mapInstanceRef.current) return;
    const map = mapInstanceRef.current;

    if (layerGroupsRef.current.tileLayer) {
      map.removeLayer(layerGroupsRef.current.tileLayer);
    }

    const newTile = L.tileLayer(tileProviders[currentTile].url, {
      maxZoom: 19,
      subdomains: 'abcd',
    }).addTo(map);

    layerGroupsRef.current.tileLayer = newTile;
  }, [currentTile]);

  useEffect(() => {
    if (!mapInstanceRef.current) return;
    const group = layerGroupsRef.current.routes;
    group.clearLayers();

    if (!activeLayers.routes) return;

    Object.entries(routeCoordinates).forEach(([name, coords]) => {
      const polyline = L.polyline(coords, {
        color: '#0284c7',
        weight: 4,
        opacity: 0.7,
        dashArray: '6, 8',
      });

      polyline.bindTooltip(`<strong>${name}</strong> · Rapid Transit Corridor`, {
        className: 'leaflet-custom-tooltip',
      });

      polyline.addTo(group);
    });
  }, [activeLayers.routes]);

  useEffect(() => {
    if (!mapInstanceRef.current) return;
    const group = layerGroupsRef.current.defects;
    group.clearLayers();

    if (!activeLayers.defects) return;

    state.defects.forEach(defect => {
      const isCritical = defect.severity === 'critical';
      const color = isCritical ? '#e11d48' : '#d97706';

      const icon = L.divIcon({
        className: 'custom-leaflet-marker',
        html: `
          <div style="
            background: ${color};
            color: white;
            font-family: 'JetBrains Mono', monospace;
            font-size: 10px;
            font-weight: bold;
            padding: 3px 6px;
            border-radius: 9999px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.25);
            border: 2px solid white;
            display: flex;
            align-items: center;
            gap: 4px;
            white-space: nowrap;
            cursor: pointer;
            transform: translate(-50%, -50%);
          ">
            <span>⚠</span>
            <span>${defect.type.toUpperCase().slice(0, 4)}</span>
          </div>
        `,
        iconSize: [60, 24],
        iconAnchor: [30, 12],
      });

      const marker = L.marker([defect.lat, defect.lng], { icon });

      marker.on('click', () => {
        if (onSelectEntity) onSelectEntity({ type: 'Defect', data: defect });
      });

      marker.addTo(group);
    });
  }, [state.defects, activeLayers.defects, onSelectEntity]);

  useEffect(() => {
    if (!mapInstanceRef.current) return;
    const group = layerGroupsRef.current.buses;
    group.clearLayers();

    if (!activeLayers.buses) return;

    state.buses.forEach(bus => {
      const isCritical = bus.status === 'critical';
      const color = isCritical ? '#e11d48' : '#0284c7';

      const icon = L.divIcon({
        className: 'custom-leaflet-marker',
        html: `
          <div style="
            background: white;
            color: #0f172a;
            font-family: 'JetBrains Mono', monospace;
            font-size: 11px;
            font-weight: bold;
            padding: 4px 8px;
            border-radius: 12px;
            box-shadow: 0 4px 16px rgba(0,0,0,0.18);
            border: 2px solid ${color};
            display: flex;
            align-items: center;
            gap: 5px;
            white-space: nowrap;
            cursor: pointer;
            transform: translate(-50%, -50%);
          ">
            <span style="color: ${color}; font-size: 13px;">🚌</span>
            <span>${bus.id}</span>
            <span style="font-size: 9px; color: #64748b; font-weight: normal;">${bus.speed}km/h</span>
          </div>
        `,
        iconSize: [85, 28],
        iconAnchor: [42, 14],
      });

      const marker = L.marker([bus.lat, bus.lng], { icon });

      marker.on('click', () => {
        dispatch({ type: 'SELECT_BUS', id: bus.id });
        if (onSelectEntity) onSelectEntity({ type: 'Bus', data: bus });
      });

      marker.addTo(group);
    });
  }, [state.buses, activeLayers.buses, onSelectEntity, dispatch]);

  return (
    <div className="relative w-full rounded-2xl overflow-hidden shadow-inner" style={{ height }}>
      <div ref={mapContainerRef} className="w-full h-full z-0" />

      {showLayersControl && (
        <div className="absolute top-3 left-3 z-10 flex items-center gap-2 bg-white/90 p-1.5 rounded-2xl border border-slate-200 backdrop-blur-md shadow-md font-mono text-[11px]">
          <span className="text-slate-500 font-bold px-1.5">MAP:</span>
          {(['voyager', 'osm', 'satellite', 'dark'] as const).map(k => (
            <button
              key={k}
              onClick={() => setCurrentTile(k)}
              className={'px-2.5 py-1 rounded-xl uppercase font-bold transition-all ' + (
                currentTile === k ? 'bg-[#0284c7] text-white shadow-sm' : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              )}
            >
              {k}
            </button>
          ))}

          <button
            onClick={() => {
              if (mapInstanceRef.current) {
                mapInstanceRef.current.setView([12.9716, 77.5946], 12);
              }
            }}
            className="px-2 py-1 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold ml-1"
            title="Reset to Bengaluru Central"
          >
            🎯 Center
          </button>
        </div>
      )}

      <div className="absolute bottom-3 left-3 z-10 flex items-center gap-3 px-3.5 py-2 rounded-2xl bg-white/90 border border-slate-200 text-[10px] font-mono backdrop-blur-md shadow-md">
        <span className="flex items-center gap-1.5 text-[#0284c7] font-bold">
          <span className="w-2.5 h-2.5 rounded-full bg-[#0284c7] shadow-[0_0_6px_#0284c7]" /> Transit Bus
        </span>
        <span className="flex items-center gap-1.5 text-[#d97706] font-bold">
          <span className="w-2.5 h-2.5 rounded-full bg-[#d97706] shadow-[0_0_6px_#d97706]" /> Road Hazard
        </span>
        <span className="flex items-center gap-1.5 text-[#e11d48] font-bold">
          <span className="w-2.5 h-2.5 rounded-full bg-[#e11d48] shadow-[0_0_6px_#e11d48]" /> Critical SOS
        </span>
      </div>
    </div>
  );
}