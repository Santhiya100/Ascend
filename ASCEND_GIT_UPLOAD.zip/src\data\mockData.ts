export type BusStatus = 'normal' | 'warning' | 'critical' | 'offline';
export type DeviceStatus = 'online' | 'degraded' | 'offline';
export type Severity = 'low' | 'medium' | 'high' | 'critical';
export type IncidentStatus = 'detected' | 'verified' | 'assigned' | 'responding' | 'resolved';

export interface Bus {
  id: string;
  registration: string;
  route: string;
  depot: string;
  driver: string;
  driverPhone: string;
  lat: number;
  lng: number;
  x: number; // SVG map x (0-1000)
  y: number; // SVG map y (0-700)
  speed: number;
  passengers: number;
  capacity: number;
  status: BusStatus;
  gpsStatus: DeviceStatus;
  cameraStatus: DeviceStatus;
  edgeAIStatus: DeviceStatus;
  networkStatus: DeviceStatus;
  tripId: string;
  eta: string;
  heading: number;
  routeProgress: number; // 0-100
  cameras: string[];
  cpuUsage: number;
  memUsage: number;
  temperature: number;
  aiModelVersion: string;
  lastHeartbeat: string;
  lastSync: string;
  storage: number;
  boardingToday: number;
  alightingToday: number;
}

export interface Alert {
  id: string;
  type: string;
  category: 'road' | 'traffic' | 'passenger' | 'safety' | 'system' | 'sos';
  severity: Severity;
  busId: string;
  location: string;
  lat: number;
  lng: number;
  timestamp: Date;
  status: 'new' | 'acknowledged' | 'resolved';
  description: string;
}

export interface RoadDefect {
  id: string;
  type: 'pothole' | 'crack' | 'waterlogging' | 'debris' | 'missing_divider' | 'damaged_divider' | 'damaged_road';
  severity: Severity;
  confidence: number;
  lat: number;
  lng: number;
  x: number;
  y: number;
  busId: string;
  timestamp: Date;
  status: 'detected' | 'verified' | 'assigned' | 'in_progress' | 'resolved';
  assignedTeam?: string;
  nearbyIncidents: number;
  imagePlaceholder?: string;
  depthCm?: number;
  areaSqMeters?: number;
}

export interface Incident {
  id: string;
  type: string;
  severity: Severity;
  busId: string;
  location: string;
  timestamp: Date;
  status: IncidentStatus;
  assignedOfficer?: string;
  description: string;
  lat: number;
  lng: number;
  evidenceRef?: string;
}

export interface SOSAlert {
  id: string;
  busId: string;
  route: string;
  location: string;
  timestamp: Date;
  occupancy: number;
  capacity: number;
  gps: string;
  alertSource: string;
  severity: 'critical';
  status: 'active' | 'acknowledged' | 'responded' | 'resolved';
  timelineSteps: { label: string; done: boolean; time?: string }[];
}

export interface MaintenanceTask {
  id: string;
  defectId: string;
  location: string;
  defectType: string;
  severity: Severity;
  detectedDate: Date;
  assignedDepartment: string;
  priority: number;
  expectedCompletion: Date;
  status: 'open' | 'assigned' | 'in_progress' | 'completed';
  description: string;
  estimatedCost?: string;
}

export interface ANPREvent {
  id: string;
  plateNumber: string;
  confidence: number;
  vehicleType: string;
  timestamp: Date;
  busId: string;
  camera: string;
  direction: string;
  gps: string;
  incidentType: string;
  status: 'detected' | 'reviewed' | 'escalated' | 'cleared';
  speedKmH?: number;
}

export interface Route {
  id: string;
  name: string;
  from: string;
  to: string;
  distance: number;
  buses: number;
  avgSpeed: number;
  avgDelay: number;
  passengerDemand: number;
  occupancy: number;
  status: 'on-time' | 'delayed' | 'disrupted';
  congestionPoints: string[];
}

export interface SystemService {
  name: string;
  status: DeviceStatus;
  latency: number;
  uptime: number;
  lastCheck: string;
  eventsPerMin: number;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: string;
  department: string;
  status: 'active' | 'inactive';
  lastLogin: string;
  permissions: string[];
}

export interface ODMatrixItem {
  origin: string;
  destination: string;
  passengerVolume: number;
  peakTime: string;
  primaryRoute: string;
}

// ─── SVG Route Trajectories ──────────────────────────────────────────────────
export const svgRoutes: Record<string, [number, number][]> = {
  'Route 1':  [[50,350],[150,350],[300,350],[450,350],[600,350],[750,350],[900,350],[950,350]],
  'Route 7':  [[200,50],[200,150],[200,300],[200,450],[200,600],[200,680]],
  'Route 12': [[80,150],[200,180],[380,220],[500,300],[620,400],[750,480],[880,550],[960,600]],
  'Route 15': [[500,30],[500,150],[500,280],[500,420],[500,570],[500,680]],
  'Route 21': [[50,550],[200,530],[400,550],[600,520],[800,540],[950,550]],
  'Route 34': [[800,50],[750,200],[700,350],[720,500],[800,620],[820,680]],
};

// ─── Initial Fleet ───────────────────────────────────────────────────────────
export const initialBuses: Bus[] = [
  { id:'B-101', registration:'KA01AB1234', route:'Route 1', depot:'Majestic', driver:'Ramesh Kumar', driverPhone:'9876543210', lat:12.9716, lng:77.5946, x:200, y:350, speed:34, passengers:42, capacity:60, status:'normal', gpsStatus:'online', cameraStatus:'online', edgeAIStatus:'online', networkStatus:'online', tripId:'T-2026-001', eta:'14 min', heading:90, routeProgress:35, cameras:['Front AI','Rear Cam','Left Blindspot','Right Blindspot','Cabin AI'], cpuUsage:62, memUsage:71, temperature:48, aiModelVersion:'v3.2.1-Edge', lastHeartbeat:'2s ago', lastSync:'1m ago', storage:68, boardingToday:340, alightingToday:298 },
  { id:'B-102', registration:'KA01CD5678', route:'Route 7', depot:'Yeshwanthpur', driver:'Suresh Babu', driverPhone:'9876543211', lat:12.9800, lng:77.5700, x:200, y:300, speed:28, passengers:55, capacity:60, status:'warning', gpsStatus:'online', cameraStatus:'degraded', edgeAIStatus:'online', networkStatus:'online', tripId:'T-2026-002', eta:'22 min', heading:180, routeProgress:55, cameras:['Front AI','Rear Cam','Left Blindspot','Right Blindspot','Cabin AI'], cpuUsage:78, memUsage:82, temperature:54, aiModelVersion:'v3.2.1-Edge', lastHeartbeat:'3s ago', lastSync:'2m ago', storage:74, boardingToday:480, alightingToday:425 },
  { id:'B-103', registration:'KA02EF9012', route:'Route 12', depot:'Shivajinagar', driver:'Venkat Rao', driverPhone:'9876543212', lat:12.9550, lng:77.6100, x:620, y:400, speed:0, passengers:18, capacity:60, status:'critical', gpsStatus:'online', cameraStatus:'online', edgeAIStatus:'online', networkStatus:'degraded', tripId:'T-2026-003', eta:'Delayed', heading:135, routeProgress:72, cameras:['Front AI','Rear Cam','Cabin AI'], cpuUsage:45, memUsage:58, temperature:42, aiModelVersion:'v3.1.9-Edge', lastHeartbeat:'5s ago', lastSync:'5m ago', storage:52, boardingToday:190, alightingToday:172 },
  { id:'B-104', registration:'KA03GH3456', route:'Route 12', depot:'Shivajinagar', driver:'Mohan Das', driverPhone:'9876543213', lat:12.9600, lng:77.5950, x:500, y:300, speed:41, passengers:33, capacity:60, status:'normal', gpsStatus:'online', cameraStatus:'online', edgeAIStatus:'online', networkStatus:'online', tripId:'T-2026-004', eta:'8 min', heading:45, routeProgress:48, cameras:['Front AI','Rear Cam','Left Blindspot','Right Blindspot','Cabin AI'], cpuUsage:58, memUsage:66, temperature:47, aiModelVersion:'v3.2.1-Edge', lastHeartbeat:'1s ago', lastSync:'30s ago', storage:61, boardingToday:310, alightingToday:277 },
  { id:'B-105', registration:'KA04IJ7890', route:'Route 15', depot:'KSRTC', driver:'Anil Singh', driverPhone:'9876543214', lat:12.9650, lng:77.5850, x:500, y:280, speed:52, passengers:28, capacity:60, status:'normal', gpsStatus:'online', cameraStatus:'online', edgeAIStatus:'online', networkStatus:'online', tripId:'T-2026-005', eta:'11 min', heading:0, routeProgress:40, cameras:['Front AI','Rear Cam','Cabin AI'], cpuUsage:55, memUsage:62, temperature:45, aiModelVersion:'v3.2.1-Edge', lastHeartbeat:'2s ago', lastSync:'45s ago', storage:59, boardingToday:260, alightingToday:232 },
  { id:'B-106', registration:'KA05KL1234', route:'Route 21', depot:'Electronic City', driver:'Prakash Nair', driverPhone:'9876543215', lat:12.9400, lng:77.6200, x:700, y:550, speed:22, passengers:47, capacity:60, status:'warning', gpsStatus:'degraded', cameraStatus:'online', edgeAIStatus:'online', networkStatus:'online', tripId:'T-2026-006', eta:'19 min', heading:0, routeProgress:65, cameras:['Front AI','Rear Cam','Left Blindspot','Right Blindspot','Cabin AI'], cpuUsage:70, memUsage:75, temperature:51, aiModelVersion:'v3.2.0-Edge', lastHeartbeat:'8s ago', lastSync:'3m ago', storage:77, boardingToday:395, alightingToday:348 },
  { id:'B-107', registration:'KA06MN5678', route:'Route 34', depot:'Whitefield', driver:'Rajendra Shetty', driverPhone:'9876543216', lat:12.9900, lng:77.6300, x:750, y:200, speed:0, passengers:0, capacity:60, status:'offline', gpsStatus:'offline', cameraStatus:'offline', edgeAIStatus:'offline', networkStatus:'offline', tripId:'-', eta:'-', heading:180, routeProgress:0, cameras:['Front AI','Rear Cam'], cpuUsage:0, memUsage:0, temperature:32, aiModelVersion:'v3.1.8-Edge', lastHeartbeat:'15m ago', lastSync:'30m ago', storage:45, boardingToday:0, alightingToday:0 },
  { id:'B-108', registration:'KA07OP9012', route:'Route 1', depot:'Majestic', driver:'Girish Murthy', driverPhone:'9876543217', lat:12.9716, lng:77.6100, x:600, y:350, speed:38, passengers:39, capacity:60, status:'normal', gpsStatus:'online', cameraStatus:'online', edgeAIStatus:'online', networkStatus:'online', tripId:'T-2026-008', eta:'6 min', heading:90, routeProgress:68, cameras:['Front AI','Rear Cam','Cabin AI'], cpuUsage:60, memUsage:69, temperature:46, aiModelVersion:'v3.2.1-Edge', lastHeartbeat:'2s ago', lastSync:'1m ago', storage:63, boardingToday:315, alightingToday:276 },
  { id:'B-109', registration:'KA08QR3456', route:'Route 7', depot:'Yeshwanthpur', driver:'Deepak Tiwari', driverPhone:'9876543218', lat:12.9500, lng:77.5700, x:200, y:500, speed:31, passengers:22, capacity:60, status:'normal', gpsStatus:'online', cameraStatus:'online', edgeAIStatus:'online', networkStatus:'online', tripId:'T-2026-009', eta:'16 min', heading:180, routeProgress:78, cameras:['Front AI','Rear Cam','Cabin AI'], cpuUsage:52, memUsage:61, temperature:44, aiModelVersion:'v3.2.1-Edge', lastHeartbeat:'3s ago', lastSync:'1m ago', storage:57, boardingToday:210, alightingToday:188 },
  { id:'B-110', registration:'KA09ST7890', route:'Route 15', depot:'KSRTC', driver:'Mahesh Kulkarni', driverPhone:'9876543219', lat:12.9400, lng:77.5850, x:500, y:550, speed:44, passengers:51, capacity:60, status:'warning', gpsStatus:'online', cameraStatus:'online', edgeAIStatus:'degraded', networkStatus:'online', tripId:'T-2026-010', eta:'9 min', heading:180, routeProgress:82, cameras:['Front AI','Rear Cam','Left Blindspot','Right Blindspot','Cabin AI'], cpuUsage:85, memUsage:88, temperature:57, aiModelVersion:'v3.2.1-Edge', lastHeartbeat:'4s ago', lastSync:'2m ago', storage:82, boardingToday:420, alightingToday:369 },
];

// ─── Initial Road Defects ────────────────────────────────────────────────────
export const initialDefects: RoadDefect[] = [
  { id:'RD-001', type:'pothole', severity:'high', confidence:94, lat:12.9716, lng:77.5946, x:300, y:350, busId:'B-101', timestamp:new Date(Date.now()-3600000), status:'verified', assignedTeam:'BBMP Ward 45', nearbyIncidents:2, depthCm:14, areaSqMeters:0.8 },
  { id:'RD-002', type:'waterlogging', severity:'critical', confidence:98, lat:12.9800, lng:77.5700, x:200, y:200, busId:'B-102', timestamp:new Date(Date.now()-7200000), status:'assigned', assignedTeam:'Storm Water Dept', nearbyIncidents:1, depthCm:25, areaSqMeters:12.0 },
  { id:'RD-003', type:'crack', severity:'medium', confidence:87, lat:12.9550, lng:77.6100, x:620, y:400, busId:'B-103', timestamp:new Date(Date.now()-1800000), status:'detected', nearbyIncidents:0, depthCm:4, areaSqMeters:2.5 },
  { id:'RD-004', type:'missing_divider', severity:'high', confidence:91, lat:12.9600, lng:77.5950, x:500, y:300, busId:'B-104', timestamp:new Date(Date.now()-5400000), status:'verified', assignedTeam:'BBMP Road Div', nearbyIncidents:1 },
  { id:'RD-005', type:'pothole', severity:'medium', confidence:89, lat:12.9400, lng:77.6200, x:700, y:550, busId:'B-106', timestamp:new Date(Date.now()-900000), status:'detected', nearbyIncidents:0, depthCm:8, areaSqMeters:0.4 },
  { id:'RD-006', type:'damaged_road', severity:'critical', confidence:96, lat:12.9716, lng:77.6100, x:600, y:350, busId:'B-108', timestamp:new Date(Date.now()-10800000), status:'in_progress', assignedTeam:'BBMP Road Div', nearbyIncidents:3, depthCm:18, areaSqMeters:6.5 },
  { id:'RD-007', type:'debris', severity:'low', confidence:82, lat:12.9500, lng:77.5700, x:200, y:500, busId:'B-109', timestamp:new Date(Date.now()-600000), status:'detected', nearbyIncidents:0, areaSqMeters:1.2 },
  { id:'RD-008', type:'pothole', severity:'high', confidence:93, lat:12.9400, lng:77.5850, x:500, y:580, busId:'B-110', timestamp:new Date(Date.now()-2700000), status:'resolved', assignedTeam:'BBMP Ward 22', nearbyIncidents:1, depthCm:11, areaSqMeters:0.6 },
  { id:'RD-009', type:'damaged_divider', severity:'high', confidence:90, lat:12.9750, lng:77.6050, x:450, y:280, busId:'B-105', timestamp:new Date(Date.now()-4200000), status:'verified', assignedTeam:'BBMP Road Div', nearbyIncidents:1 },
  { id:'RD-010', type:'waterlogging', severity:'high', confidence:92, lat:12.9350, lng:77.6200, x:720, y:500, busId:'B-106', timestamp:new Date(Date.now()-1500000), status:'detected', nearbyIncidents:0, depthCm:15, areaSqMeters:8.0 },
];

// ─── Initial Alerts ──────────────────────────────────────────────────────────
export const initialAlerts: Alert[] = [
  { id:'ALT-001', type:'Pothole Detected', category:'road', severity:'high', busId:'B-101', location:'MG Road, Near Brigade Junction', lat:12.9716, lng:77.5946, timestamp:new Date(Date.now()-3600000), status:'new', description:'High severity pothole detected with 94% confidence. 14cm depth. Immediate repair required.' },
  { id:'ALT-002', type:'Traffic Congestion', category:'traffic', severity:'critical', busId:'B-103', location:'Silk Board Junction', lat:12.9550, lng:77.6100, timestamp:new Date(Date.now()-1800000), status:'acknowledged', description:'Severe congestion detected. Traffic density: 95%. Average speed dropped to 8 km/h.' },
  { id:'ALT-003', type:'Bus Overcrowding', category:'passenger', severity:'warning', busId:'B-102', location:'Majestic Bus Stop', lat:12.9800, lng:77.5700, timestamp:new Date(Date.now()-900000), status:'new', description:'Bus occupancy at 92%. Passengers: 55/60. Deploy auxiliary feeder bus.' },
  { id:'ALT-004', type:'Waterlogging Detected', category:'road', severity:'critical', busId:'B-102', location:'Koramangala 5th Block', lat:12.9350, lng:77.6200, timestamp:new Date(Date.now()-7200000), status:'acknowledged', description:'Severe waterlogging detected. Road partially submerged. Safety risk for light vehicles.' },
  { id:'ALT-005', type:'Rash Driving Behavior', category:'safety', severity:'high', busId:'B-105', location:'Airport Road, Near Hebbal', lat:12.9650, lng:77.5850, timestamp:new Date(Date.now()-600000), status:'new', description:'Sudden acceleration (0.48g) and harsh braking detected. Speed spike: 72 km/h in 30 km/h zone.' },
  { id:'ALT-006', type:'Infrastructure Damage', category:'road', severity:'medium', busId:'B-108', location:'Old Airport Road', lat:12.9716, lng:77.6100, timestamp:new Date(Date.now()-10800000), status:'resolved', description:'Damaged traffic sign post detected at junction. Visibility hazard.' },
  { id:'ALT-007', type:'Edge AI Degraded', category:'system', severity:'warning', busId:'B-110', location:'Electronic City Phase 1', lat:12.9400, lng:77.5850, timestamp:new Date(Date.now()-1200000), status:'new', description:'Edge AI module temperature spiked to 57°C. Inference throttling active.' },
  { id:'ALT-008', type:'School Zone Pedestrian Risk', category:'safety', severity:'high', busId:'B-104', location:'Near City Public School, MG Road', lat:12.9620, lng:77.5980, timestamp:new Date(Date.now()-450000), status:'new', description:'Heavy pedestrian activity in school crossing during active drop-off hours.' },
];

// ─── Initial SOS ─────────────────────────────────────────────────────────────
export const initialSOS: SOSAlert[] = [
  {
    id: 'SOS-2026-001',
    busId: 'B-104',
    route: 'Route 12',
    location: 'MG Road, Near Trinity Circle',
    timestamp: new Date(Date.now() - 180000),
    occupancy: 33,
    capacity: 60,
    gps: '12.9716° N, 77.5946° E',
    alertSource: 'Passenger Emergency Button',
    severity: 'critical',
    status: 'acknowledged',
    timelineSteps: [
      { label: 'SOS Triggered', done: true, time: '14:23:45' },
      { label: 'Control Room Notified', done: true, time: '14:23:47' },
      { label: 'Safety Officer Assigned', done: true, time: '14:24:02' },
      { label: 'Location Shared to PCR Van #14', done: true, time: '14:24:15' },
      { label: 'Response Team Dispatched', done: false },
      { label: 'Incident Resolved', done: false },
    ],
  },
];

// ─── Initial Incidents ───────────────────────────────────────────────────────
export const initialIncidents: Incident[] = [
  { id:'INC-001', type:'Road Hazard', severity:'high', busId:'B-101', location:'MG Road, Near Brigade', timestamp:new Date(Date.now()-3600000), status:'verified', assignedOfficer:'Insp. Sharma', description:'Large pothole causing vehicle swerving.', lat:12.9716, lng:77.5946 },
  { id:'INC-002', type:'Rash Driving', severity:'high', busId:'B-105', location:'Airport Road', timestamp:new Date(Date.now()-600000), status:'detected', description:'Dangerous driving behavior recorded with high lateral acceleration.', lat:12.9650, lng:77.5850 },
  { id:'INC-003', type:'Waterlogging', severity:'critical', busId:'B-102', location:'Koramangala', timestamp:new Date(Date.now()-7200000), status:'responding', assignedOfficer:'Off. Kumar', description:'Road flooded. Traffic diverted.', lat:12.9350, lng:77.6200 },
  { id:'INC-004', type:'Pedestrian Risk', severity:'medium', busId:'B-108', location:'MG Road Crossing', timestamp:new Date(Date.now()-1800000), status:'assigned', assignedOfficer:'Insp. Reddy', description:'Pedestrian walking on roadway in non-designated area.', lat:12.9716, lng:77.6100 },
  { id:'INC-005', type:'Passenger SOS Alert', severity:'critical', busId:'B-104', location:'MG Road Near Trinity', timestamp:new Date(Date.now()-180000), status:'responding', assignedOfficer:'Safety Off. Priya', description:'Passenger SOS triggered. PCR Van en route.', lat:12.9716, lng:77.5946 },
  { id:'INC-006', type:'Vehicle Collision', severity:'critical', busId:'B-106', location:'Electronic City Flyover', timestamp:new Date(Date.now()-900000), status:'assigned', assignedOfficer:'Insp. Naidu', description:'Two-wheeler collision near entry ramp. Emergency medical unit notified.', lat:12.9400, lng:77.6200 },
];

// ─── ANPR Events ─────────────────────────────────────────────────────────────
export const anprEvents: ANPREvent[] = [
  { id:'ANPR-001', plateNumber:'KA01XX4521', confidence:97.3, vehicleType:'White SUV', timestamp:new Date(Date.now()-600000), busId:'B-101', camera:'Front AI', direction:'North-bound', gps:'12.9716°N, 77.5946°E', incidentType:'Rash Driving', status:'reviewed', speedKmH:78 },
  { id:'ANPR-002', plateNumber:'MH02YZ8834', confidence:94.1, vehicleType:'Heavy Truck', timestamp:new Date(Date.now()-3600000), busId:'B-108', camera:'Front AI', direction:'East-bound', gps:'12.9716°N, 77.6100°E', incidentType:'Signal Violation', status:'escalated', speedKmH:52 },
  { id:'ANPR-003', plateNumber:'KA05AB2267', confidence:89.7, vehicleType:'Black Motorcycle', timestamp:new Date(Date.now()-1800000), busId:'B-103', camera:'Rear Cam', direction:'South-bound', gps:'12.9550°N, 77.6100°E', incidentType:'Hit and Run', status:'detected', speedKmH:64 },
  { id:'ANPR-004', plateNumber:'TN07CD9921', confidence:96.8, vehicleType:'Sedan', timestamp:new Date(Date.now()-900000), busId:'B-105', camera:'Front AI', direction:'West-bound', gps:'12.9650°N, 77.5850°E', incidentType:'Over-speeding', status:'reviewed', speedKmH:88 },
  { id:'ANPR-005', plateNumber:'KA03MN1102', confidence:98.5, vehicleType:'Auto Rickshaw', timestamp:new Date(Date.now()-480000), busId:'B-104', camera:'Front AI', direction:'South-bound', gps:'12.9600°N, 77.5950°E', incidentType:'Wrong Side Driving', status:'reviewed', speedKmH:35 },
  { id:'ANPR-006', plateNumber:'KA51EF7723', confidence:92.4, vehicleType:'Compact SUV', timestamp:new Date(Date.now()-2100000), busId:'B-106', camera:'Right Cam', direction:'North-bound', gps:'12.9400°N, 77.6200°E', incidentType:'Illegal Parking / Blockage', status:'cleared', speedKmH:0 },
];

// ─── Initial Maintenance ─────────────────────────────────────────────────────
export const initialMaintenance: MaintenanceTask[] = [
  { id:'MT-001', defectId:'RD-001', location:'MG Road, Brigade Junction', defectType:'Pothole', severity:'high', detectedDate:new Date(Date.now()-3600000), assignedDepartment:'BBMP Ward 45', priority:1, expectedCompletion:new Date(Date.now()+86400000), status:'in_progress', description:'Deep pothole 30cm diameter, 14cm depth. Requires rapid cold-mix asphalt patch.', estimatedCost:'₹14,500' },
  { id:'MT-002', defectId:'RD-002', location:'Koramangala 5th Block', defectType:'Waterlogging', severity:'critical', detectedDate:new Date(Date.now()-7200000), assignedDepartment:'Storm Water Dept', priority:1, expectedCompletion:new Date(Date.now()+43200000), status:'assigned', description:'Blocked stormwater drain causing flooding across 12m roadway. Silt suction unit deployed.', estimatedCost:'₹32,000' },
  { id:'MT-003', defectId:'RD-004', location:'Airport Road Junction', defectType:'Missing Divider', severity:'high', detectedDate:new Date(Date.now()-5400000), assignedDepartment:'BBMP Road Division', priority:2, expectedCompletion:new Date(Date.now()+172800000), status:'open', description:'Divider concrete block dislodged. Temporary reflective safety barriers placed.', estimatedCost:'₹8,000' },
  { id:'MT-004', defectId:'RD-006', location:'Old Airport Road', defectType:'Damaged Road Surface', severity:'critical', detectedDate:new Date(Date.now()-10800000), assignedDepartment:'BBMP Road Division', priority:1, expectedCompletion:new Date(Date.now()+21600000), status:'in_progress', description:'3m x 2m road surface erosion. Heavy base grade resurfacing underway.', estimatedCost:'₹58,000' },
  { id:'MT-005', defectId:'RD-008', location:'Electronic City Phase 2', defectType:'Pothole', severity:'high', detectedDate:new Date(Date.now()-2700000), assignedDepartment:'BBMP Ward 22', priority:2, expectedCompletion:new Date(Date.now()-3600000), status:'completed', description:'Pothole filled and compacted. Post-repair inspection passed.', estimatedCost:'₹11,200' },
  { id:'MT-006', defectId:'RD-009', location:'Richmond Circle Flyover', defectType:'Damaged Divider', severity:'high', detectedDate:new Date(Date.now()-4200000), assignedDepartment:'BBMP Road Division', priority:2, expectedCompletion:new Date(Date.now()+129600000), status:'open', description:'Concrete curb damaged following minor crash. Repair team scheduled.', estimatedCost:'₹16,000' },
];

// ─── Routes ──────────────────────────────────────────────────────────────────
export const routes: Route[] = [
  { id:'R-01', name:'Route 1', from:'Majestic', to:'Whitefield', distance:28.5, buses:4, avgSpeed:32, avgDelay:8, passengerDemand:87, occupancy:71, status:'on-time', congestionPoints:['Brigade Jn','Old Airport Rd'] },
  { id:'R-07', name:'Route 7', from:'Yeshwanthpur', to:'Silk Board', distance:22.3, buses:3, avgSpeed:24, avgDelay:22, passengerDemand:92, occupancy:84, status:'delayed', congestionPoints:['Silk Board','Koramangala'] },
  { id:'R-12', name:'Route 12', from:'Shivajinagar', to:'Electronic City', distance:31.2, buses:3, avgSpeed:18, avgDelay:35, passengerDemand:78, occupancy:68, status:'delayed', congestionPoints:['Trinity Circle','Hosur Rd'] },
  { id:'R-15', name:'Route 15', from:'KSRTC', to:'Airport', distance:41.8, buses:2, avgSpeed:45, avgDelay:5, passengerDemand:65, occupancy:52, status:'on-time', congestionPoints:['Hebbal Flyover'] },
  { id:'R-21', name:'Route 21', from:'KR Puram', to:'Electronic City', distance:18.9, buses:2, avgSpeed:28, avgDelay:12, passengerDemand:81, occupancy:74, status:'on-time', congestionPoints:['Marathahalli'] },
  { id:'R-34', name:'Route 34', from:'Whitefield', to:'Hebbal', distance:35.6, buses:1, avgSpeed:38, avgDelay:0, passengerDemand:45, occupancy:38, status:'on-time', congestionPoints:['Tin Factory'] },
];

// ─── System Microservices ─────────────────────────────────────────────────────
export const systemServices: SystemService[] = [
  { name:'Fleet Telemetry Stream (MQTT)', status:'online', latency:12, uptime:99.98, lastCheck:'2s ago', eventsPerMin:1420 },
  { name:'GIS Spatial Aggregator', status:'online', latency:18, uptime:99.95, lastCheck:'3s ago', eventsPerMin:890 },
  { name:'Edge AI Ingestion Gateway', status:'online', latency:42, uptime:99.87, lastCheck:'1s ago', eventsPerMin:2350 },
  { name:'Computer Vision Defect Engine', status:'online', latency:84, uptime:99.72, lastCheck:'5s ago', eventsPerMin:310 },
  { name:'Distributed Time-Series DB', status:'online', latency:4, uptime:99.99, lastCheck:'1s ago', eventsPerMin:4100 },
  { name:'Emergency SOS Dispatch Bus', status:'online', latency:8, uptime:99.99, lastCheck:'1s ago', eventsPerMin:45 },
  { name:'GPS Differential Corrector', status:'degraded', latency:215, uptime:98.12, lastCheck:'10s ago', eventsPerMin:640 },
  { name:'Notification & SMS Webhook', status:'online', latency:24, uptime:99.91, lastCheck:'4s ago', eventsPerMin:120 },
  { name:'Automated PDF/CSV Report Engine', status:'online', latency:145, uptime:99.80, lastCheck:'15s ago', eventsPerMin:18 },
  { name:'Traffic & Delay Predictive Model', status:'online', latency:290, uptime:99.65, lastCheck:'8s ago', eventsPerMin:85 },
];

// ─── User Accounts ───────────────────────────────────────────────────────────
export const users: User[] = [
  { id:'U-001', name:'Rajiv Sharma', email:'rajiv.sharma@ascend.gov.in', role:'Transport Administrator', department:'Transport Dept HQ', status:'active', lastLogin:'2 mins ago', permissions:['all'] },
  { id:'U-002', name:'Priya Nair', email:'priya.nair@ascend.gov.in', role:'Safety Officer', department:'Passenger Safety Division', status:'active', lastLogin:'15 mins ago', permissions:['dashboard','fleet','safety','sos','incidents'] },
  { id:'U-003', name:'Arun Kumar', email:'arun.kumar@ascend.gov.in', role:'Control Room Operator', department:'Central Operations', status:'active', lastLogin:'Just now', permissions:['dashboard','fleet','traffic','alerts','gis'] },
  { id:'U-004', name:'Meena Reddy', email:'meena.reddy@ascend.gov.in', role:'Road Maintenance Officer', department:'BBMP Infrastructure', status:'active', lastLogin:'1 hour ago', permissions:['dashboard','road','maintenance','reports'] },
  { id:'U-005', name:'Sunil Patel', email:'sunil.patel@ascend.gov.in', role:'Traffic Officer', department:'Bengaluru Traffic Police', status:'active', lastLogin:'30 mins ago', permissions:['dashboard','traffic','incidents','anpr'] },
  { id:'U-006', name:'Kavitha Iyer', email:'kavitha.iyer@ascend.gov.in', role:'Viewer', department:'Smart City PMU', status:'active', lastLogin:'3 hours ago', permissions:['dashboard','reports','gis'] },
  { id:'U-007', name:'Deepak Joshi', email:'deepak.joshi@ascend.gov.in', role:'Control Room Operator', department:'Central Operations', status:'inactive', lastLogin:'2 days ago', permissions:['dashboard','fleet','traffic','alerts'] },
];

// ─── Origin-Destination Flows ────────────────────────────────────────────────
export const odMatrix: ODMatrixItem[] = [
  { origin:'Majestic', destination:'Whitefield (ITPB)', passengerVolume:14200, peakTime:'08:30 - 10:00', primaryRoute:'Route 1' },
  { origin:'Yeshwanthpur', destination:'Silk Board Jn', passengerVolume:11800, peakTime:'09:00 - 10:30', primaryRoute:'Route 7' },
  { origin:'Shivajinagar', destination:'Electronic City Ph 1', passengerVolume:9600, peakTime:'08:00 - 09:30', primaryRoute:'Route 12' },
  { origin:'Kempegowda Int Airport', destination:'Majestic', passengerVolume:6400, peakTime:'18:00 - 21:00', primaryRoute:'Route 15' },
  { origin:'KR Puram', destination:'Electronic City Ph 2', passengerVolume:8200, peakTime:'08:45 - 10:15', primaryRoute:'Route 21' },
  { origin:'Hebbal Flyover', destination:'Whitefield', passengerVolume:5100, peakTime:'17:30 - 19:30', primaryRoute:'Route 34' },
];

// ─── Time-Series Chart Data ──────────────────────────────────────────────────
export const hourlyPassengerData = [
  { hour:'06:00', passengers:245, occupancy:42, boarding:180, alighting:65 },
  { hour:'07:00', passengers:412, occupancy:71, boarding:290, alighting:123 },
  { hour:'08:00', passengers:589, occupancy:98, boarding:380, alighting:203 },
  { hour:'09:00', passengers:521, occupancy:87, boarding:240, alighting:308 },
  { hour:'10:00', passengers:378, occupancy:63, boarding:150, alighting:293 },
  { hour:'11:00', passengers:312, occupancy:52, boarding:120, alighting:186 },
  { hour:'12:00', passengers:428, occupancy:71, boarding:230, alighting:114 },
  { hour:'13:00', passengers:445, occupancy:74, boarding:190, alighting:173 },
  { hour:'14:00', passengers:389, occupancy:65, boarding:140, alighting:196 },
  { hour:'15:00', passengers:356, occupancy:59, boarding:160, alighting:193 },
  { hour:'16:00', passengers:478, occupancy:80, boarding:260, alighting:138 },
  { hour:'17:00', passengers:612, occupancy:102, boarding:390, alighting:256 },
  { hour:'18:00', passengers:534, occupancy:89, boarding:280, alighting:358 },
  { hour:'19:00', passengers:423, occupancy:71, boarding:190, alighting:301 },
  { hour:'20:00', passengers:312, occupancy:52, boarding:110, alighting:221 },
  { hour:'21:00', passengers:198, occupancy:33, boarding:70, alighting:184 },
];

export const trafficHourlyData = [
  { hour:'06:00', vehicles:120, speed:58, density:22, cars:65, bikes:42, buses:8, trucks:5 },
  { hour:'07:00', vehicles:345, speed:38, density:62, cars:190, bikes:120, buses:22, trucks:13 },
  { hour:'08:00', vehicles:512, speed:18, density:94, cars:290, bikes:180, buses:28, trucks:14 },
  { hour:'09:00', vehicles:423, speed:24, density:78, cars:240, bikes:145, buses:25, trucks:13 },
  { hour:'10:00', vehicles:289, speed:42, density:54, cars:160, bikes:98, buses:18, trucks:13 },
  { hour:'11:00', vehicles:245, speed:48, density:45, cars:130, bikes:85, buses:15, trucks:15 },
  { hour:'12:00', vehicles:312, speed:38, density:58, cars:170, bikes:105, buses:20, trucks:17 },
  { hour:'13:00', vehicles:356, speed:34, density:66, cars:195, bikes:120, buses:22, trucks:19 },
  { hour:'14:00', vehicles:334, speed:36, density:62, cars:185, bikes:112, buses:21, trucks:16 },
  { hour:'15:00', vehicles:378, speed:32, density:70, cars:210, bikes:128, buses:24, trucks:16 },
  { hour:'16:00', vehicles:478, speed:22, density:88, cars:270, bikes:165, buses:26, trucks:17 },
  { hour:'17:00', vehicles:589, speed:14, density:98, cars:340, bikes:205, buses:30, trucks:14 },
  { hour:'18:00', vehicles:512, speed:18, density:94, cars:290, bikes:182, buses:26, trucks:14 },
  { hour:'19:00', vehicles:389, speed:28, density:72, cars:220, bikes:135, buses:22, trucks:12 },
  { hour:'20:00', vehicles:234, speed:48, density:44, cars:130, bikes:82, buses:14, trucks:8 },
  { hour:'21:00', vehicles:145, speed:62, density:27, cars:80, bikes:50, buses:10, trucks:5 },
];

export const routeDelayData = [
  { route:'Route 1', delay:8, onTime:92, passengers:380, speed:32 },
  { route:'Route 7', delay:22, onTime:68, passengers:412, speed:24 },
  { route:'Route 12', delay:35, onTime:45, passengers:345, speed:18 },
  { route:'Route 15', delay:5, onTime:95, passengers:198, speed:45 },
  { route:'Route 21', delay:12, onTime:82, passengers:289, speed:28 },
  { route:'Route 34', delay:0, onTime:100, passengers:156, speed:38 },
];

export const predictionData = {
  congestion: [
    { time:'Now', risk:62, actual:62 },
    { time:'+30m', risk:74, actual:null },
    { time:'+1h', risk:88, actual:null },
    { time:'+2h', risk:79, actual:null },
    { time:'+3h', risk:65, actual:null },
    { time:'+4h', risk:48, actual:null },
    { time:'+6h', risk:35, actual:null },
    { time:'+8h', risk:28, actual:null },
  ],
  passengerDemand: [
    { time:'Now', demand:423 },
    { time:'+30m', demand:478 },
    { time:'+1h', demand:560 },
    { time:'+2h', demand:630 },
    { time:'+3h', demand:595 },
    { time:'+4h', demand:440 },
    { time:'+6h', demand:310 },
    { time:'+8h', demand:190 },
  ],
  roadRisk: [
    { route:'Route 7', risk:78, reason:'Monsoon runoff + heavy axle load' },
    { route:'Route 12', risk:68, reason:'Existing surface micro-cracks' },
    { route:'Route 1', risk:52, reason:'Underpass water ponding' },
    { route:'Route 21', risk:34, reason:'Moderate wear corridor' },
    { route:'Route 15', risk:20, reason:'Concrete elevated structure' },
  ],
};

export const demoRoles = [
  'Transport Administrator',
  'Control Room Operator',
  'Traffic Officer',
  'Road Maintenance Officer',
  'Safety Officer',
];
