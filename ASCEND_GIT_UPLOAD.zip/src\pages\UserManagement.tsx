import { users } from '../data/mockData';

export default function UserManagement() {
  return (
    <div className="flex-1 overflow-y-auto p-4 lg:p-6 space-y-6 text-slate-900">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-3 border-b border-slate-200">
        <div>
          <div className="text-xs font-mono tracking-widest text-[#0284c7] uppercase font-bold">ACCESS GOVERNANCE</div>
          <h1 className="text-2xl lg:text-3xl font-black text-slate-900 mt-1">Users, Roles & Security Permissions</h1>
        </div>
      </div>

      <div className="liquid-glass rounded-3xl border border-slate-200 overflow-hidden shadow-md">
        <div className="divide-y divide-slate-100">
          {users.map(u => (
            <div key={u.id} className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-slate-50 font-mono text-xs">
              <div>
                <span className="font-bold text-slate-900">{u.name}</span> ({u.role})
                <div className="text-slate-500 text-[10px] mt-0.5">{u.email} · {u.department}</div>
              </div>
              <span className="text-[#059669] font-bold">● {u.status.toUpperCase()}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}