import { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import TopBar from './components/layout/TopBar';
import Sidebar from './components/layout/Sidebar';
import DemoScenarioBar from './components/demo/DemoScenarioBar';
import SecretApiKeyModal from './components/common/SecretApiKeyModal';
import { useEffect } from 'react';

import Landing from './pages/Landing';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import LiveFleet from './pages/LiveFleet';
import GISMap from './pages/GISMap';
import RoadDefects from './pages/RoadDefects';
import TrafficIntelligence from './pages/TrafficIntelligence';
import PassengerAnalytics from './pages/PassengerAnalytics';
import SafetyIncidents from './pages/SafetyIncidents';
import WomenSafety from './pages/WomenSafety';
import ANPREvidence from './pages/ANPREvidence';
import RouteAnalytics from './pages/RouteAnalytics';
import PredictiveAI from './pages/PredictiveAI';
import Reports from './pages/Reports';
import MaintenanceManagement from './pages/MaintenanceManagement';
import BusManagement from './pages/BusManagement';
import AlertCenter from './pages/AlertCenter';
import SystemHealth from './pages/SystemHealth';
import UserManagement from './pages/UserManagement';
import Settings from './pages/Settings';
import AIArchitecture from './pages/AIArchitecture';

function AppContent() {
  const { state } = useApp();

  // Sync theme with DOM root class
  useEffect(() => {
    if (state.theme === 'dark') {
      document.documentElement.classList.add('dark');
      document.documentElement.setAttribute('data-theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      document.documentElement.setAttribute('data-theme', 'light');
    }
  }, [state.theme]);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const { dispatch } = useApp();

  // Global Alt+F3 Key Listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.altKey && (e.key === 'F3' || e.code === 'F3' || e.keyCode === 114)) {
        e.preventDefault();
        dispatch({ type: 'TOGGLE_API_MODAL' });
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [dispatch]);

  if (state.page === 'landing') return <Landing />;
  if (state.page === 'login') return <Login />;

  const renderContent = () => {
    switch (state.page) {
      case 'dashboard': return <Dashboard />;
      case 'fleet': return <LiveFleet />;
      case 'gis': return <GISMap />;
      case 'road-defects': return <RoadDefects />;
      case 'traffic': return <TrafficIntelligence />;
      case 'passengers': return <PassengerAnalytics />;
      case 'safety': return <SafetyIncidents />;
      case 'women-safety': return <WomenSafety />;
      case 'anpr': return <ANPREvidence />;
      case 'route-analytics': return <RouteAnalytics />;
      case 'predictive': return <PredictiveAI />;
      case 'reports': return <Reports />;
      case 'maintenance': return <MaintenanceManagement />;
      case 'bus-management': return <BusManagement />;
      case 'alerts': return <AlertCenter />;
      case 'system-health': return <SystemHealth />;
      case 'ai-architecture': return <AIArchitecture />;
      case 'users': return <UserManagement />;
      case 'settings': return <Settings />;
      default: return <Dashboard />;
    }
  };

  return (
    <div className={`flex h-screen w-screen overflow-hidden font-sans liquid-canvas relative ${state.theme === 'dark' ? 'theme-dark text-slate-100' : 'text-slate-900'}`}>
      <div className="liquid-blob-center" />
      <Sidebar collapsed={sidebarCollapsed} onToggle={() => setSidebarCollapsed(!sidebarCollapsed)} />
      <div className="flex flex-col flex-1 h-full min-w-0 overflow-hidden relative z-10">
        <TopBar />
        <main key={state.page} className="nexus-page-enter flex-1 flex flex-col min-h-0 overflow-hidden relative">
          {renderContent()}
        </main>
      </div>
      <DemoScenarioBar />
      <SecretApiKeyModal />
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}