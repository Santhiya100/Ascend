import { useState } from 'react';
import { useApp } from '../context/AppContext';

export default function WomenSafety() {
  const { state, dispatch, triggerScenario } = useApp();
  const [selectedSosId, setSelectedSosId] = useState<string | null>(state.sosAlerts[0]?.id || null);

  const activeSOSList = state.sosAlerts.filter(s => s.status !== 'resolved');
  const resolvedSOSList = state.sosAlerts.filter(s => s.status === 'resolved');
  const activeSOS = state.sosAlerts.find(s => s.id === selectedSosId) || state.sosAlerts[0];

  const handleAdvanceStep = (index: number) => {
    if (!activeSOS) return;
    const updatedSteps = activeSOS.timelineSteps.map((step, idx) => {
      if (idx <= index) {
        return { ...step, done: true, time: step.time || new Date().toLocaleTimeString('en-IN') };
      }
      return step;
    });

    const isAllDone = updatedSteps.every(s => s.done);
    dispatch({
      type: 'UPDATE_SOS',
      id: activeSOS.id,
      update: {
        timelineSteps: updatedSteps,
        status: isAllDone ? 'resolved' : 'active',
      },
    });
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 lg:p-6 space-y-6 text-slate-900">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-3 border-b border-slate-200">
        <div>
          <div className="text-xs font-mono tracking-widest text-[#e11d48] uppercase font-bold flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-[#e11d48] animate-ping" />
            <span>CRITICAL SAFETY & DISTRESS RESPONSE (112 LINK)</span>
          </div>
          <h1 className="text-2xl lg:text-3xl font-black text-slate-900 mt-0.5 tracking-tight">
            Women Safety & Emergency SOS Dispatch
          </h1>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          <button
            onClick={() => triggerScenario('sos')}
            className="px-4 py-2 rounded-2xl font-bold font-mono text-xs uppercase bg-gradient-to-r from-[#e11d48] to-[#7c3aed] text-white animate-pulse liquid-btn shadow-md"
          >
            🚨 Trigger Simulated SOS
          </button>
        </div>
      </div>

      {activeSOS ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* Left: Active SOS Dispatch Dashboard */}
          <div className="lg:col-span-7 liquid-glass p-5 rounded-3xl border border-slate-200 shadow-xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div className="flex items-center gap-2">
                <span className="text-xl">🚨</span>
                <div>
                  <div className="text-sm font-bold text-slate-900 font-mono">
                    {activeSOS.id} · Bus {activeSOS.busId} ({activeSOS.route})
                  </div>
                  <div className="text-xs text-slate-500 font-mono mt-0.5">
                    📍 {activeSOS.location} · {activeSOS.gps}
                  </div>
                </div>
              </div>
              <span className="px-3 py-1 rounded-full text-xs font-mono font-bold bg-[#e11d48]/15 text-[#e11d48] border border-[#e11d48]/40 animate-pulse">
                {activeSOS.status.toUpperCase()}
              </span>
            </div>

            {/* 6-Stage Response Timeline */}
            <div className="space-y-3">
              <div className="text-xs font-mono font-bold text-slate-700 uppercase">
                6-Stage Automated Response Workflow
              </div>

              <div className="space-y-2">
                {activeSOS.timelineSteps.map((step, idx) => (
                  <div
                    key={step.label}
                    onClick={() => handleAdvanceStep(idx)}
                    className={'p-3 rounded-2xl border flex items-center justify-between cursor-pointer transition-all ' + (
                      step.done
                        ? 'bg-[#059669]/10 border-[#059669]/30 text-slate-900'
                        : 'bg-white/80 border-slate-200 text-slate-500 hover:border-[#0284c7]/50 hover:bg-white'
                    )}
                  >
                    <div className="flex items-center gap-3">
                      <span className={'w-6 h-6 rounded-xl flex items-center justify-center text-xs font-bold ' + (
                        step.done ? 'bg-[#059669] text-white shadow-sm' : 'bg-slate-100 text-slate-500'
                      )}>
                        {step.done ? '✓' : idx + 1}
                      </span>
                      <span className={'text-xs font-mono font-semibold ' + (step.done ? 'text-slate-900' : 'text-slate-600')}>
                        {step.label}
                      </span>
                    </div>
                    {step.time && (
                      <span className="text-[10px] font-mono text-slate-500 font-semibold">{step.time}</span>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right: Response Coordination Units */}
          <div className="lg:col-span-5 liquid-glass p-5 rounded-3xl border border-slate-200 shadow-xl space-y-4 flex flex-col justify-between">
            <div>
              <div className="pb-3 border-b border-slate-200">
                <div className="text-xs font-mono text-gradient-pink uppercase font-bold">EMERGENCY DISPATCH LINK</div>
                <h3 className="text-base font-bold text-slate-900 mt-0.5">Police & PCR Unit Tracking</h3>
              </div>

              <div className="space-y-3 mt-4 text-xs font-mono">
                <div className="p-3.5 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-1">
                  <div className="text-slate-500 text-[10px]">NEAREST PATROL UNIT</div>
                  <div className="text-sm font-bold text-slate-900">PCR Van #14 (Cubbon Park)</div>
                  <div className="text-[#059669] font-bold text-[10px]">ETA: 3 mins · Distance: 1.1 km</div>
                </div>

                <div className="p-3.5 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-1">
                  <div className="text-slate-500 text-[10px]">CABIN LIVE STATUS</div>
                  <div className="text-slate-900 font-bold">34 Passengers on Board</div>
                  <div className="text-[#0284c7] font-semibold text-[10px]">Live stream verified by Operator</div>
                </div>

                <div className="p-3.5 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-1">
                  <div className="text-slate-500 text-[10px]">INTEGRATED SAFETY PROTOCOL</div>
                  <div className="text-slate-700">112 Dispatch + Suraksha App Notification Triggered</div>
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-200">
              <button
                onClick={() => handleAdvanceStep(5)}
                className="w-full py-2.5 rounded-2xl font-bold font-mono text-xs uppercase text-white bg-gradient-to-r from-[#059669] to-[#0284c7] liquid-btn shadow-md"
              >
                Mark Incident Fully Resolved ✓
              </button>
            </div>
          </div>
        </div>
      ) : (
        <div className="liquid-glass p-12 rounded-3xl border border-slate-200 text-center space-y-3">
          <div className="text-4xl">🛡</div>
          <h2 className="text-lg font-bold text-slate-900">All Clear — Zero Active Distress Alerts</h2>
          <p className="text-xs text-slate-500 font-mono">All transit routes operating under normal security standards.</p>
        </div>
      )}

      {/* SOS History Table */}
      <div className="space-y-3">
        <h3 className="text-sm font-bold text-slate-900 uppercase font-mono tracking-wider">
          Distress Logs ({state.sosAlerts.length})
        </h3>
        <div className="liquid-glass rounded-3xl border border-slate-200 overflow-hidden shadow-md">
          <div className="divide-y divide-slate-100">
            {state.sosAlerts.map(s => (
              <div
                key={s.id}
                onClick={() => setSelectedSosId(s.id)}
                className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-50 cursor-pointer font-mono text-xs transition-colors"
              >
                <div className="space-y-0.5">
                  <span className="font-bold text-slate-900">{s.id}</span> · Bus {s.busId} ({s.route})
                  <div className="text-slate-500 text-[10px]">{s.location} · {s.alertSource}</div>
                </div>
                <div className="flex items-center gap-3">
                  <span className={'px-2.5 py-0.5 rounded-full text-[10px] font-bold ' + (
                    s.status === 'resolved' ? 'bg-[#059669]/10 text-[#059669]' : 'bg-[#e11d48]/15 text-[#e11d48] animate-pulse'
                  )}>
                    {s.status.toUpperCase()}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}