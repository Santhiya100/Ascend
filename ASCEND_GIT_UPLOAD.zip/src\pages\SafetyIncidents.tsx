import { useState } from 'react';
import { useApp } from '../context/AppContext';
import type { Incident } from '../data/mockData';

export default function SafetyIncidents() {
  const { state, dispatch, triggerScenario } = useApp();
  const [selectedIncident, setSelectedIncident] = useState<Incident | null>(state.incidents[0]);

  return (
    <div className="flex-1 overflow-y-auto p-4 lg:p-6 space-y-6" >
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-2 border-b" style={{ borderColor: '#e2e8f0' }}>
        <div>
          <div className="text-xs font-mono tracking-widest text-[#0284c7] uppercase">INCIDENT COMMAND & SAFETY</div>
          <h1 className="text-2xl lg:text-3xl font-black text-slate-900 mt-1">Safety Surveillance & Incident Triage</h1>
        </div>
        <button onClick={() => triggerScenario('school_zone')}
          className="px-3 py-1.5 rounded-lg border text-xs font-mono font-semibold text-[#d97706] hover:bg-amber-400/10"
          style={{ borderColor: '#f59e0b' }}>
          🚸 Simulate School Zone Hazard
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        <div className="lg:col-span-7 liquid-glass rounded-2xl border overflow-hidden" style={{ borderColor: '#e2e8f0' }}>
          <div className="p-4 border-b flex items-center justify-between" style={{ borderColor: '#e2e8f0' }}>
            <span className="text-xs font-mono font-bold uppercase text-slate-200">Incident Register ({state.incidents.length})</span>
          </div>
          <div className="divide-y divide-slate-100 overflow-y-auto max-h-[480px]">
            {state.incidents.map(inc => (
              <div key={inc.id} onClick={() => setSelectedIncident(inc)}
                className={'p-3.5 cursor-pointer hover:bg-white/5 flex items-center justify-between ' + (selectedIncident?.id === inc.id ? 'bg-cyan-500/10 border-l-4 border-cyan-400' : '')}>
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-bold text-slate-900 text-xs font-mono">{inc.id}</span>
                    <span className="text-[10px] font-mono font-bold text-[#d97706] uppercase">{inc.type}</span>
                  </div>
                  <p className="text-[11px] text-slate-500">{inc.description}</p>
                </div>
                <span className="text-xs font-mono uppercase text-[#0284c7] font-bold">{inc.status}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="lg:col-span-5 liquid-glass p-5 rounded-2xl border space-y-4" style={{ borderColor: '#e2e8f0' }}>
          {selectedIncident ? (
            <>
              <div className="text-xs font-mono text-[#0284c7] font-bold uppercase">INCIDENT DETAILS · {selectedIncident.id}</div>
              <h3 className="text-base font-bold text-slate-900">{selectedIncident.type}</h3>
              <p className="text-xs text-slate-300 font-mono">{selectedIncident.description}</p>
              <div className="p-3 rounded-xl bg-white/80 text-xs font-mono text-slate-500">
                GPS: {selectedIncident.lat}°N, {selectedIncident.lng}°E · Bus: {selectedIncident.busId}
              </div>
              <button onClick={() => dispatch({ type: 'UPDATE_INCIDENT', id: selectedIncident.id, update: { status: 'resolved' } })}
                className="w-full py-2 rounded-xl text-xs font-mono font-bold bg-emerald-500 text-black hover:bg-emerald-400">
                ✓ Mark Resolved
              </button>
            </>
          ) : null}
        </div>
      </div>
    </div>
  );
}