import { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from 'recharts';
import AnimatedCounter from '../components/common/AnimatedCounter';
import InteractiveLeafletMap from '../components/common/InteractiveLeafletMap';
import { hourlyPassengerData, trafficHourlyData, svgRoutes } from '../data/mockData';

export default function Dashboard() {
  const { state, dispatch, navigate, triggerScenario } = useApp();
  const [activeLayer, setActiveLayer] = useState<'all' | 'buses' | 'defects' | 'traffic'>('all');
  const [selectedBusHover, setSelectedBusHover] = useState<string | null>(null);
  const [mapMode, setMapMode] = useState<'leaflet' | 'vector'>('leaflet');

  const activeBuses = state.buses.filter(b => b.status !== 'offline');
  const activeSOS = state.sosAlerts.filter(s => s.status !== 'resolved');
  const unacknowledgedAlerts = state.alerts.filter(a => a.status === 'new');
  const totalOccupancy = state.buses.reduce((acc, b) => acc + b.passengers, 0);

  const kpis = [
    {
      id: 'active_fleet',
      label: 'ACTIVE FLEET',
      val: activeBuses.length,
      suffix: '/' + state.buses.length,
      color: '#0284c7',
      gradient: 'from-[#0284c7]/15 to-[#2563eb]/5',
      borderColor: 'border-[#0284c7]/30',
      icon: '🚌',
      delta: '100% ONLINE',
      page: 'fleet',
    },
    {
      id: 'potholes_logged',
      label: 'ROAD DEFECTS',
      val: state.defects.length,
      color: '#d97706',
      gradient: 'from-[#d97706]/15 to-[#e11d48]/5',
      borderColor: 'border-[#d97706]/30',
      icon: '⚠',
      delta: '+' + state.defects.filter(d => d.status === 'detected').length + ' NEW',
      page: 'road-defects',
    },
    {
      id: 'critical_sos',
      label: 'WOMEN SOS BEACON',
      val: activeSOS.length,
      color: activeSOS.length > 0 ? '#e11d48' : '#059669',
      gradient: activeSOS.length > 0 ? 'from-[#e11d48]/25 to-[#7c3aed]/10' : 'from-[#059669]/15 to-[#0284c7]/5',
      borderColor: activeSOS.length > 0 ? 'border-[#e11d48]' : 'border-[#059669]/30',
      icon: '🚨',
      delta: activeSOS.length > 0 ? 'CRITICAL DISPATCH' : 'ALL CLEAR',
      page: 'women-safety',
      isCritical: activeSOS.length > 0,
    },
    {
      id: 'passenger_load',
      label: 'PAX TRANSIT LOAD',
      val: totalOccupancy,
      color: '#0284c7',
      gradient: 'from-[#0284c7]/15 to-[#7c3aed]/5',
      borderColor: 'border-[#0284c7]/30',
      icon: '👥',
      delta: 'AVG 68% LOAD',
      page: 'passengers',
    },
    {
      id: 'traffic_hotspots',
      label: 'BOTTLENECKS',
      val: 4,
      color: '#e11d48',
      gradient: 'from-[#e11d48]/15 to-[#d97706]/5',
      borderColor: 'border-[#e11d48]/30',
      icon: '⬡',
      delta: 'SILK BOARD CONGESTION',
      page: 'traffic',
    },
    {
      id: 'anpr_matches',
      label: 'ANPR OCR MATCHES',
      val: state.anprList.length,
      color: '#7c3aed',
      gradient: 'from-[#7c3aed]/15 to-[#e11d48]/5',
      borderColor: 'border-[#7c3aed]/30',
      icon: '🔍',
      delta: '98.2% CONFIDENCE',
      page: 'anpr',
    },
    {
      id: 'work_orders',
      label: 'MUNICIPAL ORDERS',
      val: state.maintenance.filter(m => m.status !== 'completed').length,
      color: '#2563eb',
      gradient: 'from-[#2563eb]/15 to-[#0284c7]/5',
      borderColor: 'border-[#2563eb]/30',
      icon: '🛠',
      delta: 'BBMP DISPATCHED',
      page: 'maintenance',
    },
    {
      id: 'ai_latency',
      label: 'EDGE AI LATENCY',
      val: 18,
      suffix: 'ms',
      color: '#059669',
      gradient: 'from-[#059669]/15 to-[#0284c7]/5',
      borderColor: 'border-[#059669]/30',
      icon: '⚡',
      delta: 'JETSON FP16 TENSORRT',
      page: 'system-health',
    },
  ];

  return (
    <div className="flex-1 overflow-y-auto p-4 lg:p-6 space-y-6">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-3 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#0284c7] animate-blink shadow-[0_0_8px_#0284c7]" />
            <span className="text-xs font-mono tracking-widest text-gradient-cyan uppercase font-bold">
              CENTRAL URBAN INTELLIGENCE // LIGHT LIQUID MISSION CONTROL
            </span>
          </div>
          <h1 className="text-2xl lg:text-3xl font-black text-slate-900 mt-1 tracking-tight flex items-center gap-3">
            <span>Spatial AI Command Dashboard</span>
            <span className="text-xs px-2.5 py-0.5 rounded-full font-mono font-bold bg-gradient-to-r from-[#0284c7] to-[#7c3aed] text-white shadow-sm">
              LIVE
            </span>
          </h1>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          <button
            onClick={() => triggerScenario('pothole')}
            className="px-3.5 py-2 rounded-2xl border text-xs font-mono font-bold text-[#d97706] border-[#d97706]/30 bg-[#d97706]/10 hover:bg-[#d97706]/20 liquid-btn shadow-sm"
          >
            ⚠ Test Pothole
          </button>
          <button
            onClick={() => triggerScenario('traffic')}
            className="px-3.5 py-2 rounded-2xl border text-xs font-mono font-bold text-[#0284c7] border-[#0284c7]/30 bg-[#0284c7]/10 hover:bg-[#0284c7]/20 liquid-btn shadow-sm"
          >
            ⬡ Test Congestion
          </button>
          <button
            onClick={() => triggerScenario('sos')}
            className="px-4 py-2 rounded-2xl font-bold font-mono text-xs uppercase bg-gradient-to-r from-[#e11d48] via-[#7c3aed] to-[#0284c7] text-white animate-pulse liquid-btn shadow-md"
          >
            🚨 Trigger Women SOS
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 xl:grid-cols-8 gap-3.5">
        {kpis.map(k => (
          <div
            key={k.id}
            onClick={() => navigate(k.page as any)}
            className={'liquid-glass p-4 rounded-3xl border cursor-pointer liquid-glass-card relative overflow-hidden bg-gradient-to-b ' + k.gradient + ' ' + k.borderColor + ' ' + (
              k.isCritical ? 'animate-sos-alarm' : ''
            )}
          >
            <div className="flex items-center justify-between text-xs text-slate-500 mb-1.5">
              <span className="text-[10px] font-mono font-bold tracking-wider truncate">{k.label}</span>
              <span className="text-base">{k.icon}</span>
            </div>
            <div className="text-2xl font-black font-mono tracking-tight" style={{ color: k.color }}>
              <AnimatedCounter value={k.val} suffix={k.suffix || ''} />
            </div>
            <div className="text-[9px] font-mono mt-1 font-semibold text-slate-500 truncate">
              {k.delta}
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-7 liquid-glass p-5 rounded-3xl border border-slate-200/80 flex flex-col justify-between shadow-xl relative overflow-hidden">
          <div className="flex items-center justify-between mb-3 z-10">
            <div>
              <div className="text-xs font-mono text-gradient-cyan font-bold uppercase">GEOSPATIAL FLEET & INCIDENT MAP</div>
              <div className="text-xs text-slate-500 mt-0.5">10 AI Connected Buses · 6 Rapid Transit Corridors</div>
            </div>

            <div className="flex items-center gap-1 bg-white/80 p-1 rounded-2xl border border-slate-200 text-[10px] font-mono backdrop-blur-md shadow-sm">
              {(['all', 'buses', 'defects', 'traffic'] as const).map(l => (
                <button
                  key={l}
                  onClick={() => setActiveLayer(l)}
                  className="px-2.5 py-1 rounded-xl uppercase font-bold transition-all"
                  style={{
                    background: activeLayer === l ? 'linear-gradient(135deg, #0284c7, #2563eb)' : 'transparent',
                    color: activeLayer === l ? '#fff' : '#64748b',
                    boxShadow: activeLayer === l ? '0 2px 8px rgba(2, 132, 199, 0.3)' : 'none',
                  }}
                >
                  {l}
                </button>
              ))}
            </div>
          </div>

          <div className="relative rounded-2xl overflow-hidden border border-slate-200 bg-slate-50/80 shadow-inner"
            style={{ aspectRatio: '16/10' }}>
            <div className="absolute inset-0 hud-grid-bg opacity-40 pointer-events-none" />
            
            <svg viewBox="0 0 1000 650" className="w-full h-full">
              <defs>
                <linearGradient id="routeGradLight" x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0%" stopColor="#0284c7" />
                  <stop offset="50%" stopColor="#2563eb" />
                  <stop offset="100%" stopColor="#7c3aed" />
                </linearGradient>
              </defs>

              <circle cx="500" cy="325" r="140" fill="none" stroke="rgba(2, 132, 199, 0.15)" strokeWidth="1" strokeDasharray="4 4" />
              <circle cx="500" cy="325" r="240" fill="none" stroke="rgba(124, 58, 237, 0.12)" strokeWidth="1" strokeDasharray="6 6" />
              <circle cx="500" cy="325" r="340" fill="none" stroke="rgba(225, 29, 72, 0.1)" strokeWidth="1" strokeDasharray="8 8" />

              <g className="animate-radar">
                <line x1="500" y1="325" x2="500" y2="20" stroke="#0284c7" strokeWidth="2" opacity="0.6" />
                <polygon points="500,325 430,40 500,20" fill="rgba(2, 132, 199, 0.12)" />
              </g>

              {Object.entries(svgRoutes).map(([routeName, coords]) => {
                const pathStr = coords.map((pt, i) => `${i === 0 ? 'M' : 'L'} ${pt[0]} ${pt[1]}`).join(' ');
                return (
                  <g key={routeName}>
                    <path d={pathStr} fill="none" stroke="rgba(2, 132, 199, 0.2)" strokeWidth="6" strokeLinecap="round" />
                    <path d={pathStr} fill="none" stroke="url(#routeGradLight)" strokeWidth="2" strokeDasharray="8 6" opacity="0.9" />
                  </g>
                );
              })}

              {(activeLayer === 'all' || activeLayer === 'defects') &&
                state.defects.map(defect => {
                  const isCritical = defect.severity === 'critical';
                  const color = isCritical ? '#e11d48' : '#d97706';
                  return (
                    <g key={defect.id} className="cursor-pointer" onClick={() => navigate('road-defects')}>
                      <circle cx={defect.x} cy={defect.y} r="16" fill="none" stroke={color} strokeWidth="1.5" className="animate-pulse-ring" />
                      <circle cx={defect.x} cy={defect.y} r="6" fill={color} />
                      <text x={defect.x} y={defect.y - 10} fill={color} fontSize="9.5" fontFamily="JetBrains Mono" fontWeight="bold" textAnchor="middle">
                        {defect.type.toUpperCase().slice(0, 4)}
                      </text>
                    </g>
                  );
                })}

              {(activeLayer === 'all' || activeLayer === 'buses') &&
                state.buses.map(bus => {
                  const isSelected = selectedBusHover === bus.id;
                  const isCritical = bus.status === 'critical';
                  const color = isCritical ? '#e11d48' : '#0284c7';

                  return (
                    <g
                      key={bus.id}
                      className="cursor-pointer transition-all duration-700"
                      onMouseEnter={() => setSelectedBusHover(bus.id)}
                      onMouseLeave={() => setSelectedBusHover(null)}
                      onClick={() => { dispatch({ type: 'SELECT_BUS', id: bus.id }); navigate('fleet'); }}
                    >
                      <circle cx={bus.x} cy={bus.y} r="18" fill="none" stroke={color} strokeWidth="1.5" opacity="0.4" className="animate-pulse" />
                      <circle cx={bus.x} cy={bus.y} r="8" fill={color} />
                      <rect x={bus.x - 20} y={bus.y - 26} width="40" height="15" rx="5" fill="#ffffff" stroke={color} strokeWidth="1.5" shadow="md" />
                      <text x={bus.x} y={bus.y - 15} fill={color} fontSize="9" fontFamily="JetBrains Mono" fontWeight="bold" textAnchor="middle">
                        {bus.id}
                      </text>

                      {isSelected && (
                        <g>
                          <rect x={bus.x - 65} y={bus.y + 14} width="130" height="46" rx="8" fill="#ffffff" stroke="#0284c7" strokeWidth="1.5" />
                          <text x={bus.x} y={bus.y + 30} fill="#0f172a" fontSize="9.5" fontFamily="JetBrains Mono" fontWeight="bold" textAnchor="middle">
                            {bus.id} · {bus.route}
                          </text>
                          <text x={bus.x} y={bus.y + 44} fill="#0284c7" fontSize="8.5" fontFamily="JetBrains Mono" textAnchor="middle">
                            {bus.speed} km/h · {bus.passengers}/{bus.capacity} pax
                          </text>
                        </g>
                      )}
                    </g>
                  );
                })}
            </svg>

            <div className="absolute bottom-3 left-3 flex items-center gap-3 px-3.5 py-2 rounded-2xl bg-white/90 border border-slate-200 text-[10px] font-mono backdrop-blur-md shadow-md">
              <span className="flex items-center gap-1.5 text-[#0284c7] font-bold"><span className="w-2.5 h-2.5 rounded-full bg-[#0284c7] shadow-[0_0_8px_#0284c7]" /> Transit Bus</span>
              <span className="flex items-center gap-1.5 text-[#d97706] font-bold"><span className="w-2.5 h-2.5 rounded-full bg-[#d97706] shadow-[0_0_8px_#d97706]" /> Road Hazard</span>
              <span className="flex items-center gap-1.5 text-[#e11d48] font-bold"><span className="w-2.5 h-2.5 rounded-full bg-[#e11d48] shadow-[0_0_8px_#e11d48]" /> Critical SOS</span>
            </div>
          </div>
        </div>

        <div className="lg:col-span-5 liquid-glass p-5 rounded-3xl border border-slate-200/80 flex flex-col justify-between shadow-xl">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div>
                <div className="text-xs font-mono text-gradient-pink font-bold uppercase">REAL-TIME INCIDENT FEED</div>
                <div className="text-xs text-slate-500 mt-0.5">{unacknowledgedAlerts.length} Actionable Events Pending</div>
              </div>
              <button onClick={() => navigate('alerts')} className="text-[11px] font-mono text-[#0284c7] font-bold hover:underline">
                View All Stream →
              </button>
            </div>

            <div className="divide-y divide-slate-100 overflow-y-auto max-h-[380px] space-y-1.5 mt-2.5">
              {state.alerts.slice(0, 5).map(alert => {
                const isCritical = alert.severity === 'critical';
                const isWarning = alert.severity === 'high';
                const color = isCritical ? '#e11d48' : isWarning ? '#d97706' : '#0284c7';
                return (
                  <div key={alert.id} className="py-3 px-2.5 hover:bg-slate-50 rounded-2xl transition-all flex items-start justify-between gap-3">
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="w-2.5 h-2.5 rounded-full shadow-sm" style={{ background: color }} />
                        <span className="font-bold text-slate-900 text-xs font-mono">{alert.type}</span>
                        <span
                          className="text-[9px] font-mono uppercase px-2 py-0.5 rounded-full font-bold shadow-sm"
                          style={{
                            background: isCritical ? 'rgba(225,29,72,0.15)' : 'rgba(217,119,6,0.15)',
                            color: color,
                            border: '1px solid ' + color + '40',
                          }}
                        >
                          {alert.severity}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-600 line-clamp-1">{alert.description}</p>
                      <div className="text-[9.5px] text-slate-400 font-mono mt-0.5">
                        📍 {alert.location} · Bus {alert.busId}
                      </div>
                    </div>
                    <div className="flex flex-col items-end gap-1 flex-shrink-0">
                      {alert.status === 'new' ? (
                        <button
                          onClick={() => dispatch({ type: 'ACKNOWLEDGE_ALERT', id: alert.id })}
                          className="px-2.5 py-1 rounded-xl text-[10px] font-mono font-bold text-[#0284c7] bg-[#0284c7]/10 border border-[#0284c7]/30 hover:bg-[#0284c7]/20 liquid-btn shadow-sm"
                        >
                          Acknowledge
                        </button>
                      ) : (
                        <span className="text-[10px] font-mono uppercase text-[#059669] font-bold">✓ Triage</span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
          <div className="pt-3 border-t border-slate-200 text-right">
            <span className="text-[10px] font-mono text-slate-400">Autonomous Edge Ingestion Rate: 120 frames/sec</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="liquid-glass p-5 rounded-3xl border border-slate-200/80 shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <div>
              <div className="text-xs font-mono text-gradient-cyan uppercase font-bold">PASSENGER MOBILITY WAVE</div>
              <h3 className="text-sm font-bold text-slate-900 mt-0.5">Boarding vs Alighting Flux</h3>
            </div>
            <span className="text-xs font-mono text-slate-500 font-semibold">Total Today: 3,420 pax</span>
          </div>
          <div className="h-60 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={hourlyPassengerData}>
                <defs>
                  <linearGradient id="boardGradLight" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#0284c7" stopOpacity="0.4" />
                    <stop offset="95%" stopColor="#0284c7" stopOpacity="0.05" />
                  </linearGradient>
                  <linearGradient id="alightGradLight" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#e11d48" stopOpacity="0.4" />
                    <stop offset="95%" stopColor="#e11d48" stopOpacity="0.05" />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(226, 232, 240, 0.8)" />
                <XAxis dataKey="hour" stroke="#64748b" fontSize={10} fontFamily="JetBrains Mono" />
                <YAxis stroke="#64748b" fontSize={10} fontFamily="JetBrains Mono" />
                <Tooltip contentStyle={{ background: '#ffffff', border: '1px solid #0284c7', borderRadius: '16px', color: '#0f172a', fontFamily: 'JetBrains Mono', fontSize: '11px', boxShadow: '0 10px 30px rgba(0,0,0,0.1)' }} />
                <Area type="monotone" dataKey="boarding" stroke="#0284c7" strokeWidth="3" fill="url(#boardGradLight)" name="Boarding" animationDuration="900" />
                <Area type="monotone" dataKey="alighting" stroke="#e11d48" strokeWidth="3" fill="url(#alightGradLight)" name="Alighting" animationDuration="900" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="liquid-glass p-5 rounded-3xl border border-slate-200/80 shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <div>
              <div className="text-xs font-mono text-gradient-pink uppercase font-bold">SPATIAL VELOCITY CORRELATION</div>
              <h3 className="text-sm font-bold text-slate-900 mt-0.5">Traffic Density vs Fleet Speed</h3>
            </div>
            <span className="text-xs font-mono text-[#059669] font-bold">Avg City Speed: 34.2 km/h</span>
          </div>
          <div className="h-60 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={trafficHourlyData}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(226, 232, 240, 0.8)" />
                <XAxis dataKey="hour" stroke="#64748b" fontSize={10} fontFamily="JetBrains Mono" />
                <YAxis yAxisId="left" stroke="#e11d48" fontSize={10} fontFamily="JetBrains Mono" />
                <YAxis yAxisId="right" orientation="right" stroke="#059669" fontSize={10} fontFamily="JetBrains Mono" />
                <Tooltip contentStyle={{ background: '#ffffff', border: '1px solid #0284c7', borderRadius: '16px', color: '#0f172a', fontFamily: 'JetBrains Mono', fontSize: '11px', boxShadow: '0 10px 30px rgba(0,0,0,0.1)' }} />
                <Line yAxisId="left" type="monotone" dataKey="density" stroke="#e11d48" strokeWidth="3" dot={false} name="Density %" animationDuration="1000" />
                <Line yAxisId="right" type="monotone" dataKey="speed" stroke="#059669" strokeWidth="3" dot={false} name="Fleet Speed (km/h)" animationDuration="1000" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
}