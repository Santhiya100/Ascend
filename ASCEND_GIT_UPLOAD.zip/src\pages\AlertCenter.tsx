import { useState } from 'react';
import { useApp } from '../context/AppContext';

export default function AlertCenter() {
  const { state, dispatch } = useApp();
  const [filter, setFilter] = useState('all');

  const filtered = state.alerts.filter(a => filter === 'all' || a.severity === filter);

  return (
    <div className="flex-1 overflow-y-auto p-4 lg:p-6 space-y-6" >
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-2 border-b" style={{ borderColor: '#e2e8f0' }}>
        <div>
          <div className="text-xs font-mono tracking-widest text-[#0284c7] uppercase">CENTRAL ALERT TRIAGE</div>
          <h1 className="text-2xl lg:text-3xl font-black text-slate-900 mt-1">Alert Center & Notification Stream</h1>
        </div>
      </div>

      <div className="liquid-glass rounded-2xl border overflow-hidden" style={{ borderColor: '#e2e8f0' }}>
        <div className="divide-y divide-slate-100">
          {filtered.map(alert => (
            <div key={alert.id} className="p-4 hover:bg-white/5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="font-bold text-slate-900 text-xs">{alert.type}</span>
                  <span className="text-[10px] font-mono px-1.5 py-0.2 rounded font-bold text-slate-900"
                    style={{ background: alert.severity === 'critical' ? '#ef4444' : '#f59e0b' }}>
                    {alert.severity.toUpperCase()}
                  </span>
                </div>
                <p className="text-xs text-slate-300">{alert.description}</p>
                <div className="text-[10px] text-slate-500 font-mono mt-1">📍 {alert.location}</div>
              </div>
              <div className="flex gap-2 font-mono text-xs">
                {alert.status === 'new' && (
                  <button onClick={() => dispatch({ type: 'ACKNOWLEDGE_ALERT', id: alert.id })}
                    className="px-3 py-1 rounded-lg border text-[#0284c7] hover:bg-cyan-500/10">
                    Acknowledge
                  </button>
                )}
                {alert.status !== 'resolved' && (
                  <button onClick={() => dispatch({ type: 'RESOLVE_ALERT', id: alert.id })}
                    className="px-3 py-1 rounded-lg bg-emerald-500 text-black font-bold">
                    Resolve
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}