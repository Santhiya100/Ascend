export default function Reports() {
  const reports = [
    { title: 'Daily Transport Operations Summary', period: 'Last 24 Hours', format: 'PDF / CSV' },
    { title: 'Pothole & Road Quality Infrastructure Audit', period: 'Weekly (BBMP)', format: 'PDF / GeoJSON' },
    { title: 'Traffic Bottleneck & Signal Optimization Report', period: 'Monthly (BTP)', format: 'PDF / CSV' },
  ];

  return (
    <div className="flex-1 overflow-y-auto p-4 lg:p-6 space-y-6" >
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-2 border-b" style={{ borderColor: '#e2e8f0' }}>
        <div>
          <div className="text-xs font-mono tracking-widest text-[#0284c7] uppercase">EXECUTIVE REPORTING</div>
          <h1 className="text-2xl lg:text-3xl font-black text-slate-900 mt-1">Automated Intelligence Reports</h1>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {reports.map(r => (
          <div key={r.title} className="liquid-glass p-5 rounded-2xl border space-y-3" style={{ borderColor: '#e2e8f0' }}>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded text-[#0284c7] bg-cyan-500/10 border border-cyan-500/30">
              {r.format}
            </span>
            <h3 className="text-sm font-bold text-slate-900">{r.title}</h3>
            <button onClick={() => alert('Downloading ' + r.title + '...')}
              className="w-full py-2 rounded-xl text-xs font-mono font-bold bg-cyan-400 text-black hover:bg-cyan-300">
              Download Dossier
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}