import { useState } from 'react';

export default function Settings() {
  const [city, setCity] = useState('Bengaluru');
  const [alertThreshold, setAlertThreshold] = useState(85);

  return (
    <div className="flex-1 overflow-y-auto p-4 lg:p-6 space-y-6 text-slate-900">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-3 border-b border-slate-200">
        <div>
          <div className="text-xs font-mono tracking-widest text-[#0284c7] uppercase font-bold">CONFIGURATION MESH</div>
          <h1 className="text-2xl lg:text-3xl font-black text-slate-900 mt-1">City Parameters & Telemetry Config</h1>
        </div>
      </div>

      <div className="liquid-glass p-6 rounded-3xl border border-slate-200 shadow-md space-y-4 max-w-2xl font-mono text-xs">
        <div>
          <label className="block text-slate-700 font-bold mb-1">Target Sector / Urban Grid</label>
          <input
            type="text"
            value={city}
            onChange={e => setCity(e.target.value)}
            className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 bg-white text-slate-900 shadow-inner"
          />
        </div>

        <div>
          <label className="block text-slate-700 font-bold mb-1">AI Detection Confidence Threshold ({alertThreshold}%)</label>
          <input
            type="range"
            min="60"
            max="99"
            value={alertThreshold}
            onChange={e => setAlertThreshold(Number(e.target.value))}
            className="w-full accent-[#0284c7]"
          />
        </div>

        <button className="px-6 py-2.5 rounded-2xl font-bold bg-[#0284c7] text-white liquid-btn shadow-md">
          Save Mesh Parameters ➔
        </button>
      </div>
    </div>
  );
}