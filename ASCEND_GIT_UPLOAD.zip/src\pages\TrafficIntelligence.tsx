import { useApp } from '../context/AppContext';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { trafficHourlyData } from '../data/mockData';

export default function TrafficIntelligence() {
  const { triggerScenario } = useApp();

  return (
    <div className="flex-1 overflow-y-auto p-4 lg:p-6 space-y-6 text-slate-900">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-3 border-b border-slate-200">
        <div>
          <div className="text-xs font-mono tracking-widest text-[#0284c7] uppercase font-bold">
            MULTIMODAL MOBILITY ANALYTICS
          </div>
          <h1 className="text-2xl lg:text-3xl font-black text-slate-900 mt-0.5 tracking-tight">
            Traffic Intelligence & Congestion Hotspots
          </h1>
        </div>

        <button
          onClick={() => triggerScenario('traffic')}
          className="px-4 py-2 rounded-2xl font-bold font-mono text-xs uppercase bg-gradient-to-r from-[#0284c7] to-[#7c3aed] text-white liquid-btn shadow-md"
        >
          ⬡ Trigger Congestion Surge
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="liquid-glass p-5 rounded-3xl border border-slate-200 shadow-xl space-y-3">
          <div className="text-xs font-mono text-gradient-cyan font-bold uppercase">24-HOUR TRAFFIC FLUX</div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={trafficHourlyData}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(226, 232, 240, 0.8)" />
                <XAxis dataKey="hour" stroke="#64748b" fontSize={10} fontFamily="JetBrains Mono" />
                <YAxis stroke="#64748b" fontSize={10} fontFamily="JetBrains Mono" />
                <Tooltip contentStyle={{ background: '#ffffff', border: '1px solid #0284c7', borderRadius: '16px', color: '#0f172a', fontFamily: 'JetBrains Mono', fontSize: '11px', boxShadow: '0 10px 30px rgba(0,0,0,0.1)' }} />
                <Bar dataKey="density" fill="#0284c7" radius={[6, 6, 0, 0]} name="Density %" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="liquid-glass p-5 rounded-3xl border border-slate-200 shadow-xl space-y-4">
          <div className="text-xs font-mono text-gradient-pink font-bold uppercase">MAJOR BOTTLENECK ZONES</div>
          <div className="space-y-3 text-xs font-mono">
            {[
              { loc: 'Silk Board Flyover', level: '98% Congestion', speed: '6 km/h', color: '#e11d48' },
              { loc: 'Tin Factory Junction', level: '86% Congestion', speed: '12 km/h', color: '#d97706' },
              { loc: 'Hebbal Flyover Ramp', level: '74% Congestion', speed: '18 km/h', color: '#0284c7' },
              { loc: 'Sony World Signal Koramangala', level: '68% Congestion', speed: '22 km/h', color: '#059669' },
            ].map(b => (
              <div key={b.loc} className="p-3.5 rounded-2xl bg-white border border-slate-200 shadow-sm flex items-center justify-between">
                <div>
                  <div className="font-bold text-slate-900">{b.loc}</div>
                  <div className="text-slate-500 text-[10px] mt-0.5">Avg Fleet Speed: {b.speed}</div>
                </div>
                <span className="px-2.5 py-1 rounded-full font-bold text-[10px]" style={{ background: b.color + '18', color: b.color }}>
                  {b.level}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}