import { useState } from 'react';
import { useApp } from '../context/AppContext';

export default function RoadDefects() {
  const { state, dispatch, triggerScenario } = useApp();
  const [filterSeverity, setFilterSeverity] = useState<'all' | 'critical' | 'high' | 'medium'>('all');

  const filteredDefects = state.defects.filter(d => filterSeverity === 'all' || d.severity === filterSeverity);

  return (
    <div className="flex-1 overflow-y-auto p-4 lg:p-6 space-y-6 text-slate-900">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-3 border-b border-slate-200">
        <div>
          <div className="text-xs font-mono tracking-widest text-[#d97706] uppercase font-bold">
            INFRASTRUCTURE CV DETECTION
          </div>
          <h1 className="text-2xl lg:text-3xl font-black text-slate-900 mt-0.5 tracking-tight">
            Road Surface Defects & Hazard Triage
          </h1>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          <button
            onClick={() => triggerScenario('pothole')}
            className="px-3.5 py-2 rounded-2xl border text-xs font-mono font-bold text-[#d97706] border-[#d97706]/30 bg-[#d97706]/10 hover:bg-[#d97706]/20 liquid-btn shadow-sm"
          >
            ⚠ Simulate Pothole
          </button>
          <button
            onClick={() => triggerScenario('waterlogging')}
            className="px-3.5 py-2 rounded-2xl border text-xs font-mono font-bold text-[#0284c7] border-[#0284c7]/30 bg-[#0284c7]/10 hover:bg-[#0284c7]/20 liquid-btn shadow-sm"
          >
            🌊 Simulate Waterlogging
          </button>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 text-xs font-mono">
        {(['all', 'critical', 'high', 'medium'] as const).map(sev => (
          <button
            key={sev}
            onClick={() => setFilterSeverity(sev)}
            className={'px-3.5 py-1.5 rounded-2xl font-bold uppercase transition-all ' + (
              filterSeverity === sev ? 'bg-[#0284c7] text-white shadow-md' : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
            )}
          >
            {sev} ({sev === 'all' ? state.defects.length : state.defects.filter(d => d.severity === sev).length})
          </button>
        ))}
      </div>

      {/* Defects Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredDefects.map(d => {
          const isCritical = d.severity === 'critical';
          return (
            <div key={d.id} className="liquid-glass p-5 rounded-3xl border border-slate-200 shadow-md space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono font-bold text-slate-900 uppercase">{d.type} ({d.id})</span>
                <span className={'px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold ' + (
                  isCritical ? 'bg-[#e11d48]/15 text-[#e11d48]' : 'bg-[#d97706]/15 text-[#d97706]'
                )}>
                  {d.severity.toUpperCase()}
                </span>
              </div>

              <div className="text-xs text-slate-600 font-mono space-y-1">
                <div>📍 {d.location}</div>
                <div>AI Confidence: <strong className="text-slate-900">{d.confidence}%</strong></div>
                <div>Detected by Bus: <strong className="text-slate-900">{d.detectedByBus}</strong></div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                <span className="text-[10px] font-mono text-slate-400">Status: {d.status.toUpperCase()}</span>
                <button
                  onClick={() => dispatch({ type: 'UPDATE_DEFECT', id: d.id, update: { status: 'verified' } })}
                  className="px-3 py-1.5 rounded-xl text-xs font-mono font-bold bg-[#0284c7] text-white liquid-btn shadow-sm"
                >
                  Verify & Dispatch ➔
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}