import { createContext, useContext, useReducer, useEffect, useRef, type ReactNode } from 'react';
import {
  initialBuses, initialAlerts, initialDefects, initialIncidents,
  initialSOS, initialMaintenance, anprEvents,
  type Bus, type Alert, type RoadDefect, type Incident, type SOSAlert, type MaintenanceTask, type ANPREvent,
} from '../data/mockData';
import { playAlertChime, playSosAlarm, playUiClick } from '../utils/audio';

export type Page =
  | 'landing' | 'login' | 'dashboard' | 'fleet' | 'gis' | 'road-defects'
  | 'traffic' | 'passengers' | 'safety' | 'women-safety' | 'anpr'
  | 'route-analytics' | 'predictive' | 'reports' | 'maintenance'
  | 'bus-management' | 'alerts' | 'system-health' | 'users' | 'settings'
  | 'ai-architecture';

export interface AppState {
  page: Page;
  isLoggedIn: boolean;
  userRole: string;
  userName: string;
  buses: Bus[];
  alerts: Alert[];
  defects: RoadDefect[];
  incidents: Incident[];
  sosAlerts: SOSAlert[];
  maintenance: MaintenanceTask[];
  anprList: ANPREvent[];
  simulationRunning: boolean;
  totalPassengers: number;
  activeSOSCount: number;
  notificationCount: number;
  selectedBusId: string | null;
  demoMode: boolean;
  currentDemoScenario: string | null;
  audioMuted: boolean;
  simulationSpeed: number; // 1x, 2x, 5x
  apiKey: string;
  isAiKeyActive: boolean;
  apiModalOpen: boolean;
  theme: 'light' | 'dark';
}

export type Action =
  | { type: 'SET_PAGE'; page: Page }
  | { type: 'LOGIN'; role: string; name: string }
  | { type: 'LOGOUT' }
  | { type: 'TOGGLE_SIMULATION' }
  | { type: 'SET_SIMULATION_SPEED'; speed: number }
  | { type: 'TOGGLE_AUDIO' }
  | { type: 'RESET_DEMO' }
  | { type: 'SET_API_KEY'; key: string }
  | { type: 'CLEAR_API_KEY' }
  | { type: 'TOGGLE_API_MODAL' }
  | { type: 'SET_API_MODAL'; open: boolean }
  | { type: 'TOGGLE_THEME' }
  | { type: 'SET_THEME'; theme: 'light' | 'dark' }
  | { type: 'UPDATE_BUSES'; buses: Bus[] }
  | { type: 'ADD_ALERT'; alert: Alert }
  | { type: 'ACKNOWLEDGE_ALERT'; id: string }
  | { type: 'RESOLVE_ALERT'; id: string }
  | { type: 'ADD_SOS'; sos: SOSAlert }
  | { type: 'UPDATE_SOS'; id: string; update: Partial<SOSAlert> }
  | { type: 'UPDATE_DEFECT'; id: string; update: Partial<RoadDefect> }
  | { type: 'ADD_DEFECT'; defect: RoadDefect }
  | { type: 'UPDATE_INCIDENT'; id: string; update: Partial<Incident> }
  | { type: 'ADD_INCIDENT'; incident: Incident }
  | { type: 'ADD_MAINTENANCE'; task: MaintenanceTask }
  | { type: 'UPDATE_MAINTENANCE'; id: string; update: Partial<MaintenanceTask> }
  | { type: 'UPDATE_ANPR'; id: string; update: Partial<ANPREvent> }
  | { type: 'SELECT_BUS'; id: string | null }
  | { type: 'SIMULATE_PASSENGER_EVENT'; busId: string; boardingDelta: number; alightingDelta: number }
  | { type: 'TRIGGER_SCENARIO'; scenario: string }
  | { type: 'STOP_DEMO' }
  | { type: 'TICK' };

const initialState: AppState = {
  page: 'landing',
  isLoggedIn: false,
  userRole: '',
  userName: '',
  buses: initialBuses,
  alerts: initialAlerts,
  defects: initialDefects,
  incidents: initialIncidents,
  sosAlerts: initialSOS,
  maintenance: initialMaintenance,
  anprList: anprEvents,
  simulationRunning: false,
  totalPassengers: initialBuses.reduce((s, b) => s + b.passengers, 0),
  activeSOSCount: initialSOS.filter(s => s.status !== 'resolved').length,
  notificationCount: initialAlerts.filter(a => a.status === 'new').length,
  selectedBusId: 'B-104',
  demoMode: false,
  currentDemoScenario: null,
  audioMuted: false,
  simulationSpeed: 1,
  apiKey: typeof localStorage !== 'undefined' ? localStorage.getItem('ascend_ai_api_key') || '' : '',
  isAiKeyActive: typeof localStorage !== 'undefined' ? Boolean(localStorage.getItem('ascend_ai_api_key')) : false,
  apiModalOpen: false,
  theme: typeof localStorage !== 'undefined' && localStorage.getItem('ascend_theme') === 'dark' ? 'dark' : 'light',
};

function moveBus(bus: Bus): Bus {
  if (bus.status === 'offline') return bus;
  const jitter = (n: number, range: number) => n + (Math.random() - 0.5) * range;
  const newX = Math.max(50, Math.min(950, jitter(bus.x, 10)));
  const newY = Math.max(50, Math.min(650, jitter(bus.y, 8)));
  const newSpeed = Math.max(0, Math.min(70, jitter(bus.speed, 6)));
  const passDelta = Math.round((Math.random() - 0.45) * 3);
  const newPassengers = Math.max(2, Math.min(bus.capacity, bus.passengers + passDelta));
  const occupancyRatio = newPassengers / bus.capacity;
  
  const newStatus: Bus['status'] = bus.status === 'offline' ? 'offline'
    : occupancyRatio > 0.92 ? 'warning'
    : newSpeed === 0 && bus.status === 'critical' ? 'critical'
    : 'normal';

  const newProgress = (bus.routeProgress + 2) % 100;
  const newHeading = (bus.heading + Math.round((Math.random() - 0.5) * 20)) % 360;

  return {
    ...bus,
    x: newX,
    y: newY,
    speed: Math.round(newSpeed),
    passengers: newPassengers,
    status: newStatus,
    routeProgress: newProgress,
    heading: newHeading,
    cpuUsage: Math.min(98, Math.max(30, bus.cpuUsage + Math.round((Math.random() - 0.5) * 6))),
    temperature: Math.min(75, Math.max(38, bus.temperature + Math.round((Math.random() - 0.5) * 2))),
  };
}

function reducer(state: AppState, action: Action): AppState {
  switch (action.type) {
    case 'SET_PAGE':
      playUiClick();
      return { ...state, page: action.page };

    case 'LOGIN':
      playAlertChime();
      return { ...state, isLoggedIn: true, userRole: action.role, userName: action.name, page: 'dashboard' };

    case 'LOGOUT':
      playUiClick();
      return { ...state, isLoggedIn: false, userRole: '', userName: '', page: 'landing' };

    case 'TOGGLE_SIMULATION':
      playUiClick();
      return { ...state, simulationRunning: !state.simulationRunning };

    case 'SET_SIMULATION_SPEED':
      return { ...state, simulationSpeed: action.speed };

    case 'TOGGLE_AUDIO':
      return { ...state, audioMuted: !state.audioMuted };

    case 'SET_API_KEY':
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem('ascend_ai_api_key', action.key);
      }
      playAlertChime();
      return { ...state, apiKey: action.key, isAiKeyActive: true };

    case 'CLEAR_API_KEY':
      if (typeof localStorage !== 'undefined') {
        localStorage.removeItem('ascend_ai_api_key');
      }
      playUiClick();
      return { ...state, apiKey: '', isAiKeyActive: false };

    case 'TOGGLE_API_MODAL':
      playUiClick();
      return { ...state, apiModalOpen: !state.apiModalOpen };

    case 'SET_API_MODAL':
      return { ...state, apiModalOpen: action.open };

    case 'TOGGLE_THEME': {
      const nextTheme = state.theme === 'light' ? 'dark' : 'light';
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem('ascend_theme', nextTheme);
      }
      playUiClick();
      return { ...state, theme: nextTheme };
    }

    case 'SET_THEME': {
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem('ascend_theme', action.theme);
      }
      playUiClick();
      return { ...state, theme: action.theme };
    }

    case 'RESET_DEMO':
      playAlertChime();
      return {
        ...state,
        buses: initialBuses,
        alerts: initialAlerts,
        defects: initialDefects,
        incidents: initialIncidents,
        sosAlerts: initialSOS,
        maintenance: initialMaintenance,
        anprList: anprEvents,
        currentDemoScenario: null,
        demoMode: false,
        notificationCount: initialAlerts.filter(a => a.status === 'new').length,
        activeSOSCount: initialSOS.filter(s => s.status !== 'resolved').length,
      };

    case 'UPDATE_BUSES':
      return { ...state, buses: action.buses };

    case 'ADD_ALERT': {
      playAlertChime();
      const newAlerts = [action.alert, ...state.alerts];
      return { ...state, alerts: newAlerts, notificationCount: state.notificationCount + 1 };
    }

    case 'ACKNOWLEDGE_ALERT':
      playUiClick();
      return { ...state, alerts: state.alerts.map(a => a.id === action.id ? { ...a, status: 'acknowledged' } : a) };

    case 'RESOLVE_ALERT':
      playUiClick();
      return {
        ...state,
        alerts: state.alerts.map(a => a.id === action.id ? { ...a, status: 'resolved' } : a),
        notificationCount: Math.max(0, state.notificationCount - 1),
      };

    case 'ADD_SOS': {
      playSosAlarm();
      const newSOS = [action.sos, ...state.sosAlerts];
      const newAlert: Alert = {
        id: `ALT-SOS-${Date.now()}`,
        type: 'CRITICAL SOS ALERT',
        category: 'sos',
        severity: 'critical',
        busId: action.sos.busId,
        location: action.sos.location,
        lat: 12.9716,
        lng: 77.5946,
        timestamp: new Date(),
        status: 'new',
        description: `Passenger SOS triggered on ${action.sos.busId} (${action.sos.route}). Source: ${action.sos.alertSource}.`,
      };
      return {
        ...state,
        sosAlerts: newSOS,
        alerts: [newAlert, ...state.alerts],
        activeSOSCount: state.activeSOSCount + 1,
        notificationCount: state.notificationCount + 1,
      };
    }

    case 'UPDATE_SOS':
      playUiClick();
      return {
        ...state,
        sosAlerts: state.sosAlerts.map(s => s.id === action.id ? { ...s, ...action.update } : s),
        activeSOSCount: state.sosAlerts.map(s => s.id === action.id ? { ...s, ...action.update } : s).filter(s => s.status !== 'resolved').length,
      };

    case 'UPDATE_DEFECT':
      playUiClick();
      return { ...state, defects: state.defects.map(d => d.id === action.id ? { ...d, ...action.update } : d) };

    case 'ADD_DEFECT':
      playAlertChime();
      return { ...state, defects: [action.defect, ...state.defects] };

    case 'UPDATE_INCIDENT':
      playUiClick();
      return { ...state, incidents: state.incidents.map(i => i.id === action.id ? { ...i, ...action.update } : i) };

    case 'ADD_INCIDENT':
      playAlertChime();
      return { ...state, incidents: [action.incident, ...state.incidents] };

    case 'ADD_MAINTENANCE':
      playAlertChime();
      return {
        ...state,
        maintenance: [action.task, ...state.maintenance],
        defects: state.defects.map(d => d.id === action.task.defectId ? { ...d, status: 'assigned', assignedTeam: action.task.assignedDepartment } : d),
      };

    case 'UPDATE_MAINTENANCE':
      playUiClick();
      return { ...state, maintenance: state.maintenance.map(m => m.id === action.id ? { ...m, ...action.update } : m) };

    case 'UPDATE_ANPR':
      playUiClick();
      return { ...state, anprList: state.anprList.map(a => a.id === action.id ? { ...a, ...action.update } : a) };

    case 'SELECT_BUS':
      playUiClick();
      return { ...state, selectedBusId: action.id };

    case 'SIMULATE_PASSENGER_EVENT': {
      playUiClick();
      const updatedBuses = state.buses.map(b => {
        if (b.id !== action.busId) return b;
        const newCount = Math.max(0, Math.min(b.capacity, b.passengers + action.boardingDelta - action.alightingDelta));
        return {
          ...b,
          passengers: newCount,
          boardingToday: b.boardingToday + Math.max(0, action.boardingDelta),
          alightingToday: b.alightingToday + Math.max(0, action.alightingDelta),
          status: (newCount / b.capacity > 0.92 ? 'warning' : 'normal') as Bus['status'],
        };
      });
      return {
        ...state,
        buses: updatedBuses,
        totalPassengers: updatedBuses.reduce((s, b) => s + b.passengers, 0),
      };
    }

    case 'TRIGGER_SCENARIO': {
      playAlertChime();
      let alertMsg = '';
      let targetPage: Page = state.page;
      let newAlert: Alert | null = null;
      let newSos: SOSAlert | null = null;

      switch (action.scenario) {
        case 'pothole':
          alertMsg = 'Critical Pothole detected on Route 1 (MG Road) by Bus B-101 (96% Confidence)';
          newAlert = {
            id: `ALT-POT-${Date.now()}`,
            type: 'Severe Pothole Detected',
            category: 'road',
            severity: 'high',
            busId: 'B-101',
            location: 'MG Road, Trinity Junction',
            lat: 12.9716,
            lng: 77.5946,
            timestamp: new Date(),
            status: 'new',
            description: '16cm depth crater detected by front stereo camera. High risk to 2-wheelers.',
          };
          targetPage = 'road-defects';
          break;

        case 'traffic':
          alertMsg = 'Sudden Traffic Bottleneck on Silk Board Junction (Density 98%, Avg Speed 6 km/h)';
          newAlert = {
            id: `ALT-TRAF-${Date.now()}`,
            type: 'Traffic Gridlock Detected',
            category: 'traffic',
            severity: 'critical',
            busId: 'B-103',
            location: 'Silk Board Flyover Ramp',
            lat: 12.9550,
            lng: 77.6100,
            timestamp: new Date(),
            status: 'new',
            description: 'Queue length exceeding 1.2km. Signal cycle adjustment advisory issued.',
          };
          targetPage = 'traffic';
          break;

        case 'overcrowding':
          alertMsg = 'Bus B-102 Overcrowding Alert: 58/60 Capacity (96.6% Occupancy)';
          newAlert = {
            id: `ALT-CROWD-${Date.now()}`,
            type: 'Bus Overcrowding Trigger',
            category: 'passenger',
            severity: 'warning',
            busId: 'B-102',
            location: 'Majestic Terminal',
            lat: 12.9800,
            lng: 77.5700,
            timestamp: new Date(),
            status: 'new',
            description: 'Passenger load threshold breached. Dispatching auxiliary shuttle from Yeshwanthpur.',
          };
          targetPage = 'passengers';
          break;

        case 'sos':
          playSosAlarm();
          alertMsg = 'EMERGENCY: Women/Passenger SOS Triggered on Bus B-104 (Route 12)!';
          newSos = {
            id: `SOS-${Date.now().toString().slice(-4)}`,
            busId: 'B-104',
            route: 'Route 12',
            location: 'MG Road, Near Trinity Circle',
            timestamp: new Date(),
            occupancy: 34,
            capacity: 60,
            gps: '12.9716° N, 77.5946° E',
            alertSource: 'Passenger Mobile App / Panic Button',
            severity: 'critical',
            status: 'active',
            timelineSteps: [
              { label: 'SOS Triggered', done: true, time: new Date().toLocaleTimeString('en-IN') },
              { label: 'Control Room Notified', done: true, time: new Date().toLocaleTimeString('en-IN') },
              { label: 'Safety Officer Assigned', done: false },
              { label: 'Location Shared to PCR Van', done: false },
              { label: 'Response Team Dispatched', done: false },
              { label: 'Incident Resolved', done: false },
            ],
          };
          targetPage = 'women-safety';
          break;

        case 'hit_and_run':
          alertMsg = 'Hit & Run ANPR Capture: KA05AB2267 detected with high damage profile';
          newAlert = {
            id: `ALT-ANPR-${Date.now()}`,
            type: 'ANPR Hit & Run Vehicle Match',
            category: 'safety',
            severity: 'critical',
            busId: 'B-103',
            location: 'Koramangala 80ft Road',
            lat: 12.9550,
            lng: 77.6100,
            timestamp: new Date(),
            status: 'new',
            description: 'Optical license recognition matched registered suspect vehicle in active incident.',
          };
          targetPage = 'anpr';
          break;

        case 'school_zone':
          alertMsg = 'School Zone Safety Hazard: Child pedestrian crossing risk near St. Francis';
          newAlert = {
            id: `ALT-SCH-${Date.now()}`,
            type: 'School Zone Pedestrian Hazard',
            category: 'safety',
            severity: 'high',
            busId: 'B-104',
            location: 'City Public School, Zone 3',
            lat: 12.9620,
            lng: 77.5980,
            timestamp: new Date(),
            status: 'new',
            description: 'Multiple pedestrians detected entering blind roadway during peak dismissal.',
          };
          targetPage = 'safety';
          break;

        case 'waterlogging':
          alertMsg = 'Critical Waterlogging: 28cm flood water detected on Koramangala 5th Block';
          newAlert = {
            id: `ALT-WATER-${Date.now()}`,
            type: 'Flash Waterlogging Detected',
            category: 'road',
            severity: 'critical',
            busId: 'B-102',
            location: 'Koramangala 5th Block',
            lat: 12.9350,
            lng: 77.6200,
            timestamp: new Date(),
            status: 'new',
            description: 'Road depth threshold exceeded 25cm. Traffic redirection advisory issued.',
          };
          targetPage = 'road-defects';
          break;
      }

      return {
        ...state,
        demoMode: true,
        currentDemoScenario: action.scenario,
        simulationRunning: true,
        page: targetPage,
        alerts: newAlert ? [newAlert, ...state.alerts] : state.alerts,
        sosAlerts: newSos ? [newSos, ...state.sosAlerts] : state.sosAlerts,
        activeSOSCount: newSos ? state.activeSOSCount + 1 : state.activeSOSCount,
        notificationCount: state.notificationCount + 1,
      };
    }

    case 'STOP_DEMO':
      return { ...state, demoMode: false, currentDemoScenario: null };

    case 'TICK':
      if (!state.simulationRunning) return state;
      return {
        ...state,
        buses: state.buses.map(moveBus),
        totalPassengers: state.buses.reduce((s, b) => s + b.passengers, 0),
      };

    default:
      return state;
  }
}

interface AppContextType {
  state: AppState;
  dispatch: React.Dispatch<Action>;
  navigate: (page: Page) => void;
  triggerScenario: (scenario: string) => void;
}

const AppContext = createContext<AppContextType | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(reducer, initialState);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (state.simulationRunning) {
      const delay = Math.max(1200, Math.round(3000 / state.simulationSpeed));
      intervalRef.current = setInterval(() => dispatch({ type: 'TICK' }), delay);
    } else {
      if (intervalRef.current) clearInterval(intervalRef.current);
    }
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, [state.simulationRunning, state.simulationSpeed]);

  const navigate = (page: Page) => dispatch({ type: 'SET_PAGE', page });
  const triggerScenario = (scenario: string) => dispatch({ type: 'TRIGGER_SCENARIO', scenario });

  return (
    <AppContext.Provider value={{ state, dispatch, navigate, triggerScenario }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
