import { useState } from 'react';
import { useApp } from '../context/AppContext';
import type { Bus } from '../data/mockData';

export default function BusManagement() {
  const { state } = useApp();
  const [selectedBus, setSelectedBus] = useState<Bus>(state.buses[0]);

  return (
    <div className="flex-1 overflow-y-auto p-4 lg:p-6 space-y-6" >
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-2 border-b" style={{ borderColor: '#e2e8f0' }}>
        <div>
          <div className="text-xs font-mono tracking-widest text-[#0284c7] uppercase">EDGE TELEMETRY & HARDWARE</div>
          <h1 className="text-2xl lg:text-3xl font-black text-slate-900 mt-1">Bus Fleet & Connected Device Management</h1>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        <div className="lg:col-span-7 liquid-glass rounded-2xl border overflow-hidden" style={{ borderColor: '#e2e8f0' }}>
          <div className="divide-y divide-slate-100">
            {state.buses.map(bus => (
              <div key={bus.id} onClick={() => setSelectedBus(bus)}
                className={'p-3.5 cursor-pointer hover:bg-white/5 flex items-center justify-between ' + (selectedBus.id === bus.id ? 'bg-cyan-500/10 border-l-4 border-cyan-400' : '')}>
                <div>
                  <span className="font-bold text-slate-900 text-xs font-mono">{bus.id} ({bus.registration})</span>
                  <div className="text-[11px] text-slate-500 font-mono">Route: {bus.route} · Depot: {bus.depot}</div>
                </div>
                <div className="text-right font-mono text-xs text-[#0284c7] font-bold">
                  {bus.cpuUsage}% CPU · {bus.temperature}°C
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="lg:col-span-5 liquid-glass p-5 rounded-2xl border space-y-4" style={{ borderColor: '#e2e8f0' }}>
          <div className="text-xs font-mono text-[#0284c7] font-bold uppercase">DEVICE TELEMETRY · {selectedBus.id}</div>
          <div className="space-y-2 text-xs font-mono">
            <div className="p-2 rounded bg-white/80 border border-slate-200 flex justify-between">
              <span>CPU UTILIZATION:</span>
              <span className="text-[#0284c7] font-bold">{selectedBus.cpuUsage}%</span>
            </div>
            <div className="p-2 rounded bg-white/80 border border-slate-200 flex justify-between">
              <span>DEVICE TEMP:</span>
              <span className="text-[#d97706] font-bold">{selectedBus.temperature}°C</span>
            </div>
            <div className="p-2 rounded bg-white/80 border border-slate-200 flex justify-between">
              <span>AI MODEL ENGINE:</span>
              <span className="text-[#059669] font-bold">{selectedBus.aiModelVersion}</span>
            </div>
          </div>
          <button onClick={() => alert('OTA Firmware broadcast queued for ' + selectedBus.id)}
            className="w-full py-2.5 rounded-xl text-xs font-mono font-bold bg-cyan-400 text-black hover:bg-cyan-300">
            ⚡ Push OTA Firmware
          </button>
        </div>
      </div>
    </div>
  );
}