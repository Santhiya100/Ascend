import { useState } from 'react';
import { useApp } from '../context/AppContext';
import ThemeSlider from '../components/common/ThemeSlider';

const personas = [
  {
    role: 'Transport Administrator',
    name: 'Dr. Anita Rao',
    dept: 'BMTC Operations Command',
    scope: 'Citywide Fleet, Predictive Routing & Policy',
    avatar: 'A',
    color: '#0284c7',
  },
  {
    role: 'Control Room Operator',
    name: 'Vikram Mehta',
    dept: 'Bengaluru Central Control Hub',
    scope: 'Real-time Triage, Live Camera Feeds & Driver Comms',
    avatar: 'V',
    color: '#2563eb',
  },
  {
    role: 'Traffic Police Liaison',
    name: 'Insp. R. Chandrasekhar',
    dept: 'Bengaluru Traffic Police (BTP)',
    scope: 'ANPR Forensics, Bottlenecks & Hit-and-Run Intercepts',
    avatar: 'C',
    color: '#7c3aed',
  },
  {
    role: 'Road Maintenance Engineer',
    name: 'Kavitha Sundaram',
    dept: 'BBMP Major Roads Infrastructure',
    scope: 'Pothole Verification, Work Orders & Municipal SLAs',
    avatar: 'K',
    color: '#d97706',
  },
  {
    role: 'Passenger Safety Officer',
    name: 'Priya Nambiar',
    dept: 'Women Safety & Emergency Response (112)',
    scope: 'Critical SOS Dispatch, Cabin Verification & PCR Van Link',
    avatar: 'P',
    color: '#e11d48',
  },
];

export default function Login() {
  const { state, dispatch, navigate } = useApp();
  const [selectedPersona, setSelectedPersona] = useState(personas[0]);

  const handleLogin = (persona = selectedPersona) => {
    dispatch({ type: 'LOGIN', role: persona.role, name: persona.name });
    navigate('dashboard');
  };

  return (
    <div
      className={`min-h-screen flex flex-col justify-between p-6 lg:p-12 relative overflow-hidden liquid-canvas selection:bg-[#0284c7] selection:text-white ${state.theme === 'dark' ? 'theme-dark text-slate-100' : 'text-slate-900'}`}
    >
      <div className="liquid-blob-center" />

      {/* Top Header */}
      <header className="flex items-center justify-between z-10">
        <div className="flex items-center gap-3 cursor-pointer" onClick={() => navigate('landing')}>
          <div className="w-10 h-10 rounded-2xl overflow-hidden flex items-center justify-center shadow-md border border-slate-200 bg-white">
            <img src="/ascend-logo.jpg" alt="ASCEND WEB" className="w-full h-full object-cover" />
          </div>
          <div>
            <div className="font-black tracking-widest text-base text-gradient-cyan">ASCEND WEB</div>
            <div className="text-[9px] font-mono text-slate-500 tracking-widest uppercase font-semibold">
              AUTONOMOUS URBAN AI PLATFORM
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <ThemeSlider />
          <button
            onClick={() => handleLogin(personas[0])}
            className="hidden sm:inline-flex items-center gap-2 text-xs font-mono text-[#0284c7] font-bold px-4 py-2 rounded-2xl border border-[#0284c7]/40 bg-white/90 hover:bg-[#0284c7]/10 transition-all shadow-sm"
          >
            <span className="w-2 h-2 rounded-full bg-[#0284c7] animate-blink" />
            <span>⚡ Quick Demo Access (Admin)</span>
          </button>

          <button
            onClick={() => navigate('landing')}
            className="text-xs font-mono text-slate-600 hover:text-slate-900 px-3.5 py-1.5 rounded-2xl border border-slate-300 bg-white/80 hover:bg-white transition-colors shadow-sm"
          >
            ← Mission Overview
          </button>
        </div>
      </header>

      {/* Main Console */}
      <main className="max-w-4xl mx-auto w-full my-auto z-10 py-10">
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white border border-slate-200 text-xs font-mono text-[#0284c7] font-bold mb-3 shadow-sm">
            <span className="w-1.5 h-1.5 rounded-full bg-[#0284c7] animate-blink" />
            MULTI-AGENCY ACCESS GATEWAY · SIH 2026
          </div>
          <h1 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">Select Authorized Persona</h1>
          <p className="text-xs sm:text-sm text-slate-600 mt-2 font-mono">
            Click any persona card below to instantly launch the Command Dashboard.
          </p>
        </div>

        {/* Personas Grid - Instant 1-Click Launch */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
          {personas.map(p => {
            const isSelected = selectedPersona.role === p.role;
            return (
              <div
                key={p.role}
                onClick={() => {
                  setSelectedPersona(p);
                  handleLogin(p);
                }}
                className={
                  'liquid-glass p-5 rounded-3xl border cursor-pointer transition-all liquid-glass-card group relative ' +
                  (isSelected
                    ? 'border-[#0284c7] bg-white shadow-xl scale-102 ring-2 ring-[#0284c7]/40'
                    : 'border-slate-200/90 bg-white/75 hover:bg-white hover:border-[#0284c7]/50')
                }
              >
                <div className="flex items-center justify-between mb-3">
                  <div
                    className="w-10 h-10 rounded-2xl flex items-center justify-center font-bold text-sm shadow-sm transition-transform group-hover:scale-110"
                    style={{ background: p.color + '18', color: p.color, border: '1px solid ' + p.color + '40' }}
                  >
                    {p.avatar}
                  </div>
                  <span
                    className="text-[10px] font-mono px-2.5 py-1 rounded-full font-bold transition-colors group-hover:bg-[#0284c7] group-hover:text-white"
                    style={{ background: p.color + '18', color: p.color }}
                  >
                    ENTER ➔
                  </span>
                </div>

                <div className="text-sm font-bold text-slate-900 group-hover:text-[#0284c7] transition-colors">{p.name}</div>
                <div className="text-xs font-mono font-semibold mt-0.5" style={{ color: p.color }}>{p.role}</div>
                <div className="text-[11px] text-slate-500 mt-1 font-mono">{p.dept}</div>

                <div className="mt-3 pt-2.5 border-t border-slate-100 text-[10px] text-slate-600 font-mono leading-tight">
                  <strong className="text-slate-800">SCOPE:</strong> {p.scope}
                </div>
              </div>
            );
          })}
        </div>

        {/* Primary Launch Action Button */}
        <div className="flex flex-col items-center gap-2">
          <button
            onClick={() => handleLogin(selectedPersona)}
            className="px-10 py-4 rounded-2xl font-bold font-mono text-sm uppercase text-white transition-all hover:scale-105 active:scale-95 shadow-xl bg-gradient-to-r from-[#0284c7] via-[#2563eb] to-[#7c3aed] liquid-btn flex items-center gap-2"
          >
            <span>Enter Command Center as {selectedPersona.name} ({selectedPersona.role})</span>
            <span>➔</span>
          </button>
          <span className="text-[10px] font-mono text-slate-500">
            Authenticated via Role-Based Access Control (RBAC) Token
          </span>
        </div>
      </main>

      {/* Footer */}
      <footer className="text-center text-[11px] font-mono text-slate-500 z-10 border-t border-slate-200 pt-4">
        ASCEND WEB · Smart India Hackathon 2026 · Light Floating Liquid Glass Edition
      </footer>
    </div>
  );
}