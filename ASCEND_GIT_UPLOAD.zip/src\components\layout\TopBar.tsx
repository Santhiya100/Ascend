import { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import ThemeSlider from '../common/ThemeSlider';

export default function TopBar() {
  const { state, dispatch, navigate } = useApp();
  const [time, setTime] = useState(new Date());
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [alertDrawerOpen, setAlertDrawerOpen] = useState(false);

  useEffect(() => {
    const t = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  const activeSOS = state.sosAlerts.filter(s => s.status !== 'resolved');
  const unacknowledgedAlerts = state.alerts.filter(a => a.status === 'new');

  const filteredAlerts = state.alerts.filter(a =>
    a.type.toLowerCase().includes(searchQuery.toLowerCase()) ||
    a.location.toLowerCase().includes(searchQuery.toLowerCase()) ||
    a.busId.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <header
      className="flex items-center justify-between px-4 lg:px-6 py-3 border-b z-30 flex-shrink-0 liquid-glass"
      style={{ borderColor: 'rgba(226, 232, 240, 0.9)' }}
    >
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2 px-3.5 py-1.5 rounded-2xl bg-white/80 border border-slate-200 text-xs font-mono backdrop-blur-md shadow-sm">
          <span className="text-slate-500 font-semibold">SECTOR:</span>
          <span className="text-slate-900 font-bold text-gradient-cyan">BENGALURU CENTRAL</span>
          <span className="w-2 h-2 rounded-full bg-[#0284c7] animate-blink ml-1 shadow-[0_0_8px_#0284c7]" />
        </div>

        {activeSOS.length > 0 && (
          <button
            onClick={() => navigate('women-safety')}
            className="flex items-center gap-2 px-3.5 py-1.5 rounded-2xl text-xs font-mono font-bold bg-gradient-to-r from-[#e11d48] to-[#7c3aed] text-white animate-sos-alarm transition-transform hover:scale-105 shadow-md"
          >
            <span>🚨 SOS ACTIVE ({activeSOS[0].busId})</span>
            <span className="text-[10px] bg-black/20 text-white px-2 py-0.5 rounded-lg uppercase">RESPOND →</span>
          </button>
        )}
      </div>

      <div className="flex items-center gap-2.5">
        <ThemeSlider />
        <div className="relative">
          <button
            onClick={() => setSearchOpen(!searchOpen)}
            className="flex items-center gap-2 px-3.5 py-1.5 rounded-2xl text-xs font-mono text-slate-600 bg-white/80 border border-slate-200 hover:border-[#0284c7]/50 transition-all backdrop-blur-md shadow-sm"
          >
            <span>🔍</span>
            <span className="hidden sm:inline font-semibold">Search Sector / Bus...</span>
            <span className="text-[10px] px-1.5 py-0.5 rounded-lg bg-slate-100 text-slate-500 border border-slate-200 font-bold">⌘K</span>
          </button>

          {searchOpen && (
            <div className="absolute right-0 top-full mt-2 w-84 rounded-3xl liquid-glass p-3.5 border shadow-2xl z-50 animate-fade-in"
              style={{ borderColor: '#0284c7' }}>
              <input
                type="text"
                autoFocus
                placeholder="Search buses, defects, incidents..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl text-xs font-mono outline-none border text-slate-900 mb-2 bg-white/90 border-slate-200 focus:border-[#0284c7] shadow-inner"
              />
              <div className="max-h-48 overflow-y-auto divide-y divide-slate-100 text-xs font-mono">
                {filteredAlerts.slice(0, 4).map(alert => (
                  <div key={alert.id} onClick={() => { setSearchOpen(false); navigate('alerts'); }}
                    className="p-2 hover:bg-slate-50 cursor-pointer rounded-xl flex justify-between items-center transition-colors">
                    <div>
                      <div className="font-bold text-slate-900 text-[11px]">{alert.type}</div>
                      <div className="text-[10px] text-slate-500">{alert.location}</div>
                    </div>
                    <span className="text-[9px] text-[#0284c7] font-bold">{alert.busId}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        <button
          onClick={() => dispatch({ type: 'TOGGLE_AUDIO' })}
          className={'p-2.5 rounded-2xl border text-xs font-mono transition-all backdrop-blur-md shadow-sm ' + (
            state.audioMuted ? 'text-slate-400 border-slate-200 bg-white/80' : 'text-[#0284c7] border-[#0284c7]/40 bg-[#0284c7]/10'
          )}
          title={state.audioMuted ? 'Unmute Audio' : 'Mute Audio'}
        >
          {state.audioMuted ? '🔇' : '🔊'}
        </button>

        <button
          onClick={() => setAlertDrawerOpen(!alertDrawerOpen)}
          className="relative p-2.5 rounded-2xl border text-xs font-mono text-slate-700 bg-white/80 border-slate-200 hover:border-[#0284c7]/50 transition-all backdrop-blur-md shadow-sm"
          title="Alert Stream"
        >
          <span>🔔</span>
          {unacknowledgedAlerts.length > 0 && (
            <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-gradient-to-r from-[#e11d48] to-[#d97706] text-white font-black text-[9px] flex items-center justify-center font-mono shadow-md">
              {unacknowledgedAlerts.length}
            </span>
          )}
        </button>

        <div className="hidden md:flex flex-col text-right font-mono text-[11px] px-3 py-1.5 rounded-2xl bg-white/80 border border-slate-200 backdrop-blur-md shadow-sm">
          <span className="text-slate-900 font-bold text-gradient-cyan">{time.toLocaleTimeString('en-IN', { hour12: false })} IST</span>
          <span className="text-[9px] text-slate-500">{time.toISOString().slice(0, 10)}</span>
        </div>

        <div className="flex items-center gap-2.5 pl-2.5 border-l border-slate-200">
          <div className="w-9 h-9 rounded-2xl bg-gradient-to-br from-[#0284c7] via-[#7c3aed] to-[#e11d48] p-[1.5px] shadow-sm">
            <div className="w-full h-full rounded-2xl bg-white flex items-center justify-center text-xs font-bold text-slate-900">
              {state.userName.charAt(0)}
            </div>
          </div>
          <div className="hidden lg:block text-left text-xs font-mono">
            <div className="text-slate-900 font-bold leading-none">{state.userName}</div>
            <div className="text-[9px] text-[#0284c7] font-semibold mt-0.5">{state.userRole}</div>
          </div>
        </div>
      </div>
    </header>
  );
}