import { useApp } from '../../context/AppContext';

const navGroups = [
  { label: 'Mission Overview', items: [{ id: 'dashboard', label: 'Command Center', icon: '⬡', color: '#0284c7' }] },
  { label: 'Fleet & Spatial Array', items: [{ id: 'fleet', label: 'Live Fleet Tracking', icon: '⬤', color: '#0284c7' }, { id: 'gis', label: 'GIS Spatial Map', icon: '◈', color: '#2563eb' }] },
  { label: 'Edge Detection AI', items: [{ id: 'road-defects', label: 'Road Defects', icon: '⚠', badgeCount: 'defects', color: '#d97706' }, { id: 'traffic', label: 'Traffic Intelligence', icon: '⊡', color: '#e11d48' }, { id: 'passengers', label: 'Passenger Analytics', icon: '◉', color: '#0284c7' }] },
  { label: 'Incident & Distress', items: [{ id: 'safety', label: 'Safety & Incidents', icon: '⚡', color: '#7c3aed' }, { id: 'women-safety', label: 'Women Safety / SOS', icon: '🚨', isSOS: true, color: '#e11d48' }, { id: 'anpr', label: 'ANPR Forensic OCR', icon: '◧', restricted: true, color: '#7c3aed' }] },
  { label: 'Predictive & Reports', items: [{ id: 'route-analytics', label: 'Route Analytics', icon: '⇌', color: '#2563eb' }, { id: 'predictive', label: 'Predictive AI', icon: '◈', color: '#7c3aed' }, { id: 'reports', label: 'Executive Dossiers', icon: '⊟', color: '#059669' }] },
  { label: 'Municipal Operations', items: [{ id: 'maintenance', label: 'Maintenance Orders', icon: '◆', badgeCount: 'maintenance', color: '#d97706' }, { id: 'bus-management', label: 'Fleet Edge Devices', icon: '⬒', color: '#0284c7' }, { id: 'alerts', label: 'Alert Triage Center', icon: '◎', badgeCount: 'alerts', color: '#e11d48' }] },
  { label: 'Governance & Mesh', items: [{ id: 'system-health', label: 'Microservice Mesh', icon: '⊕', color: '#059669' }, { id: 'ai-architecture', label: 'AI Architecture', icon: '∞', color: '#0284c7' }, { id: 'users', label: 'Access Governance', icon: '◷', color: '#7c3aed' }, { id: 'settings', label: 'City Parameters', icon: '⊙', color: '#64748b' }] },
];

export default function Sidebar({ collapsed, onToggle }: { collapsed: boolean; onToggle: () => void }) {
  const { state, navigate } = useApp();
  const activeSOS = state.sosAlerts.filter(s => s.status !== 'resolved').length;
  const newAlerts = state.alerts.filter(a => a.status === 'new').length;
  const openDefects = state.defects.filter(d => d.status === 'detected' || d.status === 'verified').length;
  const openWorkOrders = state.maintenance.filter(m => m.status === 'open' || m.status === 'assigned').length;

  const getBadge = (type?: string, isSOS?: boolean) => {
    if (isSOS && activeSOS > 0) return { label: 'SOS ' + activeSOS, color: 'linear-gradient(135deg, #e11d48, #7c3aed)', blink: true };
    if (type === 'alerts' && newAlerts > 0) return { label: '' + newAlerts, color: 'linear-gradient(135deg, #d97706, #e11d48)', blink: false };
    if (type === 'defects' && openDefects > 0) return { label: '' + openDefects, color: 'linear-gradient(135deg, #0284c7, #2563eb)', blink: false };
    if (type === 'maintenance' && openWorkOrders > 0) return { label: '' + openWorkOrders, color: 'linear-gradient(135deg, #7c3aed, #2563eb)', blink: false };
    return null;
  };

  return (
    <aside
      className={'flex flex-col h-full transition-all duration-300 z-40 relative liquid-glass border-r ' + (collapsed ? 'w-18' : 'w-66')}
      style={{ borderColor: 'rgba(226, 232, 240, 0.9)' }}
    >
      <div className="flex items-center gap-3 px-4 py-4 border-b flex-shrink-0" style={{ borderColor: 'rgba(226, 232, 240, 0.8)' }}>
        <div
          onClick={() => navigate('dashboard')}
          className="flex-shrink-0 w-10 h-10 rounded-2xl overflow-hidden flex items-center justify-center cursor-pointer shadow-md transition-transform hover:scale-110 active:scale-95 border border-slate-200 bg-white"
        >
          <img src="/ascend-logo.jpg" alt="ASCEND WEB Logo" className="w-full h-full object-cover" />
        </div>
        {!collapsed && (
          <div className="min-w-0 flex-1 cursor-pointer" onClick={() => navigate('dashboard')}>
            <div className="text-base font-black tracking-widest text-gradient-cyan flex items-center gap-1.5">
              <span>ASCEND WEB</span>
              <span className="text-[9px] px-1.5 py-0.2 rounded-full font-mono font-bold bg-[#0284c7]/10 text-[#0284c7] border border-[#0284c7]/30">LIGHT</span>
            </div>
            <div className="text-[8.5px] font-mono text-slate-500 tracking-wider uppercase font-semibold">URBAN INTELLIGENCE</div>
          </div>
        )}
        <button
          onClick={onToggle}
          className="p-1.5 rounded-xl text-slate-500 hover:text-slate-900 hover:bg-slate-100 transition-colors flex-shrink-0 ml-auto text-xs font-mono"
          title={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        >
          {collapsed ? '▶' : '◀'}
        </button>
      </div>

      <nav className="flex-1 overflow-y-auto py-3 px-2.5 space-y-3.5">
        {navGroups.map(group => (
          <div key={group.label} className="space-y-1">
            {!collapsed && (
              <div className="px-3 py-1 text-[9px] font-mono font-bold tracking-widest uppercase text-slate-400">
                {group.label}
              </div>
            )}
            {group.items.map(item => {
              const isActive = state.page === item.id;
              const badge = getBadge(item.badgeCount, item.isSOS);

              return (
                <button
                  key={item.id}
                  onClick={() => navigate(item.id as any)}
                  className={'w-full flex items-center gap-3 px-3 py-2.5 rounded-2xl text-left transition-all duration-200 relative group text-xs font-semibold ' + (
                    isActive
                      ? 'text-slate-900 bg-white shadow-md border border-slate-200'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
                  )}
                  style={{
                    boxShadow: isActive ? '0 4px 14px 0 rgba(2, 132, 199, 0.12)' : 'none',
                  }}
                  title={collapsed ? item.label : undefined}
                >
                  <span
                    className="flex-shrink-0 text-base text-center transition-transform group-hover:scale-110"
                    style={{ width: '20px', color: item.color }}
                  >
                    {item.icon}
                  </span>
                  
                  {!collapsed && (
                    <>
                      <span className="flex-1 truncate">{item.label}</span>
                      {badge && (
                        <span
                          className={'flex-shrink-0 px-2 py-0.5 rounded-full text-[9px] font-bold font-mono text-white shadow-sm ' + (badge.blink ? 'animate-blink' : '')}
                          style={{ background: badge.color }}
                        >
                          {badge.label}
                        </span>
                      )}
                      {item.restricted && (
                        <span className="text-[10px] text-slate-400" title="Restricted Police Access">🔒</span>
                      )}
                    </>
                  )}

                  {collapsed && badge && (
                    <span
                      className={'absolute top-2 right-2 w-2.5 h-2.5 rounded-full shadow-md ' + (badge.blink ? 'animate-blink' : '')}
                      style={{ background: badge.color }}
                    />
                  )}
                </button>
              );
            })}
          </div>
        ))}
      </nav>

      <div className="p-3.5 border-t flex-shrink-0" style={{ borderColor: 'rgba(226, 232, 240, 0.8)' }}>
        {!collapsed ? (
          <div className="flex items-center justify-between text-[10px] font-mono px-2 py-1.5 rounded-xl bg-white border border-slate-200 shadow-sm">
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-[#059669] animate-blink shadow-[0_0_8px_#059669]" />
              <span className="text-slate-700 font-bold">EDGE AI MESH</span>
            </div>
            <span className="text-gradient-cyan font-bold">ONLINE</span>
          </div>
        ) : (
          <div className="text-center text-[10px] font-mono font-bold text-[#0284c7]">●</div>
        )}
      </div>
    </aside>
  );
}