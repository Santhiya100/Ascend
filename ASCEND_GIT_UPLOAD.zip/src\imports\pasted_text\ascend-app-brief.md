Build a complete, responsive, production-style web application called:

ASCEND
AI-POWERED MOBILE URBAN INTELLIGENCE PLATFORM

This is a Smart India Hackathon 2026 project.

IMPORTANT:
Do NOT create only a static UI or landing page.
Create a highly interactive, working web application prototype with realistic data, functional navigation, state changes, charts, maps, alerts, forms, filters, modals, tables, authentication flows and simulated real-time updates.

The application should look like a serious government transportation command-and-control platform, not a generic SaaS dashboard.

====================================================
1. PRODUCT CONCEPT
====================================================

Ascend transforms public transport buses into AI-powered mobile urban sensing units.

Existing buses already travel throughout the city and may have front, rear, side and passenger cameras, GPS and vehicle data.

Ascend processes these streams using Edge AI and sends important events to a centralized platform.

The system detects:

• Potholes
• Road cracks and damaged roads
• Waterlogging
• Missing/damaged road dividers
• Missing/damaged zebra crossings
• Damaged/missing traffic signs
• Traffic signals/infrastructure
• Vehicle counts
• Traffic density
• Traffic bottlenecks
• Passenger count
• Bus occupancy
• Boarding and alighting
• Route delays
• Pedestrian safety risks
• School-zone safety events
• Rash driving
• Hit-and-run incidents
• Authorized ANPR/vehicle registration evidence
• Women/passenger safety SOS events
• Other road hazards

The central platform provides:

• Live fleet tracking
• GIS map
• Road-condition heatmap
• Traffic congestion heatmap
• Passenger occupancy analytics
• Incident management
• SOS alerts
• Road maintenance workflow
• Transport department dashboard
• Reports
• Analytics
• Predictive insights
• System health
• User management
• Bus/device management

====================================================
2. DESIGN DIRECTION
====================================================

Create a premium government-tech / smart-city visual identity.

Brand:
ASCEND

Tagline:
"AI-POWERED MOBILE URBAN INTELLIGENCE"

Visual style:

• Modern smart-city command center
• Professional
• High trust
• Data-rich
• Clean
• Minimal but powerful
• Government technology platform
• Enterprise-grade dashboard
• Responsive desktop-first design
• Also support tablet and mobile

Use:

• Deep navy
• White
• Green
• Cyan/blue
• Amber/orange for warnings
• Red for critical alerts
• Purple for analytics

Avoid excessive gradients.
Avoid childish illustrations.
Avoid generic startup landing-page styling.

Use clean cards, subtle shadows, rounded corners, thin borders, professional icons and strong information hierarchy.

Use charts and maps extensively.

====================================================
3. APPLICATION STRUCTURE
====================================================

Create these major sections:

1. Login
2. Main Dashboard
3. Live Fleet
4. GIS Intelligence Map
5. Road Defects
6. Traffic Intelligence
7. Passenger Analytics
8. Safety & Incidents
9. Women Safety / SOS
10. ANPR / Incident Evidence
11. Route Analytics
12. Predictive Analytics
13. Reports
14. Maintenance Management
15. Bus Management
16. Camera & Edge Device Management
17. Alerts Center
18. System Health
19. Users & Roles
20. Settings

Create a persistent left sidebar navigation.

Top navigation should contain:

• Current city
• Global search
• Date/time
• Notification bell
• Alert count
• System health indicator
• User profile
• Role
• Logout

====================================================
4. LOGIN
====================================================

Create a professional login screen.

Fields:

• Email
• Password

Buttons:

• Sign In
• Demo Login

Demo roles:

Transport Administrator
Control Room Operator
Traffic Officer
Road Maintenance Officer
Safety Officer

For demo purposes provide:

"Enter Demo Dashboard"

Clicking it should authenticate the user into the application.

Show:

"Ascend Urban Intelligence Platform"

and:

"Secure access for authorized transport personnel."

Do not use real credentials.

====================================================
5. MAIN DASHBOARD
====================================================

Create the main command center dashboard.

Header:

ASCEND
Urban Intelligence Command Center

Top KPI cards:

• Active Buses
• Buses Online
• Passengers Today
• Road Defects Detected
• Traffic Incidents
• SOS Alerts
• Average Occupancy
• Route Delays

Example demo values can be used but clearly label them as:

"DEMO / SIMULATED DATA"

Do not present demo numbers as real-world claims.

Dashboard sections:

A. Live Fleet Map

Show a city map with moving bus markers.

Each bus marker should have:

• Bus ID
• Route
• Speed
• Occupancy
• Status

Marker colors:

Green = Normal
Yellow = Warning
Red = Critical
Grey = Offline

Clicking a bus opens a live bus information drawer.

B. Active Alerts

Display cards for:

• Pothole detected
• Traffic congestion
• Bus overcrowding
• Rash driving
• Waterlogging
• SOS
• Infrastructure damage

C. Traffic Heatmap

Show congestion zones.

D. Road Defect Heatmap

Show pothole/road damage locations.

E. Passenger Occupancy

Line/bar chart showing:

• Passenger count
• Occupancy percentage
• Peak hours

F. Route Performance

Show:

• On-time routes
• Delayed routes
• Average delay
• Most congested routes

G. Recent Incidents

Table:

Time
Bus ID
Incident
Location
Severity
Status
Action

====================================================
6. LIVE FLEET MODULE
====================================================

Create a dedicated fleet monitoring page.

Show:

• Total buses
• Online buses
• Offline buses
• Active trips
• Delayed trips
• Average fleet speed

Map with real-time simulated bus movement.

Every 2–5 seconds update simulated:

• GPS position
• Speed
• Occupancy
• Route progress
• ETA

Provide filters:

• Route
• Bus ID
• Status
• Occupancy
• Incident status

Click bus:

Open Bus Detail Panel.

Bus detail:

Bus ID
Registration
Route
Driver
Current location
Speed
Trip
Passengers
Capacity
Occupancy %
GPS status
Camera status
Edge AI status
Network status

Camera tiles:

Front Camera
Rear Camera
Left Camera
Right Camera
Cabin Camera

For the prototype, use realistic simulated video placeholders or generated frames.

====================================================
7. GIS INTELLIGENCE MAP
====================================================

Create a full-screen GIS command center.

Map layers:

• Live buses
• Potholes
• Road damage
• Zebra crossings
• Traffic signs
• Traffic signals
• Waterlogging
• Traffic congestion
• Accidents
• SOS alerts
• School zones
• Maintenance locations

Layer controls:

[ ] Fleet
[ ] Road defects
[ ] Traffic
[ ] Infrastructure
[ ] Safety
[ ] Maintenance
[ ] School zones

Heatmap toggle:

Traffic Density
Road Risk
Incident Density
Passenger Demand

Click a map event to open:

Event ID
Type
Detected time
Bus ID
GPS
Confidence
Image/frame
Severity
Status
Assigned department

====================================================
8. ROAD DEFECT DETECTION
====================================================

Create Road Intelligence page.

Detection categories:

• Pothole
• Crack
• Damaged road
• Waterlogging
• Road debris
• Missing divider
• Damaged divider

Show:

Total detected
Critical
Pending verification
Assigned
Resolved

Create a detection table.

Columns:

ID
Type
Severity
Confidence
Location
Bus
Time
Status
Assigned Team

Click an event.

Show:

Detection image
GPS location
Timestamp
Bus ID
AI confidence
Road condition
Severity
Nearby incidents

Buttons:

Verify
Assign
Mark Resolved
Reject
Create Maintenance Task

====================================================
9. TRAFFIC INTELLIGENCE
====================================================

Create Traffic Intelligence dashboard.

Metrics:

• Vehicles/minute
• Cars
• Bikes
• Buses
• Trucks
• Traffic density
• Average speed
• Congestion score

Charts:

• Traffic by hour
• Traffic by route
• Vehicle classification
• Congestion trend

Show congestion map.

Detect:

• Bottleneck
• Sudden congestion
• Slow traffic
• Road blockage

Generate traffic alert automatically when simulated density crosses threshold.

====================================================
10. PASSENGER ANALYTICS
====================================================

Create Passenger Intelligence module.

IMPORTANT:
Privacy-first design.

Do not perform facial recognition.

Do not store passenger identities.

Use anonymous aggregate counting.

Passenger count should be calculated using:

Person detection
+
Tracking
+
Entry/exit line crossing

Display:

Current passengers
Bus capacity
Occupancy %
Boarding
Alighting
Peak load
Estimated demand

Use formula:

Occupancy(t) =
Occupancy(t-1) + Boarding - Alighting

Occupancy rate:

Occupancy / Capacity × 100

Create charts:

Passenger count by hour
Boarding vs alighting
Occupancy by route
Peak occupancy
Passenger demand prediction

Create a simulated bus cabin visualization with anonymous human silhouettes.

Allow clicking:

"Simulate Boarding"

"Simulate Alighting"

and update passenger count dynamically.

====================================================
11. WOMEN SAFETY / SOS MODULE
====================================================

Create a dedicated Women Safety & Passenger Safety module.

IMPORTANT PRIVACY RULE:

Do NOT perform facial recognition.

Do NOT identify individual women or men.

Do NOT store biometric identity.

The safety system should primarily use:

• Passenger-initiated SOS
• Emergency button
• Mobile safety trigger
• Authorized safety rules
• Driver/conductor emergency input
• AI-detected abnormal events where legally permitted

For the hackathon demo, include a clearly labelled:

"SIMULATED SAFETY SCENARIO"

Scenario:

A bus contains a single passenger who activates a safety SOS while travelling with several other passengers.

When SOS is triggered:

1. Create Critical SOS Alert
2. Capture bus ID
3. Capture route
4. Capture GPS
5. Capture timestamp
6. Capture current occupancy
7. Capture last known bus location
8. Capture authorized camera snapshot reference
9. Notify Transport Control Room
10. Notify Safety Officer
11. Show alert on GIS map
12. Start incident tracking

Display:

RED CRITICAL ALERT

"WOMEN / PASSENGER SAFETY SOS"

Bus ID
Route
Location
Time
Occupancy
GPS
Alert source
Severity

Buttons:

• Acknowledge
• Contact Driver
• Dispatch Safety Team
• Escalate
• Resolve Incident

Show alert timeline:

SOS Triggered
↓
Control Room Notified
↓
Safety Officer Assigned
↓
Location Shared
↓
Response Team Dispatched
↓
Incident Resolved

Include a "Send SOS" button in the passenger safety demo.

When clicked, the alert must actually appear in the dashboard Alerts Center and GIS map.

====================================================
12. INCIDENT MANAGEMENT
====================================================

Create incident management system.

Incident types:

• Accident
• Hit-and-run
• Rash driving
• Pedestrian risk
• School-zone risk
• Road hazard
• Waterlogging
• Infrastructure damage
• SOS

Severity:

Low
Medium
High
Critical

Incident workflow:

Detected
→ Verified
→ Assigned
→ Responding
→ Resolved

Create status badges.

Allow officers to assign incidents.

====================================================
13. HIT-AND-RUN / ANPR
====================================================

Create authorized ANPR incident module.

Flow:

Camera detects vehicle
↓
Vehicle tracking
↓
Registration plate detection
↓
OCR
↓
Confidence score
↓
Incident record
↓
Authorized officer review
↓
Evidence package

Show:

Vehicle type
Plate number
Confidence
Timestamp
GPS
Bus ID
Camera
Direction

IMPORTANT:

Mark all ANPR data:

"AUTHORIZED ACCESS ONLY"

"DEMO DATA"

Include role-based access.

Do not expose ANPR information to normal public users.

====================================================
14. RASH DRIVING
====================================================

Create rash-driving detection.

Simulate:

• Sudden acceleration
• Sudden braking
• Excessive speed
• Dangerous lane movement
• Unsafe overtaking

Show:

Vehicle
Speed
Road
Time
GPS
Risk score

Generate alert.

====================================================
15. SCHOOL / PEDESTRIAN SAFETY
====================================================

Create School Zone Safety module.

Map school zones.

Show:

• School location
• Bus routes
• Pedestrian activity
• Traffic density
• Safety incidents

Simulate:

Child/pedestrian crossing risk.

Create alert:

"SCHOOL ZONE PEDESTRIAN RISK"

Show:

Location
Bus
Time
Traffic density
Risk score

====================================================
16. ROUTE ANALYTICS
====================================================

Create route analytics.

For every route show:

• Trips
• Average speed
• Average delay
• Passenger demand
• Occupancy
• Traffic exposure
• Road incidents

Charts:

Route delay trend
Passenger demand
Peak hours
Traffic density
Incident frequency

Allow selecting route.

====================================================
17. ORIGIN-DESTINATION ANALYTICS
====================================================

Create OD analysis.

Use aggregated, privacy-preserving passenger flow data.

Display:

Origin
Destination
Passenger volume
Peak time
Route

Visualize flows on map.

Do not expose individual passenger movement.

====================================================
18. PREDICTIVE ANALYTICS
====================================================

Create AI prediction dashboard.

Predictions:

• Traffic congestion
• Passenger demand
• Route delay
• Road deterioration risk
• Incident risk

Use demo prediction data.

Display:

Prediction
Confidence
Time horizon
Risk level

Charts:

Next 1 hour
Next 3 hours
Next day

Clearly label:

"Prediction is simulated for prototype demonstration."

====================================================
19. MAINTENANCE MANAGEMENT
====================================================

When a road defect is verified, allow:

"Create Maintenance Task"

Fields:

Location
Defect
Severity
Photo
Detected date
Assigned department
Priority
Expected completion

Workflow:

Detected
→ Verified
→ Assigned
→ In Progress
→ Completed

Dashboard:

Open tasks
Critical tasks
Completed tasks
Average resolution time

====================================================
20. REPORT GENERATION
====================================================

Create Reports page.

Report types:

• Daily Transport Report
• Road Condition Report
• Traffic Report
• Passenger Report
• Safety Report
• SOS Report
• Maintenance Report
• Route Performance Report

Buttons:

Generate Report
Preview
Download PDF
Export CSV

For prototype, generate realistic report previews.

====================================================
21. ALERT CENTER
====================================================

Create centralized alert center.

Alert categories:

Critical
Warning
Information

Filters:

• Type
• Severity
• Route
• Bus
• Department
• Status
• Date

Alerts should update dynamically when demo events occur.

====================================================
22. SYSTEM HEALTH
====================================================

Create system monitoring dashboard.

Show:

• Buses online
• Edge devices online
• Cameras online
• API status
• Database status
• GPS status
• Network status
• AI service status

Use status indicators:

ONLINE
WARNING
OFFLINE

Show:

Latency
Events/minute
API response
Device health

====================================================
23. BUS + EDGE DEVICE MANAGEMENT
====================================================

Create Bus Management page.

Fields:

Bus ID
Registration
Route
Depot
Camera count
GPS device
Edge AI device
Network
Status

Device details:

CPU
Memory
Temperature
Storage
AI model version
Last sync
Last heartbeat

Actions:

View
Edit
Restart Device
Update Model
Disable

====================================================
24. USER MANAGEMENT
====================================================

Create role-based access.

Roles:

Super Admin
Transport Admin
Control Room Operator
Traffic Officer
Road Maintenance Officer
Safety Officer
Viewer

Permissions:

Dashboard
Fleet
Road Defects
Traffic
Passenger Data
SOS
ANPR
Reports
Maintenance
Users

ANPR and sensitive safety data must be restricted.

====================================================
25. BACKEND / DATA MODEL
====================================================

If backend integration is available, use Supabase.

Create database structure conceptually containing:

users
roles
buses
routes
devices
cameras
gps_events
road_defects
traffic_events
passenger_events
occupancy_records
incidents
sos_alerts
anpr_events
maintenance_tasks
notifications
system_health
reports

Create relationships between:

Bus
Route
Camera
Device
GPS Event
AI Event
Incident
Maintenance Task

Use realistic seed/demo data.

If a real backend cannot be connected, create a local mock-data service with the same data model and make the UI fully interactive.

Do NOT pretend that external AI APIs are actually running if they are not connected.

====================================================
26. REAL-TIME SIMULATION ENGINE
====================================================

Create a demo simulation engine.

Every few seconds simulate:

• Bus movement
• GPS changes
• Passenger count changes
• Traffic density changes
• Road defect detections
• Alerts
• Route delays
• Device status

Add a control:

"START LIVE SIMULATION"

"STOP SIMULATION"

"RESET DEMO"

When simulation starts, dashboard numbers and map markers should change.

====================================================
27. API ARCHITECTURE
====================================================

Design the prototype around APIs.

Example endpoints:

GET /api/buses
GET /api/buses/:id
GET /api/routes
GET /api/fleet/live
GET /api/traffic/live
GET /api/passengers/occupancy
GET /api/road-defects
GET /api/incidents
GET /api/alerts
GET /api/sos
POST /api/sos
POST /api/incidents
POST /api/maintenance
GET /api/reports
GET /api/system-health

AI event format:

{
  event_id,
  bus_id,
  event_type,
  timestamp,
  latitude,
  longitude,
  confidence,
  severity,
  image_reference,
  status
}

====================================================
28. SECURITY
====================================================

Implement the prototype with security concepts:

• Authentication
• Role-based authorization
• Secure API access
• JWT-style session concept
• HTTPS/TLS concept
• Input validation
• Protected sensitive routes
• Audit logs
• Data minimization
• Privacy-by-design

Never expose passwords or secrets in frontend code.

Do not put API keys directly in UI code.

====================================================
29. AI ARCHITECTURE VISUALIZATION
====================================================

Create an "AI Pipeline" page explaining:

BUS CAMERAS + GPS
↓
EDGE AI COMPUTER
↓
Object Detection
↓
Object Tracking
↓
Event Classification
↓
GPS + Timestamp
↓
Secure Data Transmission
↓
Central AI Platform
↓
GIS + Analytics
↓
Transport Control Room

AI modules:

YOLO-style object detection
Object tracking
OCR / ANPR
Road defect classification
Traffic classification
Passenger counting
Anomaly detection
Prediction models

Use "AI MODEL / DEMO" labels wherever actual trained models are not connected.

====================================================
30. PRIVACY
====================================================

Create Privacy & Data Governance section.

Principles:

• No facial recognition
• Anonymous passenger counting
• Aggregate analytics
• Data minimization
• Role-based access
• Sensitive evidence restricted
• ANPR access controlled
• Retention policy configurable
• Audit logging
• Secure transmission

Include:

"Privacy by Design"

====================================================
31. DEMO MODE
====================================================

Create a highly visible:

DEMO MODE

button.

Demo mode should launch a guided scenario:

Scenario 1:
Pothole Detection

Scenario 2:
Traffic Congestion

Scenario 3:
Bus Overcrowding

Scenario 4:
Women/Passenger SOS

Scenario 5:
Hit-and-Run

Scenario 6:
School Zone Safety

Scenario 7:
Waterlogging

Each scenario should automatically populate the dashboard and generate the relevant alert.

====================================================
32. DEMO SCENARIO — WOMEN SAFETY
====================================================

Create a particularly impressive end-to-end demonstration.

User clicks:

"START WOMEN SAFETY DEMO"

Then:

Bus B-104 is travelling on Route 12.

Passenger safety SOS is triggered.

System generates:

SOS-2026-001

Location:
Demo City — MG Road

Timestamp:
Current simulated time

Occupancy:
Dynamic simulated value

Severity:
CRITICAL

System automatically:

1. Creates SOS record
2. Shows red alert
3. Places SOS marker on map
4. Shows bus location
5. Opens incident panel
6. Notifies control room
7. Assigns Safety Officer
8. Starts response timer
9. Shows incident timeline
10. Allows officer to acknowledge
11. Allows officer to dispatch response
12. Allows officer to resolve

Add visual:

SOS → CONTROL ROOM → SAFETY OFFICER → RESPONSE TEAM

This must be fully clickable.

====================================================
33. RESPONSIVE DESIGN
====================================================

Desktop:
Optimized for 1440px and 1920px command center screens.

Tablet:
Responsive dashboard.

Mobile:
Responsive navigation with bottom navigation or collapsible sidebar.

====================================================
34. MICRO INTERACTIONS
====================================================

Add professional animations:

• Map marker pulse for critical alerts
• Notification slide-in
• KPI number transitions
• Chart transitions
• Modal animations
• Sidebar transitions
• Hover states
• Button feedback
• Loading skeletons
• Success/error notifications

Do not over-animate.

====================================================
35. EMPTY / ERROR / LOADING STATES
====================================================

Every major module must have:

Loading state
Empty state
Error state
Success state

Example:

"No active incidents"

"No buses offline"

"All systems operational"

====================================================
36. DATA QUALITY
====================================================

All demo data should be internally consistent.

Bus capacity must be greater than passenger count.

Occupancy percentage must be calculated correctly.

GPS coordinates must match map locations.

Timestamps should be realistic.

Alerts should reference actual buses.

Maintenance tasks should reference road defects.

SOS incidents should reference buses and locations.

====================================================
37. IMPORTANT PRODUCT POSITIONING
====================================================

The website must clearly communicate this unique concept:

"Instead of deploying thousands of fixed roadside sensors, Ascend transforms the existing public-bus fleet into a continuously moving network of AI-powered urban sensors."

Primary value proposition:

Detect.
Understand.
Alert.
Act.

Use this prominently on the landing/dashboard experience.

====================================================
38. LANDING PAGE
====================================================

Create a polished landing page before login.

Hero:

ASCEND

AI-POWERED MOBILE URBAN INTELLIGENCE

"Turning public buses into intelligent mobile sensors for safer, smarter and more responsive cities."

Buttons:

Explore Platform
View Live Demo

Visual:

Animated city map with buses moving across roads.

Show floating AI detection cards:

POTHOLE DETECTED
TRAFFIC BOTTLENECK
PASSENGER OCCUPANCY
SOS ALERT
ROAD HAZARD

Sections:

How Ascend Works

BUS CAMERAS
→
EDGE AI
→
SECURE DATA
→
CENTRAL AI
→
GIS INTELLIGENCE

Features:

Road Intelligence
Traffic Intelligence
Passenger Intelligence
Safety Intelligence
Predictive Intelligence

Final CTA:

"Turn Every Bus Into a Mobile Urban Sensor."

====================================================
39. TECHNICAL ARCHITECTURE PAGE
====================================================

Create an architecture visualization.

Input:

Bus cameras
GPS
IMU
Passenger streams

Processing:

Edge AI
Object detection
Tracking
Event filtering
Anonymization

Core Engine:

Road AI
Traffic AI
Passenger AI
Safety AI
Prediction AI

Application:

Central platform
GIS
Analytics
Alerts
Reports

Output:

Transport Department
Traffic Police
Maintenance Teams
Safety Officers
City Administrators

====================================================
40. FINAL QUALITY REQUIREMENT
====================================================

This should feel like a real product that could be demonstrated to:

• Smart India Hackathon judges
• Transport Department
• Smart City officials
• Traffic Police
• Municipal authorities
• Investors
• Technical reviewers

Do not make it look like a student template.

Make it look like a real command-and-control platform.

Every important button must perform an action.

Every major module must be navigable.

Use realistic demo data.

Clearly distinguish simulated/demo AI from actual connected AI models.

Use consistent Ascend branding throughout.

Add a small:

"ASCEND • SIH 2026"

footer where appropriate.

Build the complete working prototype now.