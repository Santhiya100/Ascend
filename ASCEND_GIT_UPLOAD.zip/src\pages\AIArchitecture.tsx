export default function AIArchitecture() {
  return (
    <div className="flex-1 overflow-y-auto p-4 lg:p-6 space-y-6 text-slate-900">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-3 border-b border-slate-200">
        <div>
          <div className="text-xs font-mono tracking-widest text-[#0284c7] uppercase font-bold">NEURAL COMPUTE TOPOLOGY</div>
          <h1 className="text-2xl lg:text-3xl font-black text-slate-900 mt-1">AI Architecture & Edge Models</h1>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {[
          { name: 'YOLO-v11 Surface Net', desc: '14cm depth resolution for potholes, cracks & curb damage.', fps: '45 FPS TensorRT FP16', color: '#d97706' },
          { name: 'ByteTrack Multi-Class', desc: 'Vehicle classification across 6 urban transit categories.', fps: '30 FPS TensorRT INT8', color: '#0284c7' },
          { name: 'Privacy Anonymizer', desc: 'Face & license plate Gaussian blurring on edge camera hardware.', fps: '60 FPS Embedded Hardware', color: '#059669' },
        ].map(m => (
          <div key={m.name} className="liquid-glass p-5 rounded-3xl border border-slate-200 shadow-md space-y-3">
            <h3 className="font-bold text-slate-900 text-sm">{m.name}</h3>
            <p className="text-xs text-slate-600">{m.desc}</p>
            <div className="pt-2 border-t border-slate-100 text-[10px] font-mono font-bold" style={{ color: m.color }}>
              ⚡ {m.fps}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}