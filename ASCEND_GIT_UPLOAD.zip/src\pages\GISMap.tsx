import { useState } from 'react';
import { useApp } from '../context/AppContext';
import InteractiveLeafletMap from '../components/common/InteractiveLeafletMap';

export default function GISMap() {
  const { navigate } = useApp();
  const [layers, setLayers] = useState({
    buses: true,
    defects: true,
    traffic: true,
    incidents: true,
    routes: true,
  });
  const [selectedEntity, setSelectedEntity] = useState<any>(null);

  const toggleLayer = (key: keyof typeof layers) => {
    setLayers(prev => ({ ...prev, [key]: !prev[key] }));
  };

  return (
    <div className="flex-1 flex flex-col h-full overflow-hidden relative" style={{ background: '#f8fafc' }}>
      <div
        className="px-6 py-3 border-b liquid-glass flex flex-wrap items-center justify-between gap-3 z-20 flex-shrink-0"
        style={{ borderColor: 'rgba(226, 232, 240, 0.9)' }}
      >
        <div>
          <div className="text-xs font-mono text-gradient-cyan font-bold uppercase tracking-wider">
            BENGALURU GIS SPATIAL MISSION GRID (REAL MAPS LINKED)
          </div>
          <div className="text-[10px] text-slate-500 font-mono">
            Center: 12.9716° N, 77.5946° E · Real Cartographic Tiles · EPSG:3857
          </div>
        </div>

        <div className="flex items-center gap-1.5 flex-wrap text-xs font-mono">
          {[
            { id: 'buses', label: '🚌 Buses', color: '#0284c7' },
            { id: 'defects', label: '⚠ Road Hazards', color: '#d97706' },
            { id: 'traffic', label: '🚦 Congestion', color: '#e11d48' },
            { id: 'incidents', label: '⚡ Incidents', color: '#7c3aed' },
            { id: 'routes', label: '⇌ Vector Routes', color: '#2563eb' },
          ].map(layer => {
            const active = layers[layer.id as keyof typeof layers];
            return (
              <button
                key={layer.id}
                onClick={() => toggleLayer(layer.id as any)}
                className="px-2.5 py-1 rounded-xl border font-semibold transition-all text-[11px] liquid-btn shadow-sm"
                style={{
                  background: active ? 'rgba(2, 132, 199, 0.12)' : '#ffffff',
                  borderColor: active ? layer.color : 'rgba(226, 232, 240, 0.9)',
                  color: active ? '#0284c7' : '#64748b',
                }}
              >
                {layer.label}
              </button>
            );
          })}
        </div>
      </div>

      <div className="flex-1 relative overflow-hidden bg-slate-100">
        <InteractiveLeafletMap
          height="100%"
          showLayersControl={true}
          activeLayers={layers}
          onSelectEntity={setSelectedEntity}
        />

        {selectedEntity && (
          <div
            className="absolute right-4 top-4 w-84 liquid-glass p-4.5 rounded-3xl border border-slate-200 shadow-2xl z-30 animate-slide-in space-y-3 backdrop-blur-2xl bg-white/95"
          >
            <div className="flex items-center justify-between pb-2 border-b border-slate-200">
              <div className="text-xs font-mono font-bold text-gradient-cyan uppercase">
                ENTITY INSPECTOR
              </div>
              <button
                onClick={() => setSelectedEntity(null)}
                className="text-slate-500 hover:text-slate-900 text-xs font-bold"
              >
                ✕
              </button>
            </div>

            {selectedEntity.type === 'Bus' && (
              <div className="space-y-2 text-xs font-mono">
                <div className="text-sm font-bold text-slate-900">
                  {selectedEntity.data.id} ({selectedEntity.data.registration})
                </div>
                <div className="text-slate-500">
                  Route: {selectedEntity.data.route} · Driver: {selectedEntity.data.driver}
                </div>
                <div className="text-[#0284c7] font-bold">
                  Speed: {selectedEntity.data.speed} km/h · Load: {selectedEntity.data.passengers} pax
                </div>
                <div className="text-[10px] text-slate-400">
                  GPS: {selectedEntity.data.lat.toFixed(4)}° N, {selectedEntity.data.lng.toFixed(4)}° E
                </div>
                <button
                  onClick={() => navigate('fleet')}
                  className="w-full py-2 rounded-xl text-xs font-mono font-bold bg-[#0284c7] text-white liquid-btn shadow-sm"
                >
                  View 5-Camera Feed ➔
                </button>
              </div>
            )}

            {selectedEntity.type === 'Defect' && (
              <div className="space-y-2 text-xs font-mono">
                <div className="text-sm font-bold text-slate-900 uppercase">
                  {selectedEntity.data.type} ({selectedEntity.data.id})
                </div>
                <div className="text-[#d97706] font-bold">
                  Severity: {selectedEntity.data.severity.toUpperCase()} · AI Conf: {selectedEntity.data.confidence}%
                </div>
                <div className="text-[10px] text-slate-400">
                  GPS: {selectedEntity.data.lat.toFixed(4)}° N, {selectedEntity.data.lng.toFixed(4)}° E
                </div>
                <button
                  onClick={() => navigate('road-defects')}
                  className="w-full py-2 rounded-xl text-xs font-mono font-bold bg-[#d97706] text-white liquid-btn shadow-sm"
                >
                  Inspect Defect Frame ➔
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}