import { useState } from 'react';
import { useApp } from '../context/AppContext';
import InteractiveLeafletMap from '../components/common/InteractiveLeafletMap';

export default function LiveFleet() {
  const { state, dispatch, navigate } = useApp();
  const [selectedCam, setSelectedCam] = useState<'Front Road (Stereo 1080p)' | 'Rear ANPR (OCR)' | 'Cabin (Anonymized)' | 'Left Blindspot' | 'Right Blindspot'>('Front Road (Stereo 1080p)');
  const [aiOverlay, setAiOverlay] = useState(true);
  const [activeTab, setActiveTab] = useState<'cameras' | 'map'>('cameras');

  const selectedBus = state.buses.find(b => b.id === state.selectedBusId) || state.buses[0];

  // Defects detected by this specific bus or along its route
  const busDefects = state.defects.filter(d => d.busId === selectedBus.id || d.busId === 'B-101' || d.busId === 'B-104');

  const cameraFeeds = [
    { id: 'Front Road (Stereo 1080p)', label: 'Front Road Stereo', fps: 30, res: '1080p60', latency: '14ms', icon: '📹' },
    { id: 'Rear ANPR (OCR)', label: 'Rear ANPR OCR', fps: 30, res: '1080p30', latency: '18ms', icon: '🔍' },
    { id: 'Cabin (Anonymized)', label: 'Cabin Privacy Feed', fps: 15, res: '720p15', latency: '22ms', icon: '👥' },
    { id: 'Left Blindspot', label: 'Left Blindspot', fps: 30, res: '1080p30', latency: '16ms', icon: '◧' },
    { id: 'Right Blindspot', label: 'Right Blindspot', fps: 30, res: '1080p30', latency: '16ms', icon: '◨' },
  ];

  return (
    <div className="flex-1 overflow-y-auto p-4 lg:p-6 space-y-6 text-slate-900">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-3 border-b border-slate-200">
        <div>
          <div className="text-xs font-mono tracking-widest text-gradient-cyan uppercase font-bold">
            MOBILE SENSOR TELEMETRY & SPATIAL PERCEPTION
          </div>
          <h1 className="text-2xl lg:text-3xl font-black text-slate-900 mt-0.5 tracking-tight flex items-center gap-3">
            <span>Live Fleet Tracking & Optical Stream</span>
            <span className="text-xs font-mono font-bold px-2.5 py-1 rounded-full bg-[#0284c7]/10 text-[#0284c7] border border-[#0284c7]/30">
              {selectedBus.id} Active
            </span>
          </h1>
        </div>

        <div className="flex items-center gap-3 flex-wrap">
          {/* Toggle View: Camera Feed vs Live GPS Map */}
          <div className="flex items-center bg-white p-1 rounded-2xl border border-slate-200 text-xs font-mono shadow-sm">
            <button
              onClick={() => setActiveTab('cameras')}
              className={'px-3 py-1.5 rounded-xl font-bold transition-all ' + (
                activeTab === 'cameras' ? 'bg-[#0284c7] text-white shadow-sm' : 'text-slate-600 hover:text-slate-900'
              )}
            >
              📹 5-Cam Optical Feed
            </button>
            <button
              onClick={() => setActiveTab('map')}
              className={'px-3 py-1.5 rounded-xl font-bold transition-all ' + (
                activeTab === 'map' ? 'bg-[#0284c7] text-white shadow-sm' : 'text-slate-600 hover:text-slate-900'
              )}
            >
              🗺 Live Pothole & Route Map
            </button>
          </div>

          <label className="flex items-center gap-2 text-xs font-mono cursor-pointer px-3.5 py-1.5 rounded-2xl bg-white border border-slate-200 shadow-sm text-slate-700 font-semibold">
            <input
              type="checkbox"
              checked={aiOverlay}
              onChange={e => setAiOverlay(e.target.checked)}
              className="rounded accent-[#0284c7]"
            />
            <span>AI YOLO Bounding Boxes</span>
          </label>
        </div>
      </div>

      {/* Main Top Section: Optical Feed OR Interactive Map */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Monitor (8 Cols) */}
        <div className="lg:col-span-8 liquid-glass p-5 rounded-3xl border border-slate-200 shadow-xl space-y-4">
          
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <span className="w-2.5 h-2.5 rounded-full bg-[#e11d48] animate-ping" />
              <span className="font-bold text-sm text-slate-900 font-mono">
                {selectedBus.id} ({selectedBus.registration}) · {activeTab === 'cameras' ? selectedCam : 'Real-time GPS Pothole Map'}
              </span>
            </div>
            <div className="flex items-center gap-2 text-[11px] font-mono text-slate-500 font-semibold">
              <span className="px-2 py-0.5 rounded-md bg-[#059669]/10 text-[#059669] border border-[#059669]/30 font-bold">
                120 FPS JETSON
              </span>
              <span>1080p60 · 14ms</span>
            </div>
          </div>

          {activeTab === 'cameras' ? (
            /* Optical Video Feed Screen */
            <div className="space-y-3">
              <div className="relative rounded-2xl overflow-hidden border border-slate-200 bg-slate-900 flex items-center justify-center shadow-inner" style={{ aspectRatio: '16/9' }}>
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/40 z-10 pointer-events-none" />

                <div className="w-full h-full relative flex items-center justify-center">
                  <div className="absolute inset-0 opacity-25 bg-[radial-gradient(#0284c7_1px,transparent_1px)] [background-size:16px_16px]" />
                  
                  <div className="text-center font-mono space-y-2 z-20">
                    <div className="text-5xl animate-bounce">🚌</div>
                    <div className="text-xs font-bold text-white tracking-widest uppercase">
                      ACTIVE RTSP EDGE STREAM: {selectedCam}
                    </div>
                    <div className="text-[10px] text-slate-300">
                      GPS: {selectedBus.lat.toFixed(4)}° N, {selectedBus.lng.toFixed(4)}° E · Speed: {selectedBus.speed} km/h
                    </div>
                  </div>

                  {aiOverlay && (
                    <div className="absolute inset-0 pointer-events-none z-20">
                      <div className="absolute top-[35%] left-[25%] border-2 border-[#0284c7] bg-[#0284c7]/15 rounded-lg px-2 py-0.5 text-[9px] font-mono text-white font-bold shadow-lg">
                        Vehicle: Auto-Rickshaw [94%]
                      </div>
                      <div className="absolute bottom-[28%] right-[30%] border-2 border-[#d97706] bg-[#d97706]/20 rounded-lg px-2.5 py-1 text-[9px] font-mono text-white font-bold shadow-lg flex items-center gap-1.5 animate-pulse">
                        <span>⚠</span>
                        <span>POTHOLE DETECTED (Depth: 14cm, Conf: 96.2%)</span>
                      </div>
                      <div className="absolute top-[40%] right-[15%] border-2 border-[#059669] bg-[#059669]/15 rounded-lg px-2 py-0.5 text-[9px] font-mono text-white font-bold shadow-lg">
                        Pedestrian: Crossing [91%]
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* 5-Camera Grid Selector */}
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5 pt-1">
                {cameraFeeds.map(cam => {
                  const isActive = selectedCam === cam.id;
                  return (
                    <button
                      key={cam.id}
                      onClick={() => setSelectedCam(cam.id as any)}
                      className={'p-2.5 rounded-2xl border text-left transition-all liquid-btn ' + (
                        isActive
                          ? 'border-[#0284c7] bg-[#0284c7]/10 text-slate-900 font-bold shadow-md ring-2 ring-[#0284c7]/30'
                          : 'border-slate-200 bg-white/70 text-slate-600 hover:bg-white hover:border-slate-300'
                      )}
                    >
                      <div className="flex items-center justify-between text-xs mb-1">
                        <span>{cam.icon}</span>
                        <span className="text-[9px] font-mono text-slate-400">{cam.fps} FPS</span>
                      </div>
                      <div className="text-[11px] font-bold truncate">{cam.label}</div>
                      <div className="text-[9px] font-mono text-slate-400 mt-0.5">{cam.res}</div>
                    </button>
                  );
                })}
              </div>
            </div>
          ) : (
            /* Live Leaflet GPS Map Focused on This Bus & Detected Potholes */
            <div className="space-y-3">
              <div className="relative rounded-2xl overflow-hidden border border-slate-200 shadow-inner" style={{ height: '360px' }}>
                <InteractiveLeafletMap
                  height="100%"
                  showLayersControl={true}
                  activeLayers={{ buses: true, defects: true, routes: true, traffic: true, incidents: true }}
                />
              </div>
              <div className="flex items-center justify-between text-[11px] font-mono px-3 py-1.5 rounded-xl bg-slate-50 border border-slate-200 text-slate-600">
                <span>📍 Tracking Bus {selectedBus.id} on {selectedBus.route}</span>
                <span className="text-[#d97706] font-bold">⚠ {busDefects.length} Road Hazards Logged Near This Route</span>
              </div>
            </div>
          )}
        </div>

        {/* Right: Jetson Telemetry & Road Quality Metrics (4 Cols) */}
        <div className="lg:col-span-4 liquid-glass p-5 rounded-3xl border border-slate-200 shadow-xl space-y-4 flex flex-col justify-between">
          <div>
            <div className="pb-3 border-b border-slate-200">
              <div className="text-xs font-mono text-gradient-cyan uppercase font-bold">EDGE HARDWARE & ROAD TELEMETRY</div>
              <h3 className="text-base font-bold text-slate-900 mt-0.5">{selectedBus.id} Fleet Diagnostics</h3>
            </div>

            <div className="space-y-3 mt-4 text-xs font-mono">
              {/* Road Quality Index */}
              <div className="p-3.5 rounded-2xl bg-white border border-slate-200 shadow-sm flex items-center justify-between">
                <div>
                  <div className="text-slate-500 text-[10px]">ROAD QUALITY INDEX (IRI)</div>
                  <div className="text-base font-bold text-slate-900">2.8 mm/m (Moderate)</div>
                </div>
                <span className="text-[10px] px-2.5 py-1 rounded-full font-bold bg-[#d97706]/15 text-[#d97706] border border-[#d97706]/40">
                  ⚠ 3 DEFECTS
                </span>
              </div>

              {/* Hardware Health Stats */}
              <div className="p-3 rounded-2xl bg-white border border-slate-200 shadow-sm flex items-center justify-between">
                <div>
                  <div className="text-slate-500 text-[10px]">JETSON CPU LOAD</div>
                  <div className="text-sm font-bold text-slate-900">{selectedBus.cpuUsage}%</div>
                </div>
                <div className="w-20 bg-slate-100 rounded-full h-2 overflow-hidden border border-slate-200">
                  <div className="h-full bg-[#0284c7] rounded-full" style={{ width: `${selectedBus.cpuUsage}%` }} />
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-white border border-slate-200 shadow-sm flex items-center justify-between">
                <div>
                  <div className="text-slate-500 text-[10px]">AI MODEL PIPELINE</div>
                  <div className="text-sm font-bold text-slate-900">{selectedBus.aiModelVersion}</div>
                </div>
                <span className="text-[10px] px-2 py-0.5 rounded-full font-bold bg-[#059669]/10 text-[#059669] border border-[#059669]/30">
                  FP16 TENSORRT
                </span>
              </div>

              {/* Route Assignment */}
              <div className="p-3.5 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-1.5 text-[11px]">
                <div className="flex justify-between">
                  <span className="text-slate-500">Route Assigned:</span>
                  <span className="font-bold text-slate-900">{selectedBus.route}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Driver in Cabin:</span>
                  <span className="font-bold text-slate-900">{selectedBus.driver}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Next Stop / ETA:</span>
                  <span className="font-bold text-[#0284c7]">{selectedBus.depot} ({selectedBus.eta})</span>
                </div>
              </div>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-200">
            <button
              onClick={() => navigate('road-defects')}
              className="w-full py-2.5 rounded-2xl font-bold font-mono text-xs uppercase text-white bg-gradient-to-r from-[#d97706] to-[#0284c7] liquid-btn shadow-md"
            >
              View All Defect Work Orders ➔
            </button>
          </div>
        </div>
      </div>

      {/* Real-time Potholes & Road Surface Hazards Logged on this Route */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-900 uppercase font-mono tracking-wider flex items-center gap-2">
            <span>⚠ Potholes & Road Hazards Detected by {selectedBus.id}</span>
            <span className="text-xs font-mono font-bold px-2 py-0.5 rounded-full bg-[#d97706]/15 text-[#d97706]">
              {busDefects.length} Anomaly Events
            </span>
          </h3>

          <button
            onClick={() => navigate('road-defects')}
            className="text-xs font-mono text-[#0284c7] font-bold hover:underline"
          >
            Open Full Road Defects Manager ➔
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {busDefects.slice(0, 3).map(defect => (
            <div
              key={defect.id}
              className="liquid-glass p-4.5 rounded-3xl border border-slate-200 shadow-md space-y-2.5 font-mono text-xs hover:border-[#d97706]/50 transition-all cursor-pointer"
              onClick={() => navigate('road-defects')}
            >
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-900 uppercase flex items-center gap-1.5">
                  <span className="text-[#d97706]">⚠</span>
                  <span>{defect.type} ({defect.id})</span>
                </span>
                <span className={'px-2.5 py-0.5 rounded-full text-[9px] font-bold ' + (
                  defect.severity === 'critical' ? 'bg-[#e11d48]/15 text-[#e11d48]' : 'bg-[#d97706]/15 text-[#d97706]'
                )}>
                  {defect.severity.toUpperCase()}
                </span>
              </div>

              <div className="text-slate-600 text-[11px] space-y-0.5">
                <div>📍 <strong>Location:</strong> {defect.location || 'MG Road Corridor'}</div>
                <div>📏 <strong>Est Depth:</strong> {defect.depthCm || 14}cm (Hazard to 2-Wheelers)</div>
                <div>🤖 <strong>AI Confidence:</strong> {defect.confidence}% YOLO-Edge</div>
              </div>

              <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[10px]">
                <span className="text-slate-400">GPS: {defect.lat.toFixed(4)}° N, {defect.lng.toFixed(4)}° E</span>
                <span className="text-[#0284c7] font-bold">Inspect Frame ➔</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Fleet Grid Selection */}
      <div className="space-y-3 pt-2">
        <h3 className="text-sm font-bold text-slate-900 uppercase font-mono tracking-wider">
          Switch Active Fleet Unit ({state.buses.length} Buses Online)
        </h3>
        <div className="grid grid-cols-2 sm:grid-cols-5 lg:grid-cols-10 gap-2.5">
          {state.buses.map(b => {
            const isSelected = b.id === selectedBus.id;
            return (
              <button
                key={b.id}
                onClick={() => dispatch({ type: 'SELECT_BUS', id: b.id })}
                className={'p-3 rounded-2xl border text-center transition-all liquid-btn ' + (
                  isSelected
                    ? 'border-[#0284c7] bg-white text-slate-900 font-bold shadow-lg ring-2 ring-[#0284c7]/40'
                    : 'border-slate-200 bg-white/70 text-slate-700 hover:bg-white hover:border-slate-300'
                )}
              >
                <div className="text-xs font-mono font-bold">{b.id}</div>
                <div className="text-[10px] text-slate-500 truncate mt-0.5">{b.route}</div>
                <div className="text-[9px] font-mono text-[#0284c7] font-bold mt-1">{b.speed} km/h</div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}