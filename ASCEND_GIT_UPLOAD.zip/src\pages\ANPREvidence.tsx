import { useState } from 'react';
import { useApp } from '../context/AppContext';
import type { ANPREvent } from '../data/mockData';

export default function ANPREvidence() {
  const { state, dispatch, triggerScenario } = useApp();
  const [selectedPlate, setSelectedPlate] = useState<ANPREvent | null>(state.anprList[0]);

  return (
    <div className="flex-1 overflow-y-auto p-4 lg:p-6 space-y-6" >
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-2 border-b" style={{ borderColor: '#e2e8f0' }}>
        <div>
          <div className="text-xs font-mono tracking-widest text-red-400 uppercase font-bold">RESTRICTED FORENSIC LOG</div>
          <h1 className="text-2xl lg:text-3xl font-black text-slate-900 mt-1">Automatic Number Plate Recognition (ANPR)</h1>
        </div>
        <button onClick={() => triggerScenario('hit_and_run')}
          className="px-3 py-1.5 rounded-lg border text-xs font-mono font-semibold text-[#7c3aed] hover:bg-purple-400/10"
          style={{ borderColor: '#8b5cf6' }}>
          🔍 Simulate Hit & Run OCR Capture
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        <div className="lg:col-span-7 liquid-glass rounded-2xl border overflow-hidden" style={{ borderColor: '#e2e8f0' }}>
          <div className="divide-y divide-slate-100">
            {state.anprList.map(item => (
              <div key={item.id} onClick={() => setSelectedPlate(item)}
                className={'p-3.5 cursor-pointer hover:bg-white/5 flex items-center justify-between ' + (selectedPlate?.id === item.id ? 'bg-purple-500/10 border-l-4 border-purple-400' : '')}>
                <div>
                  <span className="px-2 py-0.5 rounded font-mono font-black text-sm bg-yellow-400 text-black tracking-wider">
                    {item.plateNumber}
                  </span>
                  <div className="text-[11px] text-slate-500 font-mono mt-1">
                    Reason: <strong className="text-red-400">{item.incidentType}</strong> · Bus {item.busId}
                  </div>
                </div>
                <div className="text-right font-mono text-xs">
                  <div className="text-[#0284c7] font-bold">{item.confidence}% OCR</div>
                  <div className="text-[10px] text-slate-500 uppercase">{item.status}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="lg:col-span-5 liquid-glass p-5 rounded-2xl border space-y-4" style={{ borderColor: '#e2e8f0' }}>
          {selectedPlate && (
            <>
              <div className="text-xs font-mono text-[#7c3aed] font-bold uppercase">FORENSIC EVIDENCE PACKAGE</div>
              <div className="p-4 rounded-xl bg-white border text-center space-y-2" style={{ borderColor: '#e2e8f0' }}>
                <div className="inline-block px-4 py-2 rounded-lg border-2 border-black bg-amber-400 text-black font-black font-mono text-xl tracking-widest">
                  {selectedPlate.plateNumber}
                </div>
              </div>
              <div className="space-y-1 text-xs font-mono text-slate-300">
                <div>SPEED: {selectedPlate.speedKmH || 45} km/h</div>
                <div>DIRECTION: {selectedPlate.direction}</div>
                <div>CAM: {selectedPlate.camera}</div>
              </div>
              <button onClick={() => dispatch({ type: 'UPDATE_ANPR', id: selectedPlate.id, update: { status: 'escalated' } })}
                className="w-full py-2 rounded-xl text-xs font-mono font-bold bg-red-600 text-slate-900 hover:bg-red-500">
                Escalate to Patrol Van (PCR)
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}