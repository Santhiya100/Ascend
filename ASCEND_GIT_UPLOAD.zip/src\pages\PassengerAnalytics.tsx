import { useState } from 'react';
import { useApp } from '../context/AppContext';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { hourlyPassengerData, odMatrix } from '../data/mockData';

export default function PassengerAnalytics() {
  const { state, dispatch, triggerScenario } = useApp();
  const [selectedBusId, setSelectedBusId] = useState('B-104');
  const [activeTab, setActiveTab] = useState<'cabin' | 'trends' | 'od'>('cabin');

  const selectedBus = state.buses.find(b => b.id === selectedBusId) || state.buses[0];
  const occupancyPct = Math.round((selectedBus.passengers / selectedBus.capacity) * 100);

  return (
    <div className="flex-1 overflow-y-auto p-4 lg:p-6 space-y-6" >
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-2 border-b" style={{ borderColor: '#e2e8f0' }}>
        <div>
          <div className="text-xs font-mono tracking-widest text-[#0284c7] uppercase">PASSENGER INTELLIGENCE & PRIVACY</div>
          <h1 className="text-2xl lg:text-3xl font-black text-slate-900 mt-1">Anonymous Occupancy & Flow Analytics</h1>
        </div>
        <div className="px-3 py-1.5 rounded-xl border border-emerald-500/40 text-[#059669] text-xs font-mono">
          🔒 PRIVACY-BY-DESIGN: ZERO BIOMETRIC CAPTURE
        </div>
      </div>

      <div className="flex items-center gap-2 border-b pb-2" style={{ borderColor: '#e2e8f0' }}>
        {[
          { id: 'cabin', label: '💺 Interactive Cabin Simulator' },
          { id: 'trends', label: '📊 Hourly Demand Curves' },
          { id: 'od', label: '⇌ Origin-Destination (OD) Matrix' },
        ].map(t => (
          <button key={t.id} onClick={() => setActiveTab(t.id as any)}
            className="px-3.5 py-1.5 rounded-lg text-xs font-mono font-semibold transition-all"
            style={{
              background: activeTab === t.id ? '#06b6d4' : '#ffffff',
              color: activeTab === t.id ? '#000' : '#94a3b8',
            }}>
            {t.label}
          </button>
        ))}
      </div>

      {activeTab === 'cabin' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          <div className="lg:col-span-7 liquid-glass p-5 rounded-2xl border space-y-4" style={{ borderColor: '#e2e8f0' }}>
            <div className="flex items-center justify-between">
              <div>
                <div className="text-xs font-mono text-[#0284c7] font-bold uppercase">CABIN WIREFRAME OCCUPANCY · BUS {selectedBus.id}</div>
                <div className="text-xs text-slate-500 mt-0.5">Route {selectedBus.route} · Driver: {selectedBus.driver}</div>
              </div>
              <select value={selectedBusId} onChange={e => setSelectedBusId(e.target.value)}
                className="px-3 py-1.5 rounded-lg text-xs font-mono outline-none border text-slate-900"
                style={{ background: '#f1f5f9', borderColor: '#e2e8f0' }}>
                {state.buses.map(b => (
                  <option key={b.id} value={b.id}>{b.id} ({b.route}) - {b.passengers}/{b.capacity}</option>
                ))}
              </select>
            </div>

            <div className="p-6 rounded-2xl bg-white border" style={{ borderColor: '#e2e8f0' }}>
              <div className="grid grid-cols-10 gap-2 my-2">
                {Array.from({ length: selectedBus.capacity }).map((_, i) => {
                  const isOccupied = i < selectedBus.passengers;
                  return (
                    <div key={i} className="h-9 rounded-lg border flex items-center justify-center text-xs font-mono font-bold"
                      style={{
                        background: isOccupied ? 'rgba(6, 182, 212, 0.25)' : 'rgba(15, 39, 68, 0.4)',
                        borderColor: isOccupied ? '#06b6d4' : '#e2e8f0',
                        color: isOccupied ? '#38bdf8' : '#334155',
                      }}>
                      {isOccupied ? '👤' : i + 1}
                    </div>
                  );
                })}
              </div>
              <div className="mt-4 flex items-center justify-between text-xs font-mono text-slate-500">
                <span>Occupancy: <strong className="text-slate-900">{selectedBus.passengers} / {selectedBus.capacity}</strong></span>
                <span className={occupancyPct > 90 ? 'text-red-400 font-bold' : 'text-[#059669]'}>{occupancyPct}% Load</span>
              </div>
            </div>

            <div className="flex gap-2 pt-2">
              <button onClick={() => dispatch({ type: 'SIMULATE_PASSENGER_EVENT', busId: selectedBus.id, boardingDelta: 3, alightingDelta: 0 })}
                className="flex-1 py-1.5 rounded-lg text-xs font-mono font-bold border text-[#059669] hover:bg-emerald-500/10"
                style={{ borderColor: 'rgba(16,185,129,0.4)' }}>
                + Boarding (+3)
              </button>
              <button onClick={() => dispatch({ type: 'SIMULATE_PASSENGER_EVENT', busId: selectedBus.id, boardingDelta: 0, alightingDelta: 3 })}
                className="flex-1 py-1.5 rounded-lg text-xs font-mono font-bold border text-[#d97706] hover:bg-amber-500/10"
                style={{ borderColor: 'rgba(245,158,11,0.4)' }}>
                - Alighting (-3)
              </button>
            </div>
          </div>

          <div className="lg:col-span-5 liquid-glass p-5 rounded-2xl border space-y-4" style={{ borderColor: '#e2e8f0' }}>
            <div className="text-xs font-mono text-[#0284c7] font-bold uppercase">ALGORITHM DETAILS</div>
            <p className="text-xs text-slate-300 font-mono leading-relaxed">
              Optical bounding boxes track centroid vector coordinates across calibrated doorway threshold lines without facial recognition.
            </p>
            <button onClick={() => triggerScenario('overcrowding')}
              className="w-full py-2.5 rounded-xl font-bold font-mono text-xs uppercase text-amber-300 border hover:bg-amber-400/10"
              style={{ borderColor: 'rgba(245,158,11,0.5)' }}>
              ⚠ Simulate Overcrowding Alert Threshold
            </button>
          </div>
        </div>
      )}

      {activeTab === 'trends' && (
        <div className="liquid-glass p-5 rounded-2xl border" style={{ borderColor: '#e2e8f0' }}>
          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={hourlyPassengerData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" opacity={0.5} />
                <XAxis dataKey="hour" stroke="#64748b" fontSize={11} fontFamily="JetBrains Mono" />
                <YAxis stroke="#64748b" fontSize={11} fontFamily="JetBrains Mono" />
                <Tooltip contentStyle={{ background: '#ffffff', border: '1px solid #0284c7', borderRadius: '16px', color: '#0f172a', fontFamily: 'JetBrains Mono', fontSize: '11px', boxShadow: '0 10px 30px rgba(0,0,0,0.1)' }} />
                <Bar dataKey="boarding" fill="#10b981" name="Boarding Count" radius={[4, 4, 0, 0]} />
                <Bar dataKey="alighting" fill="#f59e0b" name="Alighting Count" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {activeTab === 'od' && (
        <div className="liquid-glass rounded-2xl border overflow-hidden" style={{ borderColor: '#e2e8f0' }}>
          <div className="divide-y divide-slate-100">
            {odMatrix.map((od, i) => (
              <div key={i} className="p-4 flex items-center justify-between gap-4 hover:bg-white/5 font-mono text-xs">
                <div>
                  <span className="text-slate-900 font-bold">{od.origin} ➔ {od.destination}</span>
                  <div className="text-slate-500 text-[10px] mt-0.5">Route: {od.primaryRoute} · Peak: {od.peakTime}</div>
                </div>
                <div className="text-[#0284c7] font-bold">{od.passengerVolume.toLocaleString()} pax</div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}