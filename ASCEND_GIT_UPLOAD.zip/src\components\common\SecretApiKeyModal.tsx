import { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';

export default function SecretApiKeyModal() {
  const { state, dispatch } = useApp();
  const [keyInput, setKeyInput] = useState(state.apiKey || '');
  const [showKey, setShowKey] = useState(false);
  const [selectedModel, setSelectedModel] = useState<'gemini-2.5' | 'yolov11-tensorrt' | 'custom-edge'>('gemini-2.5');
  const [testingStatus, setTestingStatus] = useState<'idle' | 'testing' | 'success' | 'error'>('idle');
  const [testResultMsg, setTestResultMsg] = useState('');
  const [activeTestTab, setActiveTestTab] = useState<'pothole' | 'anpr' | 'traffic'>('pothole');
  const [liveInferencing, setLiveInferencing] = useState(false);
  const [inferenceOutput, setInferenceOutput] = useState<string | null>(null);

  useEffect(() => {
    setKeyInput(state.apiKey || '');
  }, [state.apiKey]);

  if (!state.apiModalOpen) return null;

  const handleSaveKey = () => {
    if (!keyInput.trim()) {
      dispatch({ type: 'CLEAR_API_KEY' });
      return;
    }
    dispatch({ type: 'SET_API_KEY', key: keyInput.trim() });
    setTestingStatus('success');
    setTestResultMsg('API Key provisioned & active on Edge Inference Mesh!');
  };

  const handleTestConnection = () => {
    if (!keyInput.trim()) {
      setTestingStatus('error');
      setTestResultMsg('Please enter a valid API Key before running connection test.');
      return;
    }

    setTestingStatus('testing');
    setTestResultMsg('Pinging Edge Neural Gateway & verifying credentials...');

    setTimeout(() => {
      setTestingStatus('success');
      setTestResultMsg(`Connected successfully! Model: ${selectedModel.toUpperCase()} (Latency: 16ms, FP16 Active)`);
      dispatch({ type: 'SET_API_KEY', key: keyInput.trim() });
    }, 900);
  };

  const handleRunLiveInference = () => {
    setLiveInferencing(true);
    setInferenceOutput(null);

    setTimeout(() => {
      setLiveInferencing(false);
      if (activeTestTab === 'pothole') {
        setInferenceOutput('✓ [YOLOv11-Edge] Detected: Severe Pothole (Depth: 14.2cm, Conf: 97.4%, Lat: 12.9716°N, Long: 77.5946°E) -> BBMP Work Order #BBMP-2026-441 Generated.');
      } else if (activeTestTab === 'anpr') {
        setInferenceOutput('✓ [OCR-ByteTrack] Match: License Plate "KA05AB2267" (Conf: 98.8%, Vehicle: Dark SUV, Active Alert: Hit & Run Case #BTP-884).');
      } else {
        setInferenceOutput('✓ [Spatial-Density] Analyzed: Silk Board Junction (Density: 96.2%, Multimodal: 42 Cars, 68 Two-Wheelers, 8 Transit Buses, Advisory: Extended Green Wave +25s).');
      }
    }, 800);
  };

  const handleQuickDemoKey = () => {
    const demoKey = 'ascend_edge_ai_sih2026_live_tensorrt_mesh';
    setKeyInput(demoKey);
    dispatch({ type: 'SET_API_KEY', key: demoKey });
    setTestingStatus('success');
    setTestResultMsg('Demo AI Key provisioned: All Edge CV features unlocked!');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-md animate-fade-in font-sans">
      <div
        className="liquid-glass w-full max-w-2xl rounded-3xl border border-slate-200 shadow-2xl p-6 relative overflow-hidden space-y-5 bg-white/95 max-h-[90vh] overflow-y-auto"
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-200">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-[#0284c7] via-[#2563eb] to-[#7c3aed] flex items-center justify-center text-white text-lg font-black shadow-md">
              🔐
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-black text-slate-900 font-mono tracking-tight">
                  SECRET AI API GATEWAY
                </h2>
                <span className="text-[10px] px-2 py-0.5 rounded-full font-mono font-bold bg-[#0284c7]/10 text-[#0284c7] border border-[#0284c7]/30">
                  Shortcut: Alt + F3
                </span>
              </div>
              <p className="text-xs text-slate-500 font-mono mt-0.5">
                Provision API keys to unlock real-time neural edge detection and generative dispatch reasoning.
              </p>
            </div>
          </div>

          <button
            onClick={() => dispatch({ type: 'SET_API_MODAL', open: false })}
            className="w-8 h-8 rounded-full border border-slate-200 bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center text-sm font-bold transition-colors"
          >
            ✕
          </button>
        </div>

        {/* Status Banner */}
        <div className={'p-3.5 rounded-2xl border flex items-center justify-between text-xs font-mono ' + (
          state.isAiKeyActive
            ? 'bg-[#059669]/10 border-[#059669]/30 text-[#059669]'
            : 'bg-[#d97706]/10 border-[#d97706]/30 text-[#d97706]'
        )}>
          <div className="flex items-center gap-2">
            <span className={'w-2.5 h-2.5 rounded-full animate-blink ' + (
              state.isAiKeyActive ? 'bg-[#059669] shadow-[0_0_8px_#059669]' : 'bg-[#d97706]'
            )} />
            <span className="font-bold">
              {state.isAiKeyActive ? 'AI ENGINE: PROVISIONED & ACTIVE' : 'AI ENGINE: AWAITING API KEY'}
            </span>
          </div>
          <span className="text-[10px] font-semibold text-slate-600">
            {state.isAiKeyActive ? 'Live Edge Ingestion Enabled' : 'Simulated Fallback Mode'}
          </span>
        </div>

        {/* API Key Input Field */}
        <div className="space-y-3 font-mono text-xs">
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="font-bold text-slate-800">
                Inference API Key / Gateway Secret
              </label>
              <button
                onClick={handleQuickDemoKey}
                className="text-[10px] text-[#0284c7] font-bold hover:underline"
              >
                + Insert Demo Key
              </button>
            </div>

            <div className="relative flex items-center">
              <input
                type={showKey ? 'text' : 'password'}
                placeholder="Enter AI API Key (e.g. AIzaSy... or ascend_edge_...)"
                value={keyInput}
                onChange={e => setKeyInput(e.target.value)}
                className="w-full px-4 py-3 rounded-2xl border border-slate-300 bg-white text-slate-900 font-mono text-xs outline-none focus:border-[#0284c7] shadow-inner pr-24"
              />
              <button
                type="button"
                onClick={() => setShowKey(!showKey)}
                className="absolute right-3 text-xs text-slate-500 hover:text-slate-900 font-bold px-2 py-1 rounded-lg bg-slate-100"
              >
                {showKey ? 'HIDE' : 'SHOW'}
              </button>
            </div>
          </div>

          {/* AI Model Selector */}
          <div className="grid grid-cols-3 gap-2 pt-1">
            {[
              { id: 'gemini-2.5', label: 'Gemini 2.5 Flash', desc: 'Spatial Reasoning Co-Pilot' },
              { id: 'yolov11-tensorrt', label: 'YOLOv11 TensorRT', desc: 'Edge Road & Hazard Net' },
              { id: 'custom-edge', label: 'Custom HTTP Mesh', desc: 'Private Municipal Gateway' },
            ].map(m => (
              <button
                key={m.id}
                type="button"
                onClick={() => setSelectedModel(m.id as any)}
                className={'p-2.5 rounded-2xl border text-left transition-all ' + (
                  selectedModel === m.id
                    ? 'border-[#0284c7] bg-[#0284c7]/10 text-slate-900 font-bold ring-2 ring-[#0284c7]/30 shadow-sm'
                    : 'border-slate-200 bg-slate-50 text-slate-600 hover:bg-white'
                )}
              >
                <div className="text-[11px] font-bold truncate">{m.label}</div>
                <div className="text-[9px] text-slate-400 font-normal truncate mt-0.5">{m.desc}</div>
              </button>
            ))}
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2 pt-2">
            <button
              onClick={handleSaveKey}
              className="flex-1 py-3 rounded-2xl font-bold font-mono text-xs uppercase text-white bg-gradient-to-r from-[#0284c7] to-[#7c3aed] liquid-btn shadow-md"
            >
              Save & Activate AI Engine ➔
            </button>
            <button
              onClick={handleTestConnection}
              className="px-4 py-3 rounded-2xl font-bold font-mono text-xs border border-slate-300 bg-white hover:bg-slate-100 text-slate-700 transition-colors shadow-sm"
            >
              Ping Test ⚡
            </button>
            {state.isAiKeyActive && (
              <button
                onClick={() => {
                  dispatch({ type: 'CLEAR_API_KEY' });
                  setKeyInput('');
                  setTestingStatus('idle');
                  setTestResultMsg('');
                }}
                className="px-3 py-3 rounded-2xl font-bold font-mono text-xs border border-rose-200 bg-rose-50 text-rose-600 hover:bg-rose-100 transition-colors"
                title="Clear API Key"
              >
                Revoke
              </button>
            )}
          </div>

          {/* Test Status Message */}
          {testResultMsg && (
            <div className={'p-3 rounded-xl border text-[11px] font-mono ' + (
              testingStatus === 'success'
                ? 'bg-[#059669]/10 border-[#059669]/30 text-[#059669]'
                : testingStatus === 'error'
                ? 'bg-[#e11d48]/10 border-[#e11d48]/30 text-[#e11d48]'
                : 'bg-slate-100 border-slate-200 text-slate-700'
            )}>
              {testResultMsg}
            </div>
          )}
        </div>

        {/* Live AI Inference Verification Sandbox */}
        <div className="pt-3 border-t border-slate-200 space-y-3 font-mono text-xs">
          <div className="flex items-center justify-between">
            <div className="text-xs font-bold text-slate-800 uppercase tracking-wider">
              Live AI Detection Sandbox (Test Inference)
            </div>
            <div className="flex items-center gap-1 bg-slate-100 p-0.5 rounded-xl border border-slate-200 text-[10px]">
              {[
                { id: 'pothole', label: 'Road Surface' },
                { id: 'anpr', label: 'ANPR OCR' },
                { id: 'traffic', label: 'Traffic Density' },
              ].map(t => (
                <button
                  key={t.id}
                  onClick={() => {
                    setActiveTestTab(t.id as any);
                    setInferenceOutput(null);
                  }}
                  className={'px-2.5 py-1 rounded-lg font-bold transition-all ' + (
                    activeTestTab === t.id ? 'bg-[#0284c7] text-white shadow-sm' : 'text-slate-600 hover:text-slate-900'
                  )}
                >
                  {t.label}
                </button>
              ))}
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-slate-600 text-[11px]">
                Sample Input: <strong>Front Camera Frame #{activeTestTab.toUpperCase()}-084</strong>
              </span>
              <button
                onClick={handleRunLiveInference}
                disabled={liveInferencing}
                className="px-3.5 py-1.5 rounded-xl font-bold font-mono text-xs bg-[#0284c7] text-white liquid-btn shadow-sm disabled:opacity-50"
              >
                {liveInferencing ? 'Running YOLO Inference...' : 'Run Live Inference ⚡'}
              </button>
            </div>

            {inferenceOutput && (
              <div className="p-3 rounded-xl bg-white border border-[#059669]/40 text-[#059669] font-mono text-[11px] animate-fade-in shadow-sm leading-relaxed">
                {inferenceOutput}
              </div>
            )}
          </div>
        </div>

        {/* Footer Note */}
        <div className="text-center text-[10px] font-mono text-slate-400 pt-1">
          Keys are stored locally in secure browser storage and used for direct edge telemetry. Press <strong>Alt + F3</strong> anywhere to reopen this portal.
        </div>
      </div>
    </div>
  );
}