import { useState } from 'react';
import { useApp } from '../../context/AppContext';

const scenarios = [
  { id: 'pothole', label: 'Pothole Alert', icon: '⚠', color: '#d97706', desc: 'MG Road (14cm depth)' },
  { id: 'traffic', label: 'Traffic Spike', icon: '⬡', color: '#e11d48', desc: 'Silk Board Gridlock' },
  { id: 'overcrowding', label: 'Crowd Alert', icon: '👥', color: '#0284c7', desc: 'Bus B-102 Overcrowded' },
  { id: 'sos', label: 'Women SOS', icon: '🚨', color: '#e11d48', desc: 'Bus B-104 Distress Beacon', isSOS: true },
  { id: 'hit_and_run', label: 'Hit & Run ANPR', icon: '🔍', color: '#7c3aed', desc: 'Vehicle KA05AB2267' },
  { id: 'school_zone', label: 'School Hazard', icon: '🚸', color: '#d97706', desc: 'Pedestrian Risk Zone' },
  { id: 'waterlogging', label: 'Waterlogging', icon: '🌊', color: '#0284c7', desc: 'Koramangala 5th Block' },
];

export default function DemoScenarioBar() {
  const { state, dispatch, triggerScenario } = useApp();
  const [collapsed, setCollapsed] = useState(false);

  return (
    <div className="fixed bottom-4 right-5 z-50 flex flex-col items-end gap-2.5 font-mono">
      {!collapsed ? (
        <div
          className="liquid-glass p-4 rounded-3xl border border-slate-200/90 shadow-[0_20px_50px_rgba(0,0,0,0.12)] space-y-3 max-w-xl animate-fade-in backdrop-blur-2xl bg-white/85"
        >
          <div className="flex items-center justify-between gap-4 pb-2.5 border-b border-slate-200">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-[#0284c7] animate-blink shadow-[0_0_8px_#0284c7]" />
              <span className="text-xs font-bold text-slate-900 tracking-wider uppercase text-gradient-cyan">
                LIGHT LIQUID SCENARIO CONTROLLER
              </span>
              <span className="text-[9px] px-2 py-0.5 rounded-full bg-gradient-to-r from-[#0284c7] to-[#7c3aed] text-white font-bold shadow-sm">
                SIH 2026
              </span>
            </div>

            <div className="flex items-center gap-2">
              <div className="flex items-center rounded-xl bg-slate-100 p-0.5 border border-slate-200 text-[10px]">
                {[1, 2, 5].map(s => (
                  <button
                    key={s}
                    onClick={() => dispatch({ type: 'SET_SIMULATION_SPEED', speed: s })}
                    className={'px-2 py-0.5 rounded-lg font-bold transition-all ' + (
                      state.simulationSpeed === s ? 'bg-gradient-to-r from-[#0284c7] to-[#2563eb] text-white shadow-sm' : 'text-slate-500 hover:text-slate-900'
                    )}
                  >
                    {s}x
                  </button>
                ))}
              </div>

              <button
                onClick={() => setCollapsed(true)}
                className="p-1 text-slate-400 hover:text-slate-900 rounded-lg hover:bg-slate-100 text-xs transition-colors"
                title="Minimize Dock"
              >
                ✕
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {scenarios.map(sc => (
              <button
                key={sc.id}
                onClick={() => triggerScenario(sc.id as any)}
                className={'p-2.5 rounded-2xl border text-left transition-all liquid-btn ' + (
                  sc.isSOS
                    ? 'border-[#e11d48] bg-gradient-to-r from-[#e11d48]/20 to-[#7c3aed]/15 text-slate-900 animate-pulse shadow-md font-bold'
                    : 'border-slate-200 bg-white/70 text-slate-700 hover:border-[#0284c7]/50 hover:bg-white'
                )}
                title={sc.desc}
              >
                <div className="flex items-center gap-1.5 mb-0.5">
                  <span className="text-xs">{sc.icon}</span>
                  <span className="text-[11px] font-bold truncate" style={{ color: sc.color }}>
                    {sc.label}
                  </span>
                </div>
                <div className="text-[8.5px] text-slate-500 truncate leading-tight">{sc.desc}</div>
              </button>
            ))}

            <button
              onClick={() => dispatch({ type: 'RESET_DEMO' })}
              className="p-2.5 rounded-2xl border border-slate-200 bg-white/70 text-slate-600 hover:text-slate-900 hover:border-slate-300 text-left liquid-btn"
            >
              <div className="flex items-center gap-1.5 mb-0.5">
                <span className="text-xs">🔄</span>
                <span className="text-[11px] font-bold text-slate-800">Reset Demo</span>
              </div>
              <div className="text-[8.5px] text-slate-400">Restore clean state</div>
            </button>
          </div>
        </div>
      ) : (
        <button
          onClick={() => setCollapsed(false)}
          className="flex items-center gap-2.5 px-4 py-2.5 rounded-full liquid-glass border border-slate-200 shadow-[0_10px_30px_rgba(0,0,0,0.1)] text-xs font-bold text-slate-900 transition-all hover:scale-105 active:scale-95"
        >
          <span className="w-2.5 h-2.5 rounded-full bg-[#0284c7] animate-blink shadow-[0_0_8px_#0284c7]" />
          <span className="text-gradient-cyan">⚡ 7 DEMO SCENARIOS</span>
          <span className="text-slate-500 text-[10px]">▲</span>
        </button>
      )}
    </div>
  );
}