import { useState } from 'react';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { predictionData } from '../data/mockData';

export default function PredictiveAI() {
  const [horizon, setHorizon] = useState<'1h' | '3h' | '24h'>('1h');

  return (
    <div className="flex-1 overflow-y-auto p-4 lg:p-6 space-y-6" >
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-2 border-b" style={{ borderColor: '#e2e8f0' }}>
        <div>
          <div className="text-xs font-mono tracking-widest text-[#0284c7] uppercase">NEURAL SPATIAL FORECASTING</div>
          <h1 className="text-2xl lg:text-3xl font-black text-slate-900 mt-1">Predictive AI & Horizon Forecasting</h1>
        </div>
        <div className="flex items-center rounded-xl p-1 border" style={{ background: '#f1f5f9', borderColor: '#e2e8f0' }}>
          {(['1h', '3h', '24h'] as const).map(h => (
            <button key={h} onClick={() => setHorizon(h)}
              className="px-3 py-1 rounded-lg text-xs font-mono font-bold"
              style={{ background: horizon === h ? '#06b6d4' : 'transparent', color: horizon === h ? '#000' : '#94a3b8' }}>
              Horizon {h}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <div className="liquid-glass p-5 rounded-2xl border" style={{ borderColor: '#e2e8f0' }}>
          <h3 className="text-sm font-bold text-slate-900 mb-4">Traffic Congestion Risk Horizon</h3>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={predictionData.congestion}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" opacity={0.5} />
                <XAxis dataKey="time" stroke="#64748b" fontSize={11} fontFamily="JetBrains Mono" />
                <YAxis stroke="#64748b" fontSize={11} fontFamily="JetBrains Mono" />
                <Tooltip contentStyle={{ background: '#ffffff', border: '1px solid #0284c7', borderRadius: '16px', color: '#0f172a', fontFamily: 'JetBrains Mono', fontSize: '11px', boxShadow: '0 10px 30px rgba(0,0,0,0.1)' }} />
                <Area type="monotone" dataKey="risk" stroke="#ef4444" fill="#ef4444" fillOpacity={0.3} name="Congestion Risk %" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="liquid-glass p-5 rounded-2xl border" style={{ borderColor: '#e2e8f0' }}>
          <h3 className="text-sm font-bold text-slate-900 mb-4">Passenger Demand Forecast</h3>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={predictionData.passengerDemand}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" opacity={0.5} />
                <XAxis dataKey="time" stroke="#64748b" fontSize={11} fontFamily="JetBrains Mono" />
                <YAxis stroke="#64748b" fontSize={11} fontFamily="JetBrains Mono" />
                <Tooltip contentStyle={{ background: '#ffffff', border: '1px solid #0284c7', borderRadius: '16px', color: '#0f172a', fontFamily: 'JetBrains Mono', fontSize: '11px', boxShadow: '0 10px 30px rgba(0,0,0,0.1)' }} />
                <Area type="monotone" dataKey="demand" stroke="#06b6d4" fill="#06b6d4" fillOpacity={0.3} name="Passenger Demand" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
}