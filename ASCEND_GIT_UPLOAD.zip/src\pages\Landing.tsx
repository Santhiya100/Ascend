import { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import ThemeSlider from '../components/common/ThemeSlider';

const floatingCards = [
  { label: 'POTHOLE DETECTED', color: '#d97706', icon: '⚠', lat: '12.9716°N', loc: 'MG Road Junction', conf: '96.2%' },
  { label: 'TRAFFIC BOTTLENECK', color: '#e11d48', icon: '⬡', lat: '12.9550°N', loc: 'Silk Board Flyover', conf: '98.4%' },
  { label: 'PASSENGER FLOW', color: '#0284c7', icon: '◉', lat: '12.9800°N', loc: 'Majestic Terminal', conf: '99.1%' },
  { label: 'CRITICAL SOS ALERT', color: '#e11d48', icon: '🚨', lat: '12.9600°N', loc: 'Route 12, Trinity Circle', conf: '100%' },
  { label: 'WATERLOGGING DETECTED', color: '#0284c7', icon: '🌊', lat: '12.9350°N', loc: 'Koramangala 5th Block', conf: '94.7%' },
];

const features = [
  {
    icon: '◈',
    title: 'Road Surface & Hazard AI',
    tag: 'CV / YOLO-Edge',
    color: '#d97706',
    desc: 'Automated optical detection of potholes, surface cracks, damaged curbs, and flash waterlogging across 1,200+ km of city roads daily without dedicated sensor cars.',
    metrics: '96.2% Precision · 14cm Avg Depth Resolution',
  },
  {
    icon: '⊡',
    title: 'Traffic Intelligence & Flow',
    tag: 'Density / OCR',
    color: '#e11d48',
    desc: 'Real-time vehicle counting, multimodal flow classification (cars, bikes, buses, trucks), bottleneck forecasting, and signal timing optimization telemetry.',
    metrics: '6 Classification Classes · <2s Ingestion Delay',
  },
  {
    icon: '◉',
    title: 'Passenger Flow AI',
    tag: 'Privacy-First',
    color: '#0284c7',
    desc: 'Anonymous aggregate passenger counting via overhead cabin cameras. Strict privacy-by-design: zero facial recognition or biometric capture.',
    metrics: '100% Anonymous · Dynamic Boarding & Alighting Vector',
  },
  {
    icon: '⚡',
    title: 'Safety & Critical SOS',
    tag: 'Instant Dispatch',
    color: '#e11d48',
    desc: 'Passenger emergency button integration, rash driving telemetry, driver drowsiness alerts, and school-zone pedestrian safety hazard alerts.',
    metrics: '<15s Control Room Response · Live GIS Coordinate Sharing',
  },
  {
    icon: '◈',
    title: 'Predictive Municipal AI',
    tag: 'Neural Forecasting',
    color: '#7c3aed',
    desc: 'AI-driven forecasting for road degradation, peak passenger crowding, and traffic pressure hours before gridlock occurs.',
    metrics: '1h, 3h & 24h Horizon Forecasts · 91% Predictive Precision',
  },
];

const pipelineSteps = [
  { title: 'Bus Optical Array', sub: 'Front Stereo, Rear OCR, Cabin Anonymized & Blindspot Cams', icon: '📹' },
  { title: 'Edge AI Compute Unit', sub: 'NVIDIA Jetson YOLO-v11 TensorRT + ByteTrack + Anonymizer', icon: '⚡' },
  { title: 'Secure Cellular Link', sub: 'Encrypted Telemetry & Spatial Metadata Payloads', icon: '🔒' },
  { title: 'Central AI Aggregator', sub: 'Spatial Deduplication & Multi-Horizon Predictive Models', icon: '☁' },
  { title: 'Command & GIS Center', sub: 'Multi-Agency Dispatch: Transport, BBMP, Police & Safety', icon: '🖥' },
];

export default function Landing() {
  const { state, navigate, triggerScenario } = useApp();
  const [activeCard, setActiveCard] = useState(0);

  useEffect(() => {
    const t = setInterval(() => setActiveCard(v => (v + 1) % floatingCards.length), 3000);
    return () => clearInterval(t);
  }, []);

  return (
    <div className={`min-h-screen flex flex-col liquid-canvas selection:bg-[#0284c7] selection:text-white ${state.theme === 'dark' ? 'theme-dark text-slate-100' : 'text-slate-900'}`}>
      
      {/* Dynamic Background Blob */}
      <div className="liquid-blob-center" />

      {/* Top Header */}
      <header className="flex items-center justify-between px-6 lg:px-12 py-4 border-b liquid-glass sticky top-0 z-50"
        style={{ borderColor: 'rgba(226, 232, 240, 0.9)' }}>
        <div className="flex items-center gap-3 cursor-pointer" onClick={() => navigate('landing')}>
          <div className="w-10 h-10 rounded-2xl overflow-hidden flex items-center justify-center shadow-md border border-slate-200 bg-white">
            <img src="/ascend-logo.jpg" alt="ASCEND WEB" className="w-full h-full object-cover" />
          </div>
          <div>
            <div className="font-black tracking-widest text-base text-gradient-cyan">ASCEND WEB</div>
            <div className="text-[9px] font-mono text-slate-500 tracking-widest uppercase font-semibold">AI URBAN INTELLIGENCE</div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <ThemeSlider />
          <div className="hidden md:flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-mono bg-[#059669]/10 border border-[#059669]/30 text-[#059669] font-bold">
            <span className="w-2 h-2 rounded-full bg-[#059669] animate-blink" />
            <span>SMART INDIA HACKATHON 2026</span>
          </div>

          <button
            onClick={() => navigate('login')}
            className="px-5 py-2.5 rounded-2xl text-xs font-mono font-bold uppercase transition-all hover:scale-105 active:scale-95 shadow-md bg-gradient-to-r from-[#0284c7] to-[#7c3aed] text-white liquid-btn"
          >
            Launch Command Center →
          </button>
        </div>
      </header>

      {/* Hero Section */}
      <main className="flex-1 max-w-7xl mx-auto px-6 lg:px-12 py-12 lg:py-20 space-y-16 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          <div className="lg:col-span-7 space-y-6">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-mono font-semibold bg-white border border-slate-200 shadow-sm text-slate-700">
              <span className="w-2 h-2 rounded-full bg-[#0284c7] animate-blink" />
              <span>BMTC FLEET-MOUNTED EDGE AI PLATFORM</span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black text-slate-900 tracking-tight leading-none">
              Transforming Public Buses into{' '}
              <span className="text-gradient-cyan">Autonomous Mobile Sensors</span>
            </h1>

            <p className="text-base sm:text-lg text-slate-600 leading-relaxed max-w-2xl font-normal">
              ASCEND turns everyday transit buses into spatial AI perception units — streaming real-time road hazard detection, multimodal traffic intelligence, anonymous passenger counting, and emergency response across the entire city.
            </p>

            <div className="flex flex-wrap items-center gap-4 pt-2">
              <button
                onClick={() => navigate('login')}
                className="px-8 py-3.5 rounded-2xl font-bold font-mono text-sm uppercase text-white shadow-lg transition-all hover:scale-105 active:scale-95 bg-gradient-to-r from-[#0284c7] via-[#2563eb] to-[#7c3aed] liquid-btn"
              >
                Access Command Center →
              </button>
              <button
                onClick={() => triggerScenario('pothole')}
                className="px-6 py-3.5 rounded-2xl font-bold font-mono text-xs uppercase text-[#d97706] bg-white border border-[#d97706]/40 hover:bg-[#d97706]/10 transition-all liquid-btn shadow-sm"
              >
                ⚠ Test Live Pothole Alert
              </button>
            </div>
          </div>

          <div className="lg:col-span-5 relative">
            <div className="liquid-glass p-6 rounded-3xl border border-slate-200/90 shadow-2xl relative overflow-hidden space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-200">
                <div className="text-xs font-mono font-bold text-gradient-cyan uppercase">
                  LIVE SPATIAL INGESTION STREAM
                </div>
                <span className="text-[10px] font-mono text-slate-500 font-semibold">120 FPS Jetson Edge</span>
              </div>

              {/* Dynamic Rotating Card */}
              {floatingCards.map((card, idx) => (
                <div
                  key={card.label}
                  className={'p-4 rounded-2xl border transition-all duration-500 ' + (
                    idx === activeCard
                      ? 'bg-white border-slate-300 shadow-md scale-102'
                      : 'bg-white/40 border-slate-100 opacity-60'
                  )}
                >
                  <div className="flex items-center justify-between text-xs font-mono font-bold mb-1">
                    <span className="flex items-center gap-2" style={{ color: card.color }}>
                      <span>{card.icon}</span>
                      <span>{card.label}</span>
                    </span>
                    <span className="text-slate-900">{card.conf}</span>
                  </div>
                  <div className="text-xs text-slate-700 font-medium">{card.loc}</div>
                  <div className="text-[10px] text-slate-400 font-mono mt-0.5">GPS: {card.lat}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* 5-Layer Pipeline */}
        <div className="space-y-6">
          <div className="text-center space-y-2">
            <div className="text-xs font-mono font-bold uppercase text-gradient-cyan">END-TO-END ARCHITECTURE</div>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">5-Layer Edge-to-Cloud Pipeline</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-5 gap-3.5">
            {pipelineSteps.map((step, idx) => (
              <div key={step.title} className="liquid-glass p-4 rounded-3xl border border-slate-200/80 shadow-md text-center space-y-2">
                <div className="text-2xl">{step.icon}</div>
                <div className="text-xs font-mono font-bold text-slate-500">STAGE 0{idx + 1}</div>
                <div className="text-xs font-bold text-slate-900">{step.title}</div>
                <div className="text-[11px] text-slate-600 leading-snug">{step.sub}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {features.map(f => (
            <div key={f.title} className="liquid-glass p-6 rounded-3xl border border-slate-200/80 shadow-md hover:shadow-xl transition-all space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xl" style={{ color: f.color }}>{f.icon}</span>
                <span className="text-[10px] font-mono px-2.5 py-0.5 rounded-full font-bold bg-slate-100 text-slate-700 border border-slate-200">
                  {f.tag}
                </span>
              </div>
              <h3 className="text-base font-bold text-slate-900">{f.title}</h3>
              <p className="text-xs text-slate-600 leading-relaxed">{f.desc}</p>
              <div className="pt-2 border-t border-slate-100 text-[10px] font-mono font-semibold text-slate-500">{f.metrics}</div>
            </div>
          ))}
        </div>
      </main>

      {/* Footer */}
      <footer className="text-center py-6 text-xs font-mono text-slate-500 border-t border-slate-200 liquid-glass">
        ASCEND WEB Urban Intelligence · Smart India Hackathon 2026 · Light Liquid Glass Edition
      </footer>
    </div>
  );
}