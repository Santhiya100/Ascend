import { useState } from 'react';
import { useApp } from '../context/AppContext';
import type { MaintenanceTask } from '../data/mockData';

export default function MaintenanceManagement() {
  const { state, dispatch } = useApp();
  const [selectedTask, setSelectedTask] = useState<MaintenanceTask | null>(state.maintenance[0]);

  const columns: { label: string; status: MaintenanceTask['status']; color: string }[] = [
    { label: 'Open Work Orders', status: 'open', color: '#f59e0b' },
    { label: 'Assigned to Ward', status: 'assigned', color: '#06b6d4' },
    { label: 'In Progress / Repair', status: 'in_progress', color: '#8b5cf6' },
    { label: 'Quality Passed & Done', status: 'completed', color: '#10b981' },
  ];

  return (
    <div className="flex-1 overflow-y-auto p-4 lg:p-6 space-y-6" >
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-2 border-b" style={{ borderColor: '#e2e8f0' }}>
        <div>
          <div className="text-xs font-mono tracking-widest text-[#0284c7] uppercase">BBMP MUNICIPAL WORK ORDERS</div>
          <h1 className="text-2xl lg:text-3xl font-black text-slate-900 mt-1">Road Infrastructure Maintenance</h1>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
        {columns.map(col => {
          const tasks = state.maintenance.filter(m => m.status === col.status);
          return (
            <div key={col.status} className="liquid-glass p-3.5 rounded-2xl border space-y-2" style={{ borderColor: '#e2e8f0' }}>
              <div className="flex justify-between items-center pb-2 border-b" style={{ borderColor: '#e2e8f0' }}>
                <span className="text-xs font-mono font-bold uppercase" style={{ color: col.color }}>{col.label}</span>
                <span className="text-xs font-mono px-1.5 py-0.2 rounded font-bold text-slate-900" style={{ background: col.color }}>{tasks.length}</span>
              </div>
              {tasks.map(t => (
                <div key={t.id} onClick={() => setSelectedTask(t)}
                  className="p-3 rounded-xl border bg-white/80/80 cursor-pointer hover:border-cyan-400 text-xs font-mono"
                  style={{ borderColor: selectedTask?.id === t.id ? '#06b6d4' : '#e2e8f0' }}>
                  <div className="font-bold text-slate-900">{t.id}</div>
                  <div className="text-slate-300 font-semibold">{t.defectType}</div>
                  <div className="text-[10px] text-slate-500 mt-1">{t.location}</div>
                </div>
              ))}
            </div>
          );
        })}
      </div>

      {selectedTask && (
        <div className="liquid-glass p-5 rounded-2xl border space-y-3" style={{ borderColor: '#e2e8f0' }}>
          <div className="text-xs font-mono text-[#0284c7] font-bold uppercase">WORK ORDER · {selectedTask.id}</div>
          <h3 className="text-base font-bold text-slate-900">{selectedTask.defectType} ({selectedTask.location})</h3>
          <p className="text-xs text-slate-300 font-mono">{selectedTask.description}</p>
          <div className="flex gap-2 pt-2">
            <button onClick={() => dispatch({ type: 'UPDATE_MAINTENANCE', id: selectedTask.id, update: { status: 'completed' } })}
              className="px-4 py-1.5 rounded-lg text-xs font-mono font-bold bg-emerald-500 text-black hover:bg-emerald-400">
              ✓ Mark Quality Passed & Done
            </button>
          </div>
        </div>
      )}
    </div>
  );
}